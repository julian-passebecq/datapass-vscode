"""Trusted static syntax worker. No source execution, imports, evaluation or SQL connection."""
import ast, ctypes as c, hashlib, json, os, socket, struct, subprocess, sys, winreg
from ctypes import wintypes as w

FRAME_LIMIT=320*1024*1024
OUTPUT_LIMIT=48*1024*1024
AST_FILENAME='<datapass-static-ast>'
ALLOWED_ENV=frozenset(k.upper() for k in ('SystemRoot','WINDIR','SystemDrive','USERPROFILE','LOCALAPPDATA','APPDATA','TEMP','TMP'))
PROBES=('memory','cpu','time','subprocess','network','file-write','import','exec')

class ContainmentRefused(BaseException):
    """BaseException so library `except Exception` blocks cannot swallow a refusal."""
    def __init__(self,code): super().__init__(code); self.code=code

class Guard:
    """PY1C parse-only guard. Installed after warm-up; an audit hook cannot be removed."""
    def __init__(self): self.armed=False; self.permit=None; self.refused=None; self.temp=None
    def refuse(self,code):
        if self.refused is None: self.refused=code
        raise ContainmentRefused(code)
    def parse(self,text):
        # The only compile allowed: ast.parse of the current captured text, AST-only flag.
        # CPython reports the source to the audit hook as UTF-8 bytes.
        self.permit=(text,text.encode('utf-8','surrogatepass'))
        try: return ast.parse(text,filename=AST_FILENAME)
        finally: self.permit=None
    def hook(self,event,args):
        if not self.armed: return
        if event=='compile':
            if args[1]==AST_FILENAME and self.permit is not None and args[0] in self.permit: return
            self.refuse('code-execution-refused')
        if event in ('exec','code.__new__','function.__new__','marshal.loads','marshal.load','pickle.find_class','builtins.breakpoint','sys.addaudithook','cpython.run_command','cpython.run_file','cpython.run_module'):
            self.refuse('code-execution-refused')
        if event=='import': self.refuse('import-refused')
        if event.startswith('socket.'): self.refuse('network-refused')
        if event in ('subprocess.Popen','os.system','os.exec','os.spawn','os.posix_spawn','os.startfile','os.fork','os.forkpty','_winapi.CreateProcess','os.kill','signal.pthread_kill'):
            self.refuse('child-process-refused')
        if event.startswith('ctypes.') or event.startswith('winreg.') or event=='_winapi.CreateNamedPipe': self.refuse('native-call-refused')
        if event in ('os.remove','os.rename','os.rmdir','os.mkdir','os.chmod','os.link','os.symlink','os.truncate','os.utime','shutil.rmtree','shutil.copyfile','shutil.move','os.chown'):
            self.refuse('file-write-refused')
        if event=='open':
            path,mode,flags=args[0],args[1],args[2]
            writing=(isinstance(mode,str) and any(ch in mode for ch in 'wax+')) or (isinstance(flags,int) and flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_APPEND|os.O_TRUNC))
            if writing and not self.inside_temp(path): self.refuse('file-write-refused')
    def inside_temp(self,path):
        if not self.temp or not isinstance(path,(str,bytes)): return False
        path=os.fsdecode(path)
        try: return os.path.commonpath([os.path.normcase(os.path.abspath(path)),self.temp])==self.temp
        except ValueError: return False
    def arm(self):
        temp=os.environ.get('TEMP')
        self.temp=os.path.normcase(os.path.abspath(temp)) if temp else None
        self.armed=True

GUARD=Guard()

def scrub_environment():
    """Env scrubbed to the controller allowlist; sys.path frozen to the runtime directory only."""
    for key in [k for k in os.environ if k.upper() not in ALLOWED_ENV]: del os.environ[key]
    runtime=os.path.dirname(os.path.abspath(sys.executable))
    sys.path[:]=[p for p in sys.path if os.path.normcase(os.path.abspath(p)).startswith(os.path.normcase(runtime))]
    sys.path_importer_cache.clear()
    return {'environment':sorted(os.environ),'sysPath':len(sys.path)}

def warm_up():
    """Load every module the parse path can need before the import freeze."""
    import logging, re, encodings.utf_8, encodings.ascii
    logging.getLogger('sqlglot').disabled=True
    import sqlglot, sqlglot.dialects.tsql, sqlglot.dialects.spark
    from sqlglot.errors import ParseError
    for dialect in ('tsql','spark'):
        for text in ('SELECT a.b AS c FROM d.e AS a JOIN f ON a.x=f.x WHERE a.y>1 GROUP BY a.b','SELECT ( FROM',SDP_WARM_UP):
            try: sql_statements(text,dialect)
            except ParseError: pass
    python_tree(ast.parse('import a\nx: int = f(1, *y, k=2)[0].z\nasync def g():\n    await h()\n',filename=AST_FILENAME))
    try: ast.parse('def (',filename=AST_FILENAME)
    except SyntaxError as error: str(error)
    json.dumps(json.loads('{"a":[1,2.5,"\\u00e9",null,true]}'),ensure_ascii=True,allow_nan=False,separators=(',',':'))
    try: bytearray(1)
    except MemoryError: pass

def run_probe(name):
    """Fixed qualification attempts. Each must be refused by the OS, the Job Object or the guard."""
    if name=='memory': return len(bytearray(64*1024*1024))
    if name=='cpu':
        while True: pass
    if name=='time':
        import time; time.sleep(30)
    if name=='subprocess': return subprocess.run([sys.executable,'-c','pass'],timeout=1)
    if name=='network': return socket.socket(socket.AF_INET,socket.SOCK_STREAM).connect(('127.0.0.1',9))
    if name=='file-write':
        with open(os.path.join(os.path.dirname(os.path.abspath(sys.executable)),'py1c-probe-write.txt'),'w') as stream: stream.write('refused')
    if name=='import': import xmlrpc.client
    if name=='exec': exec('1')
    return None

def exact(count):
    chunks=[]
    while count:
        piece=sys.stdin.buffer.read(min(count,65536))
        if not piece: raise ValueError('truncated-frame')
        chunks.append(piece); count-=len(piece)
    return b''.join(chunks)

def read_frame(limit):
    size=struct.unpack('<I',exact(4))[0]
    if not 0<size<=limit: raise ValueError('frame-limit')
    return json.loads(exact(size))

def preflight(context):
    if context.get('policy')!='local-static-parser-v1': return 'unknown-policy'
    kernel=c.WinDLL('kernel32',use_last_error=True)
    create=kernel.CreateFileW
    create.argtypes=[w.LPCWSTR,w.DWORD,w.DWORD,c.c_void_p,w.DWORD,w.DWORD,c.c_void_p]
    create.restype=c.c_void_p
    close=kernel.CloseHandle; close.argtypes=[c.c_void_p]; close.restype=w.BOOL
    if context.get('containment')=='trusted-local-host-only':
        # No AppContainer token: the Job Object and the guard still refuse children,
        # but selected-root, registry and socket denial cannot be proved here.
        try:
            subprocess.run([sys.executable,'-I','-S','-c','pass'],timeout=1,check=False,
                           stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            return 'child-process-allowed'
        except OSError as error:
            if error.winerror not in (367,1816): return 'child-denial-unknown'
        except subprocess.TimeoutExpired: return 'child-process-allowed'
        return None
    # A write attempt next to the runtime must be denied to the LPAC token.
    probe=os.path.join(os.path.dirname(os.path.abspath(sys.executable)),'py1c-write-denied.probe')
    handle=create(probe,0x40000000,0,None,1,0x04000000,None)
    if handle!=c.c_void_p(-1).value:
        close(handle); return 'runtime-writable'
    if c.get_last_error()!=5: return 'write-denial-unknown'
    # READ_DATA for files / LIST_DIRECTORY for directories. Never read content.
    for path in context['paths']:
        handle=create(path,1,7,None,3,0x02000000,None)
        if handle!=c.c_void_p(-1).value:
            close(handle); return 'selected-root-readable'
        if c.get_last_error()!=5: return 'selected-root-access-unknown'
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,context['registryKey'],0,winreg.KEY_QUERY_VALUE):
            return 'hkcu-canary-readable'
    except OSError as error:
        if error.winerror!=5: return 'hkcu-access-unknown'
    try:
        connection=socket.socket(); connection.close(); return 'network-socket-allowed'
    except OSError as error:
        if error.winerror!=10013: return 'network-denial-unknown'
    try:
        subprocess.run([sys.executable,'-I','-S','-c','pass'],timeout=1,check=False,
                       stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        return 'child-process-allowed'
    except OSError as error:
        if error.winerror!=367: return 'child-denial-unknown'
    except subprocess.TimeoutExpired: return 'child-process-allowed'
    return None

def python_tree(node,depth=0,budget=None):
    if budget is None: budget=[0]
    if depth>128: raise ValueError('syntax-depth-limit')
    budget[0]+=1
    if budget[0]>50000: raise ValueError('syntax-node-limit')
    if isinstance(node,ast.AST):
        result={'nodeType':type(node).__name__,'fields':{}}
        for key,value in ast.iter_fields(node): result['fields'][key]=python_tree(value,depth+1,budget)
        for key in ('lineno','col_offset','end_lineno','end_col_offset'):
            if hasattr(node,key): result[key]=getattr(node,key)
        return result
    if isinstance(node,list): return [python_tree(value,depth+1,budget) for value in node]
    if isinstance(node,int) and not isinstance(node,bool) and abs(node)>9007199254740991:
        return {'literalKind':'int','decimal':str(node)}
    if node is None or isinstance(node,(str,bool,int)): return node
    # JSON cannot losslessly encode complex/bytes/ellipsis/non-finite Python constants.
    if isinstance(node,float) and node==node and abs(node)!=float('inf'): return node
    return {'literalKind':type(node).__name__}

SDP_WARM_UP=("CREATE OR REFRESH PRIVATE STREAMING TABLE a (x INT, CONSTRAINT c EXPECT (x > 0) ON VIOLATION DROP ROW) AS SELECT x FROM STREAM b;\n"
    "CREATE LIVE TABLE m AS SELECT x FROM LIVE.a;\nCREATE FLOW f AS INSERT INTO ONCE a BY NAME SELECT x FROM STREAM(b);\n"
    "CREATE FLOW g AS AUTO CDC INTO a FROM STREAM(b) KEYS (x) IGNORE NULL UPDATES APPLY AS DELETE WHEN op = 'D' SEQUENCE BY ts "
    "COLUMNS * EXCEPT (op) STORED AS SCD TYPE 2 TRACK HISTORY ON x")
SDP_CDC_CLAUSES=(('KEYS',),('IGNORE','NULL','UPDATES'),('APPLY','AS','DELETE','WHEN'),('APPLY','AS','TRUNCATE','WHEN'),('SEQUENCE','BY'),('COLUMNS',),('STORED','AS','SCD','TYPE'),('TRACK','HISTORY','ON'))

def sql_statements(text,dialect):
    """`datapass.sql-syntax-facts/1` statements: exactly `sqlglot.parse`, except Spark files holding declarative-pipeline syntax."""
    import sqlglot
    if dialect=='spark':
        planned=sdp_statements(text)
        if planned is not None: return planned
    statements=sqlglot.parse(text,read=dialect)
    if len(statements)>500: raise ValueError('statement-limit')
    out=[]; budget=[0]
    for statement in statements:
        if statement is not None: sdp_keep(out,{'tree':statement.dump()},budget)
    return out

def sdp_keep(out,statement,budget):
    """Appends one statement, stopping as soon as the 500-statement or 50k-node limit is passed (not after the whole file)."""
    budget[0]+=sdp_nodes(statement)
    if budget[0]>50000: raise ValueError('syntax-node-limit')
    out.append(statement)
    if len(out)>500: raise ValueError('statement-limit')

def sdp_nodes(value):
    """Syntax nodes in a statement: its tree plus every tree dump in its `sdp` annotation."""
    if isinstance(value,list): return len(value) if value and isinstance(value[0],dict) and ('c' in value[0] or 'v' in value[0]) else sum(sdp_nodes(v) for v in value)
    if isinstance(value,dict): return sum(sdp_nodes(v) for v in value.values())
    return 0

def sdp_statements(text):
    """SDP1b: Lakeflow / Spark declarative pipeline SQL. SQLGlot 30.19 has no grammar for PRIVATE, LIVE, INCREMENTAL, CREATE FLOW,
    AUTO CDC / APPLY CHANGES, CONSTRAINT ... EXPECT or `STREAM name`. These words are found on SQLGlot's own tokens, blanked in place
    (same length, newlines kept, so every offset stays the file's) and recorded in the statement's `sdp` annotation; the rest of the
    statement, and each AUTO CDC clause body, is parsed by SQLGlot. None when no statement uses them: the caller parses as before."""
    import sqlglot
    from sqlglot import exp
    from sqlglot.dialects.dialect import Dialect
    from sqlglot.tokens import TokenType as T
    from sqlglot.errors import ParseError, TokenError
    try: tokens=Dialect.get_or_raise('spark').tokenize(text)
    except TokenError: return None
    starts=[0]+[i+1 for i,ch in enumerate(text) if ch=='\n']
    def word(ts,i): return ts[i].text.upper() if 0<=i<len(ts) and ts[i].token_type not in (T.STRING,T.IDENTIFIER) else None
    def named(t): return t.token_type==T.IDENTIFIER or (t.token_type not in (T.STRING,T.NUMBER) and (t.text[:1].isalpha() or t.text[:1]=='_'))
    def name_end(ts,i):
        while i+2<len(ts) and ts[i+1].token_type==T.DOT and named(ts[i+2]): i+=2
        return i
    def close(ts,i):
        depth=0
        for j in range(i,len(ts)):
            if ts[j].token_type==T.L_PAREN: depth+=1
            elif ts[j].token_type==T.R_PAREN:
                depth-=1
                if depth==0: return j
        return None
    def parse(start,end,masks=(),into=None,many=False):
        """text[start:end+1] with masks applied, parsed alone behind a prefix that keeps the file's line, column and offset."""
        lo,hi=0,len(starts)-1
        while lo<hi:
            mid=(lo+hi+1)//2
            if starts[mid]<=start: lo=mid
            else: hi=mid-1
        prefix='\n'*lo+' '*(start-starts[lo]); body=list(text[start:end+1])
        for s,e,put in masks:
            for k in range(s,e+1):
                if start<=k<=end and body[k-start] not in '\r\n': body[k-start]=put[k-s] if k-s<len(put) else ' '
        source=prefix+''.join(body); delta=start-len(prefix)
        trees=[t for t in sqlglot.parse(source,read='spark')] if many else [sqlglot.parse_one(source,read='spark',into=into)]
        dumps=[]
        for tree in trees:
            if tree is None: continue
            dump=tree.dump()
            for node in dump:
                if 'm' in node: node['m']=dict(node['m'],start=node['m']['start']+delta,end=node['m']['end']+delta)
            dumps.append(dump)
        return dumps if many else dumps[0]
    def clause_at(ts,i):
        for kw in SDP_CDC_CLAUSES:
            if all(word(ts,i+x)==w for x,w in enumerate(kw)): return kw
        return None
    heads={kw[0] for kw in SDP_CDC_CLAUSES}
    def next_clause(ts,i):
        """Next depth-0 token opening a clause, known or not (an unknown `APPLY AS MERGE ...` must not extend the clause before it)."""
        depth=0
        for j in range(i,len(ts)):
            if ts[j].token_type==T.L_PAREN: depth+=1
            elif ts[j].token_type==T.R_PAREN: depth-=1
            elif depth==0 and word(ts,j) in heads: return j
        return len(ts)
    def unlive(ts,i):
        return i+2 if word(ts,i)=='LIVE' and i+2<len(ts) and ts[i+1].token_type==T.DOT and named(ts[i+2]) else i
    def cdc(ts,k,ann):
        """`AUTO CDC | APPLY CHANGES INTO target FROM [STREAM] source KEYS (...) ... SEQUENCE BY ...` at token k."""
        t0=unlive(ts,k+3); t1=name_end(ts,t0)
        if t0>=len(ts) or not named(ts[t0]) or word(ts,t1+1)!='FROM' or t1+2>=len(ts): return None
        s=t1+2; streaming=word(ts,s)=='STREAM'
        if streaming and s+1<len(ts) and ts[s+1].token_type==T.L_PAREN:
            e=close(ts,s+1); s=unlive(ts,s+2)
            if e is None or e<s+1 or name_end(ts,s)!=e-1: return None
            source=(s,e-1); pos=e+1
        else:
            s=unlive(ts,s+1 if streaming else s)
            if s>=len(ts) or not named(ts[s]): return None
            source=(s,name_end(ts,s)); pos=source[1]+1
        ann['live']=ann['live'] or t0!=k+3 or word(ts,source[0]-2)=='LIVE'
        out={'target':parse(ts[t0].start,ts[t1].end,into=exp.Table),'source':parse(ts[source[0]].start,ts[source[1]].end,into=exp.Table),
             'sourceStreaming':streaming,'keys':None,'ignoreNullUpdates':False,'applyAsDelete':None,'applyAsTruncate':None,'sequenceBy':None,
             'columns':None,'scdType':1,'trackHistory':None,'unread':[]}
        while pos<len(ts):
            kw=clause_at(ts,pos)
            if kw is None:
                if len(out['unread'])<32: out['unread'].append(ts[pos].text.upper()[:64])
                pos=next_clause(ts,pos+1); continue
            body=pos+len(kw); end=next_clause(ts,body)
            if kw==('STORED','AS','SCD','TYPE') and body<len(ts) and ts[body].text in ('1','2'): end=body+1
            try: read_clause(ts,out,kw,pos,body,end)
            except ParseError: out['unread'].append(' '.join(kw))
            pos=end
        return out
    def read_clause(ts,out,kw,pos,body,end):
        if kw==('IGNORE','NULL','UPDATES') and end==body: out['ignoreNullUpdates']=True
        elif kw==('STORED','AS','SCD','TYPE') and end==body+1 and ts[body].text in ('1','2'): out['scdType']=int(ts[body].text)
        elif end==body or kw in (('IGNORE','NULL','UPDATES'),('STORED','AS','SCD','TYPE')): out['unread'].append(' '.join(kw))
        elif kw in (('COLUMNS',),('TRACK','HISTORY','ON')):
            # A column list reads as a SELECT list: the clause words are rewritten in place to `SELECT`.
            key='columns' if kw==('COLUMNS',) else 'trackHistory'
            out[key]=parse(ts[pos].start,ts[end-1].end,masks=[(ts[pos].start,ts[body-1].end,'SELECT')],into=exp.Select)
        else:
            key={('KEYS',):'keys',('APPLY','AS','DELETE','WHEN'):'applyAsDelete',('APPLY','AS','TRUNCATE','WHEN'):'applyAsTruncate',('SEQUENCE','BY'):'sequenceBy'}[kw]
            out[key]=parse(ts[body].start,ts[end-1].end)
    def constraints(ts,i,j,masks,ann):
        """`CONSTRAINT name EXPECT (cond) [ON VIOLATION DROP ROW | FAIL UPDATE]` elements of the column list ts[i..j] (parentheses)."""
        parts=[]; commas=[]; depth=0; begin=i+1
        for k in range(i+1,j):
            if ts[k].token_type==T.L_PAREN: depth+=1
            elif ts[k].token_type==T.R_PAREN: depth-=1
            elif ts[k].token_type==T.COMMA and depth==0: parts.append((begin,k)); commas.append(k); begin=k+1
        parts.append((begin,j)); dropped=set()
        for index,(a,b) in enumerate(parts):
            if not (b-a>=5 and word(ts,a)=='CONSTRAINT' and named(ts[a+1]) and word(ts,a+2)=='EXPECT' and ts[a+3].token_type==T.L_PAREN): continue
            e=close(ts,a+3)
            if e is None or e>=b or e==a+4: continue
            violation={():'warn',('ON','VIOLATION','DROP','ROW'):'drop',('ON','VIOLATION','FAIL','UPDATE'):'fail'}.get(tuple(word(ts,k) for k in range(e+1,b)))
            if violation is None: continue
            ann['expectations'].append({'name':ts[a+1].text,'quoted':ts[a+1].token_type==T.IDENTIFIER,'condition':parse(ts[a+4].start,ts[e-1].end),
                'onViolation':violation,'start':ts[a].start,'end':ts[b-1].end})
            dropped.add(index); masks.append((ts[a].start,ts[b-1].end,''))
        if not dropped: return False
        if len(dropped)==len(parts): masks.append((ts[i].start,ts[j].end,'')); return True
        kept=[x for x in range(len(parts)) if x not in dropped]
        # Keep the comma after each kept element that another kept element follows; blank every other comma.
        keep={commas[kept[x]] for x in range(len(kept)-1)}
        for comma in commas:
            if comma not in keep: masks.append((ts[comma].start,ts[comma].end,''))
        return True
    def inspect(ts):
        """(masks, annotation, uses pipeline-only syntax) for one statement's tokens."""
        masks=[]; only=False
        ann={'kind':'query','dataset':None,'private':False,'temporary':False,'live':False,'once':False,'flow':None,'streams':[],'expectations':[],'cdc':None}
        blank=lambda t: masks.append((t.start,t.end,''))
        if word(ts,0) in ('AUTO','APPLY') and (word(ts,0),word(ts,1),word(ts,2)) in (('AUTO','CDC','INTO'),('APPLY','CHANGES','INTO')):
            ann['cdc']=cdc(ts,0,ann)
            if ann['cdc'] is not None: ann['kind']='auto-cdc'; return masks,ann,True
        if word(ts,0)=='CREATE':
            i=3 if word(ts,1)=='OR' and word(ts,2) in ('REFRESH','REPLACE') else 1
            while word(ts,i) in ('PRIVATE','TEMPORARY','TEMP'):
                if word(ts,i)=='PRIVATE': ann['private']=only=True; blank(ts[i])
                else: ann['temporary']=True
                i+=1
            w=(word(ts,i),word(ts,i+1),word(ts,i+2))
            if w==('STREAMING','LIVE','TABLE'): blank(ts[i+1]); ann['live']=only=True; ann['dataset']='streaming-table'; i+=3
            elif w==('INCREMENTAL','LIVE','TABLE'): masks.append((ts[i].start,ts[i].end,'STREAMING')); blank(ts[i+1]); ann['live']=only=True; ann['dataset']='streaming-table'; i+=3
            elif w[:2]==('STREAMING','TABLE'): ann['dataset']='streaming-table'; i+=2
            elif w[:2]==('MATERIALIZED','VIEW'): ann['dataset']='materialized-view'; i+=2
            elif w[:2] in (('LIVE','TABLE'),('LIVE','VIEW')):
                blank(ts[i]); ann['live']=only=True; i+=2
                if w[1]=='TABLE': ann['dataset']='materialized-view'
                else: ann['dataset']='view'; ann['temporary']=True
            elif w[0]=='FLOW' and i+1<len(ts) and named(ts[i+1]):
                n1=name_end(ts,i+1); k=n1+2
                if word(ts,n1+1)=='AS':
                    flow=parse(ts[i+1].start,ts[n1].end,into=exp.Table)
                    if (word(ts,k),word(ts,k+1))==('INSERT','INTO'):
                        masks.append((ts[0].start,ts[n1+1].end,'')); ann.update(kind='flow',flow=flow); only=True
                        if word(ts,k+2)=='ONCE': ann['once']=True; blank(ts[k+2])
                    elif (word(ts,k),word(ts,k+1),word(ts,k+2)) in (('AUTO','CDC','INTO'),('APPLY','CHANGES','INTO')):
                        ann['cdc']=cdc(ts,k,ann)
                        if ann['cdc'] is not None: ann.update(kind='auto-cdc',flow=flow); return masks,ann,True
            if ann['dataset']:
                ann['kind']='dataset'
                if (word(ts,i),word(ts,i+1),word(ts,i+2))==('IF','NOT','EXISTS'): i+=3
                if i<len(ts) and named(ts[i]):
                    i=name_end(ts,i)+1
                    if i<len(ts) and ts[i].token_type==T.L_PAREN:
                        j=close(ts,i)
                        if j is not None and constraints(ts,i,j,masks,ann): only=True
        for k,t in enumerate(ts):
            # `FROM STREAM name` (no parentheses): SQLGlot reads STREAM as the table. `STREAM(name)` parses natively.
            after=word(ts,k-1) in ('FROM','JOIN') or (k>0 and ts[k-1].token_type==T.COMMA)
            if word(ts,k)=='STREAM' and after and k+1<len(ts) and named(ts[k+1]) and word(ts,k+1)!='STREAM':
                e=name_end(ts,k+1)
                if e+1<len(ts) and ts[e+1].token_type==T.L_PAREN: e=close(ts,e+1) or e
                blank(t); ann['streams'].append({'start':ts[k+1].start,'end':ts[e].end}); only=True
            # The legacy `LIVE.` schema names this pipeline's own datasets: `LIVE.x` is read as `x`.
            if word(ts,k)=='LIVE' and k+2<len(ts) and ts[k+1].token_type==T.DOT and named(ts[k+2]) and not (k>0 and ts[k-1].token_type==T.DOT):
                masks.append((t.start,ts[k+1].end,'')); ann['live']=True
                if ann['kind']!='query': only=True
        return masks,ann,only
    chunks=[]; begin=0; current=[]
    for t in tokens:
        if t.token_type==T.SEMICOLON: chunks.append((begin,t.start-1,current)); begin=t.end+1; current=[]
        else: current.append(t)
    chunks.append((begin,len(text)-1,current))
    plans=[(start,end,ts)+inspect(ts) for start,end,ts in chunks if ts]
    if not any(only for *_,only in plans): return None
    if len(plans)>500: raise ValueError('statement-limit')
    statements=[]; budget=[0]
    for start,end,ts,masks,ann,only in plans:
        annotated=ann['kind']!='query' or ann['streams'] or ann['live']
        if ann['kind']=='auto-cdc': sdp_keep(statements,{'sdp':ann},budget); continue
        for tree in parse(start,end,masks=masks,many=True): sdp_keep(statements,{'tree':tree,'sdp':ann} if annotated else {'tree':tree},budget)
    return statements

def analyze(request):
    import logging
    logging.getLogger('sqlglot').disabled=True
    import sqlglot
    from sqlglot.errors import ParseError
    if sys.version_info[:3]!=(3,13,15) or sqlglot.__version__!='30.19.0': raise ValueError('runtime-version')
    captures=request['captures']
    if not isinstance(captures,list) or len(captures)>500: raise ValueError('capture-limit')
    facts=[]; total=0
    for source in captures:
        if source['language']=='notebook':
            cells=source['cells']
            if not isinstance(cells,list) or len(cells)>10000: raise ValueError('notebook-cell-limit')
            projected=[]; notebook_bytes=0
            for cell in cells:
                raw=cell['text'].encode('utf-8'); notebook_bytes+=len(raw)
                binding=cell['binding']
                if len(raw)>2*1024*1024 or notebook_bytes>10*1024*1024: raise ValueError('notebook-source-limit')
                if hashlib.sha256(raw).hexdigest()!=binding['cellSourceDigest']['value']: raise ValueError('cell-digest')
                language=cell['language'].lower()
                output={'binding':binding,'language':cell['language']}
                if cell['kind']!='code': output.update(status='not-code',syntaxFacts=None)
                elif language not in ('python','pyspark','sql','tsql'): output.update(status='unsupported-language',syntaxFacts=None)
                elif language in ('sql','tsql') and cell.get('dialect') not in ('tsql','spark'): output.update(status='unsupported-dialect',syntaxFacts=None)
                else:
                    item={'artifactId':source['artifactId'],'text':cell['text'],'integrityDigest':binding['cellSourceDigest']['value'],
                          'language':'python' if language in ('python','pyspark') else 'sql','dialect':cell.get('dialect')}
                    output.update(status='syntax-facts',syntaxFacts=analyze({'captures':[item]})[0])
                projected.append(output)
            total+=notebook_bytes
            if total>50*1024*1024: raise ValueError('source-limit')
            facts.append({'schema':'datapass.notebook-syntax-facts/1','kind':'notebook','artifactId':source['artifactId'],
                          'integrityDigest':{'algorithm':'sha256','mode':'exact-bytes','value':source['integrityDigest']},
                          'semanticDigest':source['semanticDigest'],'cells':projected})
            continue
        text=source['text']; raw=text.encode('utf-8'); total+=len(raw)
        if len(raw)>2*1024*1024 or total>50*1024*1024: raise ValueError('source-limit')
        if hashlib.sha256(raw).hexdigest()!=source['integrityDigest']: raise ValueError('source-digest')
        item={'artifactId':source['artifactId'],'integrityDigest':{'algorithm':'sha256','mode':'exact-bytes','value':source['integrityDigest']}}
        dialect=source.get('dialect')
        if source['language']=='sql':
            if dialect not in ('tsql','spark'): raise ValueError('unsupported-dialect')
            item.update(schema='datapass.sql-syntax-facts/1',dialect=dialect,parserVersion=sqlglot.__version__)
        elif source['language']=='python': item.update(schema='datapass.python-syntax-facts/1',parserVersion='3.13.15',offsetEncoding='utf-8-line-bytes')
        try:
            if source['language']=='sql':
                trees=sql_statements(text,dialect)  # raises statement-limit / syntax-node-limit while dumping
                item.update(kind='sqlglot',statements=trees)
            elif source['language']=='python':
                item.update(kind='python-ast',parserVersion='3.13.15',tree=python_tree(GUARD.parse(text)))
            else: raise ValueError('unsupported-language')
        except ParseError as error:
            item.update(kind='parse-error',diagnostics=[{'line':e.get('line',1),'column':e.get('col',1),
                'description':'SQL syntax rejected'} for e in error.errors[:32]])
        except SyntaxError as error:
            line=error.lineno or 1; lines=text.splitlines(); column=error.offset or 1
            if 0<line<=len(lines): column=len(lines[line-1][:max(0,column-1)].encode('utf-8'))+1
            item.update(kind='parse-error',diagnostics=[{'line':line,'column':column,
                'description':'Python syntax rejected'}])
        facts.append(item)
    return facts

INPUT_LIMITS=('source-limit','capture-limit','notebook-source-limit','notebook-cell-limit')

def main():
    import msvcrt
    context=read_frame(16*1024*1024)
    containment=context.get('containment','lpac')
    probe=context.get('probe')
    if containment not in ('lpac','trusted-local-host-only') or (probe is not None and probe not in PROBES): raise ValueError('context')
    ready=msvcrt.open_osfhandle(int(context['readyHandle']),os.O_WRONLY)
    scrub_environment(); warm_up()
    # No captured source is parsed until all access and child/network checks pass.
    reason=preflight(context)
    sys.addaudithook(GUARD.hook); GUARD.arm()
    # The controller tightens the Job Object (commit, CPU) on this byte, then sends the request.
    os.write(ready,b'R' if reason is None else b'X'); os.close(ready)
    request=read_frame(FRAME_LIMIT)
    reply={key:request[key] for key in ('requestId','generation','requestDigest')}
    reply['containment']=containment
    if reason: reply.update(status='unavailable',code=reason)
    else:
        try:
            if probe:
                run_probe(probe); reply.update(status='unavailable',code='probe-not-refused')
            else: reply.update(status='syntax-facts',facts=analyze(request),policy='local-static-parser-v1')
        except ContainmentRefused as error: reply.update(status='unavailable',code=error.code)
        except MemoryError: reply.update(status='unavailable',code='memory-limit')
        except (ValueError,RecursionError) as error:
            reply.update(status='unavailable',code='input-limit' if str(error) in INPUT_LIMITS else 'syntax-resource-or-input-limit')
        # A refusal swallowed by library code still fails the whole request.
        if GUARD.refused:
            for key in ('facts','policy'): reply.pop(key,None)
            reply.update(status='unavailable',code=GUARD.refused)
    output=json.dumps(reply,ensure_ascii=True,allow_nan=False,separators=(',',':')).encode('utf-8')
    if len(output)>OUTPUT_LIMIT:
        reply={key:request[key] for key in ('requestId','generation','requestDigest')}
        reply.update(status='unavailable',code='syntax-output-limit',containment=containment); output=json.dumps(reply).encode('utf-8')
    sys.stdout.buffer.write(struct.pack('<I',len(output))+output); sys.stdout.buffer.flush()

if __name__=='__main__': main()
