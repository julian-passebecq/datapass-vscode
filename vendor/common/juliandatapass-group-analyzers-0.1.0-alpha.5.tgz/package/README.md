# Trusted analyzer dispatcher

This headless A0 candidate accepts only installed plugin objects. It performs no module loading, filesystem access, source execution or network access. C2b owns validation and source identities; host A0H owns worker isolation, timers and actual termination.

`createAnalyzerDispatcher(plugins, clock)` supports two concurrent tasks and at most 32 outstanding requests, with 100 MiB total serialized UTF-16 captures retained across queued and active requests. `dispatch(projectId, request, captures)` validates and copies inputs, pins plugin identity/version/parser digest/dialect, and returns a result promise plus an explicit cancellation method. A queued cancellation starts no plugin. An active cancellation keeps its slot occupied until host cleanup settles. Host cleanup must be bounded; an uncooperative host cannot be forcibly terminated by a headless library.

The in-memory cache is bounded by serialized UTF-16 size (default 8 MiB). It is separated by project, full protocol cache key and exact source digests. Cached responses are copied, rebound and validated against fresh captures; no persisted cache or imported cache authority exists. Parser errors, malformed results and cancellations are not cached. Cache memory can contain source snippets from parser output; it is not a redaction layer.

Plugins return one terminal response only after owned worker resources are released. Validated request-bound progress and explicit parser-support manifests are available. Dependency/link-phase orchestration and A0H adapter conformance remain to be implemented; this candidate does not claim full A0 completion. The dispatcher test plugin is a synthetic protocol fixture.

Parser support manifests distinguish parse/link phases, syntax-only/supplied-only context and supported/unsupported/unknown syntax. Supported entries require corpus references; qualified platforms require an evidence reference. These references are declarations for review, not authenticated proof or permission to launch a runtime.

## Bounded SQL adapter

The `@juliandatapass-group/analyzers/sql` entry point exports `createSqlAnalyzerPlugin({ parserLockDigest, provider })`, `analyzeSqlFacts`, validated syntax-facts types and `SQL_SUPPORT`. The plugin accepts only explicit `tsql`, SQLGlot 30.19.0 facts from an installed trusted provider. The provider owns resource cleanup and containment; a missing provider returns `tool-unavailable` with no lineage. No Python, SQL or catalog execution occurs in this package. `SQL_NO_RULE_EVALUATION_DIGEST` explicitly identifies the absence of rule evaluation; DQ1 owns a real rule catalog.

SELECT/alias/CTE/subquery, basic joins/projections/predicates/aggregates and bounded INSERT/CTAS mappings have a fixed synthetic oracle. Unknown schemas, stars, dynamic SQL and unsupported forms remain coverage gaps. Names retain spelling and quoting; cross-file catalog linking and database collation are unqualified. See [SQL qualification evidence](https://gitlab.com/juliandatapass-group/datapass-vscode-common/-/blob/v4/common-sql-adapter/packages/analyzers/qualification/sql/README.md) for pins, provenance, comparison observations and remaining L0/A1 obligations. Snapshot or AI authority is unchanged.
