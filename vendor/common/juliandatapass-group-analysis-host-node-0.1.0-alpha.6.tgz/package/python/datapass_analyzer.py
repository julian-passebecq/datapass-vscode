"""Trusted static syntax worker. No source execution, imports, evaluation or SQL connection."""
import ast, ctypes as c, hashlib, json, os, socket, struct, subprocess, sys, winreg
from ctypes import wintypes as w

FRAME_LIMIT=320*1024*1024
OUTPUT_LIMIT=48*1024*1024
AST_FILENAME='<datapass-static-ast>'
ALLOWED_ENV=frozenset(k.upper() for k in ('SystemRoot','WINDIR','SystemDrive','USERPROFILE','LOCALAPPDATA','APPDATA','TEMP','TMP'))
PROBES=('memory','cpu','time','subprocess','network','file-write','import','exec')

class ContainmentRefused(BaseException):
    """BaseException so library `except Exception` blocks cannot swallow a refusal."""
    def __init__(self,code): super().__init__(code); self.code=code

class Guard:
    """PY1C parse-only guard. Installed after warm-up; an audit hook cannot be removed."""
    def __init__(self): self.armed=False; self.permit=None; self.refused=None; self.temp=None
    def refuse(self,code):
        if self.refused is None: self.refused=code
        raise ContainmentRefused(code)
    def parse(self,text):
        # The only compile allowed: ast.parse of the current captured text, AST-only flag.
        # CPython reports the source to the audit hook as UTF-8 bytes.
        self.permit=(text,text.encode('utf-8','surrogatepass'))
        try: return ast.parse(text,filename=AST_FILENAME)
        finally: self.permit=None
    def hook(self,event,args):
        if not self.armed: return
        if event=='compile':
            if args[1]==AST_FILENAME and self.permit is not None and args[0] in self.permit: return
            self.refuse('code-execution-refused')
        if event in ('exec','code.__new__','function.__new__','marshal.loads','marshal.load','pickle.find_class','builtins.breakpoint','sys.addaudithook','cpython.run_command','cpython.run_file','cpython.run_module'):
            self.refuse('code-execution-refused')
        if event=='import': self.refuse('import-refused')
        if event.startswith('socket.'): self.refuse('network-refused')
        if event in ('subprocess.Popen','os.system','os.exec','os.spawn','os.posix_spawn','os.startfile','os.fork','os.forkpty','_winapi.CreateProcess','os.kill','signal.pthread_kill'):
            self.refuse('child-process-refused')
        if event.startswith('ctypes.') or event.startswith('winreg.') or event=='_winapi.CreateNamedPipe': self.refuse('native-call-refused')
        if event in ('os.remove','os.rename','os.rmdir','os.mkdir','os.chmod','os.link','os.symlink','os.truncate','os.utime','shutil.rmtree','shutil.copyfile','shutil.move','os.chown'):
            self.refuse('file-write-refused')
        if event=='open':
            path,mode,flags=args[0],args[1],args[2]
            writing=(isinstance(mode,str) and any(ch in mode for ch in 'wax+')) or (isinstance(flags,int) and flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_APPEND|os.O_TRUNC))
            if writing and not self.inside_temp(path): self.refuse('file-write-refused')
    def inside_temp(self,path):
        if not self.temp or not isinstance(path,(str,bytes)): return False
        path=os.fsdecode(path)
        try: return os.path.commonpath([os.path.normcase(os.path.abspath(path)),self.temp])==self.temp
        except ValueError: return False
    def arm(self):
        temp=os.environ.get('TEMP')
        self.temp=os.path.normcase(os.path.abspath(temp)) if temp else None
        self.armed=True

GUARD=Guard()

def scrub_environment():
    """Env scrubbed to the controller allowlist; sys.path frozen to the runtime directory only."""
    for key in [k for k in os.environ if k.upper() not in ALLOWED_ENV]: del os.environ[key]
    runtime=os.path.dirname(os.path.abspath(sys.executable))
    sys.path[:]=[p for p in sys.path if os.path.normcase(os.path.abspath(p)).startswith(os.path.normcase(runtime))]
    sys.path_importer_cache.clear()
    return {'environment':sorted(os.environ),'sysPath':len(sys.path)}

def warm_up():
    """Load every module the parse path can need before the import freeze."""
    import logging, re, encodings.utf_8, encodings.ascii
    logging.getLogger('sqlglot').disabled=True
    import sqlglot, sqlglot.dialects.tsql, sqlglot.dialects.spark
    from sqlglot.errors import ParseError
    for dialect in ('tsql','spark'):
        for text in ('SELECT a.b AS c FROM d.e AS a JOIN f ON a.x=f.x WHERE a.y>1 GROUP BY a.b','SELECT ( FROM'):
            try: [s.dump() for s in sqlglot.parse(text,read=dialect) if s is not None]
            except ParseError: pass
    python_tree(ast.parse('import a\nx: int = f(1, *y, k=2)[0].z\nasync def g():\n    await h()\n',filename=AST_FILENAME))
    try: ast.parse('def (',filename=AST_FILENAME)
    except SyntaxError as error: str(error)
    json.dumps(json.loads('{"a":[1,2.5,"\\u00e9",null,true]}'),ensure_ascii=True,allow_nan=False,separators=(',',':'))
    try: bytearray(1)
    except MemoryError: pass

def run_probe(name):
    """Fixed qualification attempts. Each must be refused by the OS, the Job Object or the guard."""
    if name=='memory': return len(bytearray(64*1024*1024))
    if name=='cpu':
        while True: pass
    if name=='time':
        import time; time.sleep(30)
    if name=='subprocess': return subprocess.run([sys.executable,'-c','pass'],timeout=1)
    if name=='network': return socket.socket(socket.AF_INET,socket.SOCK_STREAM).connect(('127.0.0.1',9))
    if name=='file-write':
        with open(os.path.join(os.path.dirname(os.path.abspath(sys.executable)),'py1c-probe-write.txt'),'w') as stream: stream.write('refused')
    if name=='import': import xmlrpc.client
    if name=='exec': exec('1')
    return None

def exact(count):
    chunks=[]
    while count:
        piece=sys.stdin.buffer.read(min(count,65536))
        if not piece: raise ValueError('truncated-frame')
        chunks.append(piece); count-=len(piece)
    return b''.join(chunks)

def read_frame(limit):
    size=struct.unpack('<I',exact(4))[0]
    if not 0<size<=limit: raise ValueError('frame-limit')
    return json.loads(exact(size))

def preflight(context):
    if context.get('policy')!='local-static-parser-v1': return 'unknown-policy'
    kernel=c.WinDLL('kernel32',use_last_error=True)
    create=kernel.CreateFileW
    create.argtypes=[w.LPCWSTR,w.DWORD,w.DWORD,c.c_void_p,w.DWORD,w.DWORD,c.c_void_p]
    create.restype=c.c_void_p
    close=kernel.CloseHandle; close.argtypes=[c.c_void_p]; close.restype=w.BOOL
    if context.get('containment')=='trusted-local-host-only':
        # No AppContainer token: the Job Object and the guard still refuse children,
        # but selected-root, registry and socket denial cannot be proved here.
        try:
            subprocess.run([sys.executable,'-I','-S','-c','pass'],timeout=1,check=False,
                           stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            return 'child-process-allowed'
        except OSError as error:
            if error.winerror not in (367,1816): return 'child-denial-unknown'
        except subprocess.TimeoutExpired: return 'child-process-allowed'
        return None
    # A write attempt next to the runtime must be denied to the LPAC token.
    probe=os.path.join(os.path.dirname(os.path.abspath(sys.executable)),'py1c-write-denied.probe')
    handle=create(probe,0x40000000,0,None,1,0x04000000,None)
    if handle!=c.c_void_p(-1).value:
        close(handle); return 'runtime-writable'
    if c.get_last_error()!=5: return 'write-denial-unknown'
    # READ_DATA for files / LIST_DIRECTORY for directories. Never read content.
    for path in context['paths']:
        handle=create(path,1,7,None,3,0x02000000,None)
        if handle!=c.c_void_p(-1).value:
            close(handle); return 'selected-root-readable'
        if c.get_last_error()!=5: return 'selected-root-access-unknown'
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,context['registryKey'],0,winreg.KEY_QUERY_VALUE):
            return 'hkcu-canary-readable'
    except OSError as error:
        if error.winerror!=5: return 'hkcu-access-unknown'
    try:
        connection=socket.socket(); connection.close(); return 'network-socket-allowed'
    except OSError as error:
        if error.winerror!=10013: return 'network-denial-unknown'
    try:
        subprocess.run([sys.executable,'-I','-S','-c','pass'],timeout=1,check=False,
                       stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        return 'child-process-allowed'
    except OSError as error:
        if error.winerror!=367: return 'child-denial-unknown'
    except subprocess.TimeoutExpired: return 'child-process-allowed'
    return None

def python_tree(node,depth=0,budget=None):
    if budget is None: budget=[0]
    if depth>128: raise ValueError('syntax-depth-limit')
    budget[0]+=1
    if budget[0]>50000: raise ValueError('syntax-node-limit')
    if isinstance(node,ast.AST):
        result={'nodeType':type(node).__name__,'fields':{}}
        for key,value in ast.iter_fields(node): result['fields'][key]=python_tree(value,depth+1,budget)
        for key in ('lineno','col_offset','end_lineno','end_col_offset'):
            if hasattr(node,key): result[key]=getattr(node,key)
        return result
    if isinstance(node,list): return [python_tree(value,depth+1,budget) for value in node]
    if isinstance(node,int) and not isinstance(node,bool) and abs(node)>9007199254740991:
        return {'literalKind':'int','decimal':str(node)}
    if node is None or isinstance(node,(str,bool,int)): return node
    # JSON cannot losslessly encode complex/bytes/ellipsis/non-finite Python constants.
    if isinstance(node,float) and node==node and abs(node)!=float('inf'): return node
    return {'literalKind':type(node).__name__}

def analyze(request):
    import logging
    logging.getLogger('sqlglot').disabled=True
    import sqlglot
    from sqlglot.errors import ParseError
    if sys.version_info[:3]!=(3,13,15) or sqlglot.__version__!='30.19.0': raise ValueError('runtime-version')
    captures=request['captures']
    if not isinstance(captures,list) or len(captures)>500: raise ValueError('capture-limit')
    facts=[]; total=0
    for source in captures:
        if source['language']=='notebook':
            cells=source['cells']
            if not isinstance(cells,list) or len(cells)>10000: raise ValueError('notebook-cell-limit')
            projected=[]; notebook_bytes=0
            for cell in cells:
                raw=cell['text'].encode('utf-8'); notebook_bytes+=len(raw)
                binding=cell['binding']
                if len(raw)>2*1024*1024 or notebook_bytes>10*1024*1024: raise ValueError('notebook-source-limit')
                if hashlib.sha256(raw).hexdigest()!=binding['cellSourceDigest']['value']: raise ValueError('cell-digest')
                language=cell['language'].lower()
                output={'binding':binding,'language':cell['language']}
                if cell['kind']!='code': output.update(status='not-code',syntaxFacts=None)
                elif language not in ('python','pyspark','sql','tsql'): output.update(status='unsupported-language',syntaxFacts=None)
                elif language in ('sql','tsql') and cell.get('dialect') not in ('tsql','spark'): output.update(status='unsupported-dialect',syntaxFacts=None)
                else:
                    item={'artifactId':source['artifactId'],'text':cell['text'],'integrityDigest':binding['cellSourceDigest']['value'],
                          'language':'python' if language in ('python','pyspark') else 'sql','dialect':cell.get('dialect')}
                    output.update(status='syntax-facts',syntaxFacts=analyze({'captures':[item]})[0])
                projected.append(output)
            total+=notebook_bytes
            if total>50*1024*1024: raise ValueError('source-limit')
            facts.append({'schema':'datapass.notebook-syntax-facts/1','kind':'notebook','artifactId':source['artifactId'],
                          'integrityDigest':{'algorithm':'sha256','mode':'exact-bytes','value':source['integrityDigest']},
                          'semanticDigest':source['semanticDigest'],'cells':projected})
            continue
        text=source['text']; raw=text.encode('utf-8'); total+=len(raw)
        if len(raw)>2*1024*1024 or total>50*1024*1024: raise ValueError('source-limit')
        if hashlib.sha256(raw).hexdigest()!=source['integrityDigest']: raise ValueError('source-digest')
        item={'artifactId':source['artifactId'],'integrityDigest':{'algorithm':'sha256','mode':'exact-bytes','value':source['integrityDigest']}}
        dialect=source.get('dialect')
        if source['language']=='sql':
            if dialect not in ('tsql','spark'): raise ValueError('unsupported-dialect')
            item.update(schema='datapass.sql-syntax-facts/1',dialect=dialect,parserVersion=sqlglot.__version__)
        elif source['language']=='python': item.update(schema='datapass.python-syntax-facts/1',parserVersion='3.13.15',offsetEncoding='utf-8-line-bytes')
        try:
            if source['language']=='sql':
                statements=sqlglot.parse(text,read=dialect)
                if len(statements)>500: raise ValueError('statement-limit')
                trees=[]; nodes=0
                for statement in statements:
                    if statement is None: continue
                    tree=statement.dump(); nodes+=len(tree)
                    if nodes>50000: raise ValueError('syntax-node-limit')
                    trees.append({'tree':tree})
                item.update(kind='sqlglot',statements=trees)
            elif source['language']=='python':
                item.update(kind='python-ast',parserVersion='3.13.15',tree=python_tree(GUARD.parse(text)))
            else: raise ValueError('unsupported-language')
        except ParseError as error:
            item.update(kind='parse-error',diagnostics=[{'line':e.get('line',1),'column':e.get('col',1),
                'description':'SQL syntax rejected'} for e in error.errors[:32]])
        except SyntaxError as error:
            line=error.lineno or 1; lines=text.splitlines(); column=error.offset or 1
            if 0<line<=len(lines): column=len(lines[line-1][:max(0,column-1)].encode('utf-8'))+1
            item.update(kind='parse-error',diagnostics=[{'line':line,'column':column,
                'description':'Python syntax rejected'}])
        facts.append(item)
    return facts

INPUT_LIMITS=('source-limit','capture-limit','notebook-source-limit','notebook-cell-limit')

def main():
    import msvcrt
    context=read_frame(16*1024*1024)
    containment=context.get('containment','lpac')
    probe=context.get('probe')
    if containment not in ('lpac','trusted-local-host-only') or (probe is not None and probe not in PROBES): raise ValueError('context')
    ready=msvcrt.open_osfhandle(int(context['readyHandle']),os.O_WRONLY)
    scrub_environment(); warm_up()
    # No captured source is parsed until all access and child/network checks pass.
    reason=preflight(context)
    sys.addaudithook(GUARD.hook); GUARD.arm()
    # The controller tightens the Job Object (commit, CPU) on this byte, then sends the request.
    os.write(ready,b'R' if reason is None else b'X'); os.close(ready)
    request=read_frame(FRAME_LIMIT)
    reply={key:request[key] for key in ('requestId','generation','requestDigest')}
    reply['containment']=containment
    if reason: reply.update(status='unavailable',code=reason)
    else:
        try:
            if probe:
                run_probe(probe); reply.update(status='unavailable',code='probe-not-refused')
            else: reply.update(status='syntax-facts',facts=analyze(request),policy='local-static-parser-v1')
        except ContainmentRefused as error: reply.update(status='unavailable',code=error.code)
        except MemoryError: reply.update(status='unavailable',code='memory-limit')
        except (ValueError,RecursionError) as error:
            reply.update(status='unavailable',code='input-limit' if str(error) in INPUT_LIMITS else 'syntax-resource-or-input-limit')
        # A refusal swallowed by library code still fails the whole request.
        if GUARD.refused:
            for key in ('facts','policy'): reply.pop(key,None)
            reply.update(status='unavailable',code=GUARD.refused)
    output=json.dumps(reply,ensure_ascii=True,allow_nan=False,separators=(',',':')).encode('utf-8')
    if len(output)>OUTPUT_LIMIT:
        reply={key:request[key] for key in ('requestId','generation','requestDigest')}
        reply.update(status='unavailable',code='syntax-output-limit',containment=containment); output=json.dumps(reply).encode('utf-8')
    sys.stdout.buffer.write(struct.pack('<I',len(output))+output); sys.stdout.buffer.flush()

if __name__=='__main__': main()
