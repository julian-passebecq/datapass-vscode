// PY1C containment proof: hostile-shaped inputs are parsed, never run; fixed probes are refused and typed.
// Usage: node qualify-containment.mjs <manifest.json> <reviewed-sha256> [record.json]
import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir, access, rm } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname, join, resolve } from 'node:path';
import { release } from 'node:os';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { StaticSyntaxHost, createWindowsPathInspector } = require('../dist/cjs/index.cjs');
const { runContainmentProbe, CONTAINMENT_PROBES } = require('../dist/cjs/controller.cjs');
const core = require('@juliandatapass-group/semantic-core');
const { ANALYSIS_LIMITS } = require('@juliandatapass-group/analysis-protocol');
const manifestPath = resolve(process.argv[2]); const manifestBytes = await readFile(manifestPath);
const sha = value => createHash('sha256').update(value).digest('hex');
assert.equal(sha(manifestBytes), process.argv[3]);
const artifact = dirname(manifestPath);
const selectedRoot = join(artifact, 'py1c-root'); await rm(selectedRoot, { recursive: true, force: true }); await mkdir(selectedRoot);
const canary = join(artifact, 'py1c-client-code-executed.txt');
const policyFor = containment => ({ selectedRoot, securityPolicy: 'local-static-parser-v1', containment, runtimeDirectory: join(artifact, 'runtime'), manifestBytes,
  expectedManifestSha256: sha(manifestBytes), cachePolicy: { cacheRoot: artifact, nativePathInspector: createWindowsPathInspector(process.env.SystemRoot) }, systemRoot: process.env.SystemRoot });
const canaryLiteral = JSON.stringify(canary);
// Authored synthetic inputs; each would reach the canary or the network if it were ever executed.
const inputs = {
  'oversize': 'x = 1\n'.repeat(330000),
  'infinite-loop': 'while True:\n    pass\n',
  'fork-subprocess': `import os, subprocess\nos.fork()\nsubprocess.run(['cmd', '/c', 'echo x > ' + ${canaryLiteral}])\n`,
  'network': "import socket\nsocket.create_connection(('127.0.0.1', 9)).sendall(b'x')\n",
  'file-write': `open(${canaryLiteral}, 'w').write('executed')\n`,
  'import-exec': `import importlib\nimportlib.import_module('antigravity')\nexec(compile('open(' + repr(${canaryLiteral}) + ', "w")', 'x', 'exec'))\n`,
};
let generation = 0;
async function parse(host, name) {
  const text = inputs[name]; const path = name + '.py'; await writeFile(join(selectedRoot, path), text);
  const snapshots = [{ artifactId: path, path, kind: 'file', byteLength: Buffer.byteLength(text), integrityDigest: core.unwrap(core.digestExactBytes(Buffer.from(text))), semanticDigest: null }];
  const options = { dialect: 'python', resolutionPolicy: 'syntax-only' }; const digest = core.unwrap(core.digestJson(options));
  const request = { schema: 'datapass.analysis-wire/1', kind: 'request', requestId: 'py1c', generation: ++generation, options, limits: ANALYSIS_LIMITS, snapshotManifest: snapshots,
    header: { schemaVersion: 'datapass.analysis-wire/1', engineVersion: 'qualification', producer: { pluginId: 'qualification', version: '1', parserLockDigest: digest },
      configDigest: digest, ruleCatalogDigest: digest, supportedManifestVersion: 'datapass.snapshot-manifest/1', snapshotId: 'py1c-synthetic',
      sourceDigests: snapshots.map(({ artifactId, integrityDigest, semanticDigest }) => ({ artifactId, integrityDigest, semanticDigest })), dependencyDigests: [] } };
  const started = Date.now();
  const result = await host.analyze(request);
  const elapsedMs = Date.now() - started;
  await assert.rejects(access(canary), `${name} executed client code`);
  return { name, bytes: Buffer.byteLength(text), status: result.status, code: result.code ?? null, containment: result.containment ?? null,
    kind: result.facts?.[0]?.kind ?? null, elapsedMs };
}
const record = { schema: 'datapass.py1c-containment-qualification/1', manifestSha256: sha(manifestBytes), windowsBuild: release(), node: process.versions.node,
  budget: { commitMiBAboveWarmBaseline: 25, userCpuMs: 2000, parseWallMs: 2000, activeProcesses: 1, childProcesses: 0 }, inputs: {}, probes: {} };
for (const containment of ['lpac-required', 'trusted-local-host-only']) {
  const host = new StaticSyntaxHost(policyFor(containment));
  const inputResults = []; const probeResults = [];
  try {
    for (const name of Object.keys(inputs)) inputResults.push(await parse(host, name));
  } finally { await host.dispose(); }
  for (const probe of CONTAINMENT_PROBES) {
    const started = Date.now(); const result = await runContainmentProbe(policyFor(containment), probe);
    probeResults.push({ ...result, elapsedMs: Date.now() - started });
  }
  record.inputs[containment] = inputResults; record.probes[containment] = probeResults;
}
await rm(selectedRoot, { recursive: true, force: true });
// Expectations: oversize is refused by the commit budget; every other input is parsed, not run.
const expectedProbe = { memory: 'memory-limit', cpu: 'cpu-limit', time: 'time-limit', subprocess: 'child-process-refused', network: 'network-refused',
  'file-write': 'file-write-refused', import: 'import-refused', exec: 'code-execution-refused' };
const failures = [];
for (const [containment, results] of Object.entries(record.inputs)) {
  const status = containment === 'lpac-required' ? 'lpac-job-object' : 'trusted-local-host-only';
  for (const item of results) {
    const ok = item.name === 'oversize' ? item.status === 'unavailable' && item.code === 'memory-limit'
      : item.status === 'syntax-facts' && item.kind === 'python-ast' && item.containment === status;
    if (!ok) failures.push(`${containment}/${item.name}: ${item.status}/${item.code}`);
  }
}
for (const [containment, results] of Object.entries(record.probes)) {
  for (const item of results) if (item.code !== expectedProbe[item.probe]) failures.push(`${containment}/probe ${item.probe}: ${item.code}`);
}
record.passed = failures.length === 0; record.failures = failures;
const text = JSON.stringify(record, null, 2) + '\n';
await writeFile(join(artifact, 'py1c-containment-result.json'), text);
if (process.argv[4]) await writeFile(resolve(process.argv[4]), text);
console.log(JSON.stringify({ passed: record.passed, failures }));
process.exitCode = record.passed ? 0 : 1;
