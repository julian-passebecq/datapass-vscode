// Synthetic corpus only; no expected oracle is passed to the worker.
import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash, randomUUID } from 'node:crypto';
import { dirname, join, resolve } from 'node:path';
import { createRequire } from 'node:module';
const require=createRequire(import.meta.url);
const { runProcess }=require('../dist/cjs/process.cjs');
const { verifyRuntime, createWindowsPathInspector, encodeFrame, FrameDecoder }=require('../dist/cjs/index.cjs');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const manifestPath=resolve(process.argv[2] ?? '');
const manifestBytes=await readFile(manifestPath);
if(sha(manifestBytes)!==process.argv[3]) throw new Error('Reviewed manifest SHA required');
const corpusBytes=await readFile(resolve(process.argv[4] ?? ''));
if(sha(corpusBytes)!=='4ed5db512cb32b79cfc94984e51febf7b898493471359b9b5a460f5d6b398847') throw new Error('Unreviewed synthetic corpus');
const corpus=JSON.parse(corpusBytes);
const runtime=join(dirname(manifestPath),'runtime');
await verifyRuntime({cacheRoot:dirname(manifestPath),nativePathInspector:createWindowsPathInspector(process.env.SystemRoot)},runtime,manifestBytes,sha(manifestBytes));
const selectedRoot=join(dirname(manifestPath),'owned-selected-root'); await mkdir(selectedRoot,{recursive:true});
for(const item of corpus.cases) await writeFile(join(selectedRoot,item.id+'.sql'),item.source);
const captures=corpus.cases.map(item=>({artifactId:item.id,language:'sql',dialect:'tsql',text:item.source,integrityDigest:sha(Buffer.from(item.source))}));
const request={requestId:'synthetic-sql-corpus',generation:1,requestDigest:sha(Buffer.from(JSON.stringify(captures))),captures};
const profile='DataPass.Analysis.'+randomUUID().replaceAll('-','');
const env={SystemRoot:process.env.SystemRoot,WINDIR:process.env.SystemRoot};
for(const key of ['SystemDrive','USERPROFILE','LOCALAPPDATA','APPDATA','TEMP','TMP']) if(process.env[key]) env[key]=process.env[key];
const base={executable:join(runtime,'pythonw.exe'),cwd:runtime,env,timeoutMs:30000,maxStdoutBytes:48*1024*1024,maxStderrBytes:4096};
let response;
try {
  response=await runProcess({...base,args:['-I','-S','-B',join(runtime,'datapass_controller.py'),'analysis',profile,'5000','256',selectedRoot],input:encodeFrame(request,320*1024*1024)});
} finally {
  await runProcess({...base,args:['-I','-S','-B',join(runtime,'datapass_controller.py'),'cleanup',profile,'5000','256'],input:Buffer.alloc(0)});
}
const decoder=new FrameDecoder(48*1024*1024,1); const frames=decoder.push(response.stdout); decoder.finish();
assert.equal(frames.length,1);
assert.equal(frames[0].requestDigest,request.requestDigest);
await writeFile(join(dirname(manifestPath),'syntax-result.json'),JSON.stringify({manifestSha256:sha(manifestBytes),corpusSha256:sha(corpusBytes),windowsBuild:'26200',result:frames[0]},null,2)+'\n');
console.log(JSON.stringify({status:frames[0].status,code:frames[0].code,facts:frames[0].facts?.length,resultPath:join(dirname(manifestPath),'syntax-result.json')}));
assert.equal(frames[0].status,'syntax-facts');
