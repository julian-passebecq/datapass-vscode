// Explicit Spark SQL static profile. No Spark runtime, SQL execution or provider calls.
import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname, join, resolve } from 'node:path';
import { createRequire } from 'node:module';
const require=createRequire(import.meta.url);
const { StaticSyntaxHost, createWindowsPathInspector }=require('../dist/cjs/index.cjs');
const core=require('@juliandatapass-group/semantic-core');
const { ANALYSIS_LIMITS }=require('@juliandatapass-group/analysis-protocol');
const manifestPath=resolve(process.argv[2]); const manifestBytes=await readFile(manifestPath);
const sha=value=>createHash('sha256').update(value).digest('hex'); assert.equal(sha(manifestBytes),process.argv[3]);
const selectedRoot=join(dirname(manifestPath),'owned-spark-profile'); await mkdir(selectedRoot,{recursive:true});
await writeFile(join(selectedRoot,'harmless-canary.txt'),'owned denied-read canary');
const source='SELECT o.`order id`, explode(o.items) AS item FROM delta.`orders` o';
const raw=JSON.stringify({cells:[{id:'spark',cell_type:'code',source:[source],metadata:{},outputs:[],execution_count:null}],metadata:{},nbformat:4,nbformat_minor:5});
const projection=metadata=>({splitterVersion:'synthetic-jupyter/1',analysisMetadata:metadata,cells:[{cellId:'spark',kind:'code',language:'sql',exactSourceText:source}]});
const captures=[{artifactId:'literal-child',text:source,notebookProjection:null},{artifactId:'explicit',text:raw,notebookProjection:projection({sqlDialect:'spark'})},
  {artifactId:'ambiguous',text:raw,notebookProjection:projection({})}];
const snapshots=captures.map((capture,index)=>({artifactId:capture.artifactId,path:index===0?'literal.sql':capture.artifactId+'.ipynb',kind:index===0?'file':'notebook',
  byteLength:Buffer.byteLength(capture.text),integrityDigest:core.unwrap(core.digestExactBytes(Buffer.from(capture.text))),
  semanticDigest:index===0?null:core.unwrap(core.digestNotebookSource(capture.notebookProjection))}));
const options={dialect:'spark',resolutionPolicy:'syntax-only'}; const digest=core.unwrap(core.digestJson(options));
const request={schema:'datapass.analysis-wire/1',kind:'request',requestId:'spark-profile',generation:1,snapshotManifest:snapshots,options,limits:ANALYSIS_LIMITS,
  header:{schemaVersion:'datapass.analysis-wire/1',engineVersion:'fixture',producer:{pluginId:'fixture',version:'1',parserLockDigest:digest},configDigest:digest,ruleCatalogDigest:digest,
    supportedManifestVersion:'datapass.snapshot-manifest/1',snapshotId:'spark-fixture',sourceDigests:snapshots.map(({artifactId,integrityDigest,semanticDigest})=>({artifactId,integrityDigest,semanticDigest})),dependencyDigests:[]}};
const host=new StaticSyntaxHost({selectedRoot,securityPolicy:'local-static-parser-v1',runtimeDirectory:join(dirname(manifestPath),'runtime'),manifestBytes,
  expectedManifestSha256:sha(manifestBytes),cachePolicy:{cacheRoot:dirname(manifestPath),nativePathInspector:createWindowsPathInspector(process.env.SystemRoot)},systemRoot:process.env.SystemRoot});
let facts; let pythonFacts;
try {
  const task=host.startCaptured(request,captures); facts=await task.facts; assert(Array.isArray(facts));
  assert.equal(facts[0].dialect,'spark'); assert.equal(facts[0].kind,'sqlglot');
  assert.equal(facts[1].cells[0].syntaxFacts.dialect,'spark');
  assert.equal(facts[2].cells[0].status,'unsupported-dialect'); await task.cancel();
  const pythonSource='x = 1\ry = x\r';
  const pythonCapture={artifactId:'bare-cr',text:pythonSource,notebookProjection:null};
  const pythonSnapshot={artifactId:'bare-cr',path:'bare-cr.py',kind:'file',byteLength:Buffer.byteLength(pythonSource),
    integrityDigest:core.unwrap(core.digestExactBytes(Buffer.from(pythonSource))),semanticDigest:null};
  const pythonOptions={dialect:'pyspark',resolutionPolicy:'syntax-only'};
  const pythonRequest={...request,requestId:'python-profile',options:pythonOptions,snapshotManifest:[pythonSnapshot],
    header:{...request.header,configDigest:core.unwrap(core.digestJson(pythonOptions)),sourceDigests:[{artifactId:'bare-cr',integrityDigest:pythonSnapshot.integrityDigest,semanticDigest:null}]}};
  const pythonTask=host.startCaptured(pythonRequest,[pythonCapture]); pythonFacts=await pythonTask.facts;
  assert(Array.isArray(pythonFacts)); assert.equal(pythonFacts[0].kind,'python-ast');
  assert.equal(pythonFacts[0].tree.fields.body[1].lineno,2); await pythonTask.cancel();
  const wrongProfile=host.startCaptured({...request,requestId:'sql-with-python-profile',options:pythonOptions,
    header:{...request.header,configDigest:core.unwrap(core.digestJson(pythonOptions))}},captures);
  assert.deepEqual(await wrongProfile.facts,{status:'unavailable',code:'capture-kind-unsupported'}); await wrongProfile.cancel();
} finally { await host.dispose(); }
await writeFile(join(dirname(manifestPath),'spark-host-result.json'),JSON.stringify({manifestSha256:sha(manifestBytes),runtimeVersions:process.versions,request,captures,facts,
  pythonFixture:{source:'x = 1\ry = x\r',facts:pythonFacts}},null,2)+'\n');
console.log(JSON.stringify({explicitSparkChild:true,explicitSparkNotebook:true,ambiguousNotebookRejected:true,pysparkProfile:true,bareCrLocations:true,pythonProfileRejectsSql:true,execution:'not-executed'}));
