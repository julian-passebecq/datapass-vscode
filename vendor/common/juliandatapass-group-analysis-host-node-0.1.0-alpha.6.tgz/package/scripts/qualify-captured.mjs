// Real LPAC proof for explicit editor snapshots and C2-bound notebook projections.
import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir, access } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname, join, resolve } from 'node:path';
import { createRequire } from 'node:module';
const require=createRequire(import.meta.url);
const { StaticSyntaxHost, createWindowsPathInspector }=require('../dist/cjs/index.cjs');
const core=require('@juliandatapass-group/semantic-core');
const { ANALYSIS_LIMITS, validateNotebookCellBinding }=require('@juliandatapass-group/analysis-protocol');
const manifestPath=resolve(process.argv[2]); const manifestBytes=await readFile(manifestPath);
const sha=value=>createHash('sha256').update(value).digest('hex'); assert.equal(sha(manifestBytes),process.argv[3]);
const selectedRoot=join(dirname(manifestPath),'owned-captured-root'); await mkdir(selectedRoot,{recursive:true});
await writeFile(join(selectedRoot,'dirty.sql'),'SELECT old_disk_value');
const python='label = "😀"\r\nframe = spark.read.table("dbo.orders")\r\nframe.select("id").write.saveAsTable("dbo.output")\r\nopen("never-created.txt", "w").write("not executed")\r\n';
const projection={splitterVersion:'synthetic-jupyter/1',analysisMetadata:{origin:'synthetic'},cells:[
  {cellId:'py',kind:'code',language:'python',exactSourceText:python},
  {cellId:'sql',kind:'code',language:'tsql',exactSourceText:'SELECT café FROM dbo.orders'},
  {cellId:'md',kind:'markdown',language:'markdown',exactSourceText:'# Never execute'},
  {cellId:'r',kind:'code',language:'r',exactSourceText:'unhandled()'},
  {cellId:'ambiguous',kind:'code',language:'sql',exactSourceText:'SELECT * FROM unknown_dialect'}]};
const notebook=output=>JSON.stringify({nbformat:4,nbformat_minor:5,metadata:{},cells:projection.cells.map(cell=>({id:cell.cellId,cell_type:cell.kind,
  source:[cell.exactSourceText],metadata:{},...(cell.kind==='code'?{execution_count:null,outputs:[{output_type:'stream',name:'stdout',text:output}]}:{})}))});
const captures=[{artifactId:'dirty',text:'SELECT new_editor_value',notebookProjection:null},
  {artifactId:'nb1',text:notebook('OUTPUT_ONLY_UNPARSED_MARKER'),notebookProjection:projection},
  {artifactId:'nb2',text:notebook('changed output only'),notebookProjection:structuredClone(projection)}];
const originalProjection=structuredClone(projection);
const snapshotManifest=captures.map((capture,index)=>({artifactId:capture.artifactId,path:index===0?'dirty.sql':capture.artifactId+'.ipynb',
  kind:index===0?'file':'notebook',byteLength:Buffer.byteLength(capture.text),integrityDigest:core.unwrap(core.digestExactBytes(Buffer.from(capture.text))),
  semanticDigest:index===0?null:core.unwrap(core.digestNotebookSource(capture.notebookProjection))}));
assert.deepEqual(snapshotManifest[1].semanticDigest,snapshotManifest[2].semanticDigest);
assert.notDeepEqual(snapshotManifest[1].integrityDigest,snapshotManifest[2].integrityDigest);
const options={dialect:'tsql',resolutionPolicy:'syntax-only'}; const digest=core.unwrap(core.digestJson(options));
const request={schema:'datapass.analysis-wire/1',kind:'request',requestId:'captured',generation:1,options,limits:ANALYSIS_LIMITS,snapshotManifest,
  header:{schemaVersion:'datapass.analysis-wire/1',engineVersion:'fixture',producer:{pluginId:'fixture',version:'1',parserLockDigest:digest},configDigest:digest,
    ruleCatalogDigest:digest,supportedManifestVersion:'datapass.snapshot-manifest/1',snapshotId:'captured-fixture',
    sourceDigests:snapshotManifest.map(({artifactId,integrityDigest,semanticDigest})=>({artifactId,integrityDigest,semanticDigest})),dependencyDigests:[]}};
const host=new StaticSyntaxHost({selectedRoot,securityPolicy:'local-static-parser-v1',runtimeDirectory:join(dirname(manifestPath),'runtime'),manifestBytes,
  expectedManifestSha256:sha(manifestBytes),cachePolicy:{cacheRoot:dirname(manifestPath),nativePathInspector:createWindowsPathInspector(process.env.SystemRoot)},systemRoot:process.env.SystemRoot});
let facts;
try {
  const invalid=structuredClone(captures); invalid[1].notebookProjection.cells[0].exactSourceText='wrong';
  assert.throws(()=>host.startCaptured(request,invalid));
  const task=host.startCaptured(request,captures); assert.equal(task.acquisition,'supplied-capture');
  captures[1].notebookProjection.cells[0].exactSourceText='mutated after start';
  facts=await task.facts; assert(Array.isArray(facts)); assert.equal(facts.length,3);
  assert(JSON.stringify(facts[0]).includes('new_editor_value')); assert(!JSON.stringify(facts).includes('old_disk_value'));
  assert(!JSON.stringify(facts).includes('OUTPUT_ONLY_UNPARSED_MARKER'));
  for(let index=1;index<3;index++) {
    const item=facts[index]; assert.equal(item.kind,'notebook');
    assert.equal(item.cells[0].syntaxFacts.schema,'datapass.python-syntax-facts/1');
    assert.equal(item.cells[0].syntaxFacts.tree.nodeType,'Module');
    assert.equal(item.cells[2].status,'not-code'); assert.equal(item.cells[3].status,'unsupported-language');
    assert.equal(item.cells[4].status,'unsupported-dialect');
    for(const cell of item.cells) assert(core.unwrap(validateNotebookCellBinding(cell.binding,captures[index].text)));
  }
  assert.notDeepEqual(facts[1].cells[0].binding.containerDigest,facts[2].cells[0].binding.containerDigest);
  assert.deepEqual(facts[1].cells[0].syntaxFacts.tree,facts[2].cells[0].syntaxFacts.tree);
  await assert.rejects(access(join(dirname(manifestPath),'runtime','never-created.txt')));
  await assert.rejects(access(join(selectedRoot,'never-created.txt')));
  await task.cancel();
} finally { await host.dispose(); }
await writeFile(join(dirname(manifestPath),'captured-result.json'),JSON.stringify({manifestSha256:sha(manifestBytes),runtimeVersions:process.versions,
  sourceFixtures:{python,notebookProjection:originalProjection},facts},null,2)+'\n');
console.log(JSON.stringify({dirtyBuffer:true,notebookProjection:true,outputOnlyRebound:true,mutableCallerIsolated:true,noExecution:true}));
