"""Built-in qualification fixture ONLY. No supplied SQL/Python is executed or parsed."""
import ast, json, os, struct, sys, time
MAX_FRAME = 4096
def exact(count):
    chunks=[]
    while count:
        piece=sys.stdin.buffer.read(count)
        if not piece: raise ValueError('truncated-frame')
        chunks.append(piece); count-=len(piece)
    return b''.join(chunks)
size=struct.unpack('<I',exact(4))[0]
if not 0<size<=MAX_FRAME: raise ValueError('frame-limit')
request=json.loads(exact(size))
if set(request)!={'fixture','requestId','generation'} or request['fixture'] not in ('static-sql-v1','owned-lifetime-v1'): raise ValueError('unsupported-fixture')
if not isinstance(request['requestId'],str) or len(request['requestId'])>128: raise ValueError('request-id')
if not isinstance(request['generation'],int) or request['generation']<0: raise ValueError('generation')
if request['fixture']=='owned-lifetime-v1':
    sys.stderr.write('owned-fixture-ready:'+str(os.getpid())+'\n'); sys.stderr.flush()
    time.sleep(20)
    raise RuntimeError('lifetime-probe-was-not-cancelled')
import sqlglot
from sqlglot import exp
from sqlglot.errors import ParseError
tree=sqlglot.parse_one('SELECT c.id FROM dbo.customers AS c',read='tsql')
try:
    sqlglot.parse_one('SELECT ( FROM dbo.orders',read='tsql')
    malformed=False
except ParseError: malformed=True
reply={'fixture':'static-sql-v1','requestId':request['requestId'],'generation':request['generation'],
    'python':sys.version.split()[0],'parser':sqlglot.__version__,'tables':sorted(t.name for t in tree.find_all(exp.Table)),
    'malformedRejected':malformed,'astNodes':len(list(ast.walk(ast.parse('x = 1 + 2')))),'productionQualified':False}
encoded=json.dumps(reply,separators=(',',':')).encode('utf-8')
if len(encoded)>MAX_FRAME: raise ValueError('output-limit')
sys.stdout.buffer.write(struct.pack('<I',len(encoded))+encoded); sys.stdout.buffer.flush()
