"""Trusted static syntax worker. No source execution, imports, evaluation or SQL connection."""
import ast, ctypes as c, hashlib, json, os, socket, struct, subprocess, sys, winreg
from ctypes import wintypes as w

FRAME_LIMIT=320*1024*1024
OUTPUT_LIMIT=48*1024*1024

def exact(count):
    chunks=[]
    while count:
        piece=sys.stdin.buffer.read(min(count,65536))
        if not piece: raise ValueError('truncated-frame')
        chunks.append(piece); count-=len(piece)
    return b''.join(chunks)

def read_frame(limit):
    size=struct.unpack('<I',exact(4))[0]
    if not 0<size<=limit: raise ValueError('frame-limit')
    return json.loads(exact(size))

def preflight(context):
    if context.get('policy')!='local-static-parser-v1': return 'unknown-policy'
    kernel=c.WinDLL('kernel32',use_last_error=True)
    create=kernel.CreateFileW
    create.argtypes=[w.LPCWSTR,w.DWORD,w.DWORD,c.c_void_p,w.DWORD,w.DWORD,c.c_void_p]
    create.restype=c.c_void_p
    close=kernel.CloseHandle; close.argtypes=[c.c_void_p]; close.restype=w.BOOL
    # READ_DATA for files / LIST_DIRECTORY for directories. Never read content.
    for path in context['paths']:
        handle=create(path,1,7,None,3,0x02000000,None)
        if handle!=c.c_void_p(-1).value:
            close(handle); return 'selected-root-readable'
        if c.get_last_error()!=5: return 'selected-root-access-unknown'
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,context['registryKey'],0,winreg.KEY_QUERY_VALUE):
            return 'hkcu-canary-readable'
    except OSError as error:
        if error.winerror!=5: return 'hkcu-access-unknown'
    try:
        connection=socket.socket(); connection.close(); return 'network-socket-allowed'
    except OSError as error:
        if error.winerror!=10013: return 'network-denial-unknown'
    try:
        subprocess.run([sys.executable,'-I','-S','-c','pass'],timeout=1,check=False,
                       stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        return 'child-process-allowed'
    except OSError as error:
        if error.winerror!=367: return 'child-denial-unknown'
    except subprocess.TimeoutExpired: return 'child-process-allowed'
    return None

def python_tree(node,depth=0,budget=None):
    if budget is None: budget=[0]
    if depth>128: raise ValueError('syntax-depth-limit')
    budget[0]+=1
    if budget[0]>50000: raise ValueError('syntax-node-limit')
    if isinstance(node,ast.AST):
        result={'type':type(node).__name__}
        for key,value in ast.iter_fields(node): result[key]=python_tree(value,depth+1,budget)
        for key in ('lineno','col_offset','end_lineno','end_col_offset'):
            if hasattr(node,key): result[key]=getattr(node,key)
        return result
    if isinstance(node,list): return [python_tree(value,depth+1,budget) for value in node]
    if node is None or isinstance(node,(str,bool,int)): return node
    # JSON cannot losslessly encode complex/bytes/ellipsis/non-finite Python constants.
    if isinstance(node,float) and node==node and abs(node)!=float('inf'): return node
    return {'literalKind':type(node).__name__}

def analyze(request):
    import logging
    logging.getLogger('sqlglot').disabled=True
    import sqlglot
    from sqlglot.errors import ParseError
    if sys.version_info[:3]!=(3,13,15) or sqlglot.__version__!='30.19.0': raise ValueError('runtime-version')
    captures=request['captures']
    if not isinstance(captures,list) or len(captures)>500: raise ValueError('capture-limit')
    facts=[]; total=0
    for source in captures:
        text=source['text']; raw=text.encode('utf-8'); total+=len(raw)
        if len(raw)>2*1024*1024 or total>50*1024*1024: raise ValueError('source-limit')
        if hashlib.sha256(raw).hexdigest()!=source['integrityDigest']: raise ValueError('source-digest')
        item={'artifactId':source['artifactId'],'integrityDigest':{'algorithm':'sha256','mode':'exact-bytes','value':source['integrityDigest']}}
        if source['language']=='sql': item.update(schema='datapass.sql-syntax-facts/1',dialect='tsql',parserVersion=sqlglot.__version__)
        try:
            if source['language']=='sql':
                statements=sqlglot.parse(text,read='tsql')
                if len(statements)>500: raise ValueError('statement-limit')
                trees=[]; nodes=0
                for statement in statements:
                    if statement is None: continue
                    tree=statement.dump(); nodes+=len(tree)
                    if nodes>50000: raise ValueError('syntax-node-limit')
                    trees.append({'tree':tree})
                item.update(kind='sqlglot',dialect='tsql',parserVersion=sqlglot.__version__,statements=trees)
            elif source['language']=='python':
                item.update(kind='python-ast',parserVersion='3.13.15',tree=python_tree(ast.parse(text)))
            else: raise ValueError('unsupported-language')
        except ParseError as error:
            item.update(kind='parse-error',diagnostics=[{'line':e.get('line',1),'column':e.get('col',1),
                'description':'SQL syntax rejected'} for e in error.errors[:32]])
        except SyntaxError as error:
            item.update(kind='parse-error',diagnostics=[{'line':error.lineno or 1,'column':error.offset or 1,
                'description':'Python syntax rejected'}])
        facts.append(item)
    return facts

def main():
    context=read_frame(16*1024*1024)
    request=read_frame(FRAME_LIMIT)
    reply={key:request[key] for key in ('requestId','generation','requestDigest')}
    # Read the bounded envelope before preflight so a rejected context still drains IPC.
    # No captured source is parsed until all access and child/network checks pass.
    reason=preflight(context)
    if reason: reply.update(status='unavailable',code=reason)
    else:
        try: reply.update(status='syntax-facts',facts=analyze(request),policy='local-static-parser-v1')
        except (ValueError,RecursionError,MemoryError): reply.update(status='unavailable',code='syntax-resource-or-input-limit')
    output=json.dumps(reply,ensure_ascii=True,allow_nan=False,separators=(',',':')).encode('utf-8')
    if len(output)>OUTPUT_LIMIT:
        reply={key:request[key] for key in ('requestId','generation','requestDigest')}
        reply.update(status='unavailable',code='syntax-output-limit'); output=json.dumps(reply).encode('utf-8')
    sys.stdout.buffer.write(struct.pack('<I',len(output))+output); sys.stdout.buffer.flush()

if __name__=='__main__': main()
