"""Trusted Windows controller; never imports client code. Python analysis remains unqualified."""
import ctypes as c
from ctypes import wintypes as w
import hashlib, json, os, pathlib, shutil, socket, subprocess, sys, time, uuid, zipfile

ROOT = pathlib.Path(__file__).resolve().parent
RUNTIME = ROOT
LPAC = True
P = c.c_void_p
SZ = c.c_size_t
K = c.WinDLL('kernel32', use_last_error=True)
U = c.WinDLL('userenv', use_last_error=True)
A = c.WinDLL('advapi32', use_last_error=True)
B = c.WinDLL('kernelbase', use_last_error=True)

def api(lib, name, result, args):
    fn = getattr(lib, name); fn.restype = result; fn.argtypes = args; return fn

close = api(K, 'CloseHandle', w.BOOL, [P])
create_profile = api(U, 'CreateAppContainerProfile', c.c_long, [w.LPCWSTR]*3+[P,w.DWORD,c.POINTER(P)])
delete_profile = api(U, 'DeleteAppContainerProfile', c.c_long, [w.LPCWSTR])
sid_string = api(A, 'ConvertSidToStringSidW', w.BOOL, [P,c.POINTER(w.LPWSTR)])
free_sid = api(A, 'FreeSid', P, [P])
local_free = api(K, 'LocalFree', P, [P])
init_attrs = api(K, 'InitializeProcThreadAttributeList', w.BOOL, [P,w.DWORD,w.DWORD,c.POINTER(SZ)])
update_attr = api(K, 'UpdateProcThreadAttribute', w.BOOL, [P,w.DWORD,SZ,P,SZ,P,P])
delete_attrs = api(K, 'DeleteProcThreadAttributeList', None, [P])

class SI(c.Structure):
    _fields_ = [('cb',w.DWORD),('reserved',w.LPWSTR),('desktop',w.LPWSTR),('title',w.LPWSTR),
        ('x',w.DWORD),('y',w.DWORD),('xs',w.DWORD),('ys',w.DWORD),('xc',w.DWORD),('yc',w.DWORD),
        ('fill',w.DWORD),('flags',w.DWORD),('show',w.WORD),('reserved2size',w.WORD),('reserved2',P),
        ('stdin',P),('stdout',P),('stderr',P)]
class SIX(c.Structure):
    _fields_ = [('si',SI),('attrs',P)]
class PI(c.Structure):
    _fields_ = [('process',P),('thread',P),('pid',w.DWORD),('tid',w.DWORD)]
class CAPS(c.Structure):
    _fields_ = [('sid',P),('caps',P),('count',w.DWORD),('reserved',w.DWORD)]
class SIDATTR(c.Structure):
    _fields_ = [('sid',P),('attributes',w.DWORD)]

derive_caps = api(B,'DeriveCapabilitySidsFromName',w.BOOL,[w.LPCWSTR,c.POINTER(P),c.POINTER(w.DWORD),c.POINTER(P),c.POINTER(w.DWORD)])
class BASIC(c.Structure):
    _fields_ = [('processTime',c.c_longlong),('jobTime',c.c_longlong),('flags',w.DWORD),
        ('minws',SZ),('maxws',SZ),('active',w.DWORD),('affinity',SZ),('priority',w.DWORD),('scheduling',w.DWORD)]
class IO(c.Structure):
    _fields_ = [(n,c.c_ulonglong) for n in ('readops','writeops','otherops','readbytes','writebytes','otherbytes')]
class LIMIT(c.Structure):
    _fields_ = [('basic',BASIC),('io',IO),('processMemory',SZ),('jobMemory',SZ),('peakProcess',SZ),('peakJob',SZ)]

create_process = api(K,'CreateProcessW',w.BOOL,[w.LPCWSTR,w.LPWSTR,P,P,w.BOOL,w.DWORD,P,w.LPCWSTR,c.POINTER(SIX),c.POINTER(PI)])
create_job = api(K,'CreateJobObjectW',P,[P,w.LPCWSTR])
set_job = api(K,'SetInformationJobObject',w.BOOL,[P,c.c_int,P,w.DWORD])
query_job = api(K,'QueryInformationJobObject',w.BOOL,[P,c.c_int,P,w.DWORD,P])
assign_job = api(K,'AssignProcessToJobObject',w.BOOL,[P,P])
terminate_job = api(K,'TerminateJobObject',w.BOOL,[P,w.UINT])
terminate_process = api(K,'TerminateProcess',w.BOOL,[P,w.UINT])
resume = api(K,'ResumeThread',w.DWORD,[P])
wait = api(K,'WaitForSingleObject',w.DWORD,[P,w.DWORD])
exit_code = api(K,'GetExitCodeProcess',w.BOOL,[P,c.POINTER(w.DWORD)])

def ok(value):
    if not value: raise c.WinError(c.get_last_error())
    return value


class TRUSTEE(c.Structure):
    _fields_=[('multiple',P),('operation',w.DWORD),('form',w.DWORD),('kind',w.DWORD),('name',P)]
class ACCESS(c.Structure):
    _fields_=[('permissions',w.DWORD),('mode',w.DWORD),('inheritance',w.DWORD),('trustee',TRUSTEE)]
get_security=api(A,'GetNamedSecurityInfoW',w.DWORD,[w.LPWSTR,w.DWORD,w.DWORD,P,P,c.POINTER(P),P,c.POINTER(P)])
set_security=api(A,'SetNamedSecurityInfoW',w.DWORD,[w.LPWSTR,w.DWORD,w.DWORD,P,P,P,P])
set_acl=api(A,'SetEntriesInAclW',w.DWORD,[w.ULONG,c.POINTER(ACCESS),P,c.POINTER(P)])
attributes=api(K,'GetFileAttributesW',w.DWORD,[w.LPCWSTR])

def set_runtime_access(sid,grant):
    # ACL updates happen in this process: cancellation cannot orphan icacls children.
    paths=[ROOT]
    for parent,dirs,files in os.walk(ROOT,followlinks=False):
        paths.extend(pathlib.Path(parent)/name for name in dirs+files)
    if len(paths)>8192: raise ValueError('runtime-entry-limit')
    for path in paths:
        attr=attributes(str(path))
        if attr==0xffffffff or attr & 0x400: raise ValueError('runtime-reparse-point')
        old=P(); descriptor=P(); new=P()
        code=get_security(str(path),1,4,None,None,c.byref(old),None,c.byref(descriptor))
        if code: raise c.WinError(code)
        try:
            entry=ACCESS(0x1200a9 if grant else 0,1 if grant else 4,0,TRUSTEE(None,0,0,0,sid))
            code=set_acl(1,c.byref(entry),old,c.byref(new))
            if code: raise c.WinError(code)
            code=set_security(str(path),1,4,None,None,new,None)
            if code: raise c.WinError(code)
        finally:
            if new: local_free(new)
            if descriptor: local_free(descriptor)

def inspect_selected_root(root):
    root=pathlib.Path(os.path.abspath(root))
    for component in [*reversed(root.parents),root]:
        attr=attributes(str(component))
        if attr==0xffffffff or attr & 0x400: raise ValueError('unsupported-reparse-point')
    if not root.is_dir() or str(root).startswith('\\\\'): raise ValueError('unsupported-root')
    volume=c.create_unicode_buffer(1024); filesystem=c.create_unicode_buffer(64)
    get_volume=api(K,'GetVolumePathNameW',w.BOOL,[w.LPCWSTR,w.LPWSTR,w.DWORD])
    volume_info=api(K,'GetVolumeInformationW',w.BOOL,[w.LPCWSTR,P,w.DWORD,P,P,P,w.LPWSTR,w.DWORD])
    drive_type=api(K,'GetDriveTypeW',w.UINT,[w.LPCWSTR])
    ok(get_volume(str(root),volume,1024)); ok(volume_info(volume.value,None,0,None,None,None,filesystem,64))
    if filesystem.value!='NTFS' or drive_type(volume.value)!=3: raise ValueError('unsupported-filesystem')
    paths=[str(root)]; path_bytes=len(str(root).encode('utf-8'))
    def failed(error): raise error
    for parent,dirs,files in os.walk(root,followlinks=False,onerror=failed):
        for name in dirs+files:
            path=str(pathlib.Path(parent)/name); attr=attributes(path)
            if attr==0xffffffff or attr & 0x400: raise ValueError('unsupported-reparse-point')
            paths.append(path)
            path_bytes+=len(path.encode('utf-8'))
            if len(paths)>10000 or path_bytes>4*1024*1024: raise ValueError('root-enumeration-limit')
    if attributes(str(root)) & 0x400: raise ValueError('unsupported-reparse-point')
    return paths

# Controller arguments are supplied only by the trusted Node host.
def main():
    import re
    if len(sys.argv) not in (5,6): raise ValueError('controller-arguments')
    mode,name,timeout_text,memory_text=sys.argv[1:5]
    if mode not in ('fixture','cleanup','analysis') or not re.fullmatch(r'DataPass.Analysis.[a-f0-9]{32}',name): raise ValueError('controller-mode')
    if (mode=='analysis') != (len(sys.argv)==6): raise ValueError('controller-root')
    timeout=int(timeout_text); memory=int(memory_text)
    if not 1<=timeout<=30000 or not 64<=memory<=512: raise ValueError('controller-limits')
    sid=P(); ptr=w.LPWSTR(); job=None; pi=PI(); attrs=None; allocations=[]; worker_read=None; worker_write=None; deadline=None
    if sys.getwindowsversion().build!=26200: raise ValueError('unqualified-windows-build')
    selected_paths=inspect_selected_root(sys.argv[5]) if mode=='analysis' else None
    import winreg
    registry_key='Software\\'+name
    if mode=='cleanup':
        derive=api(U,'DeriveAppContainerSidFromAppContainerName',c.c_long,[w.LPCWSTR,c.POINTER(P)])
        hr=derive(name,c.byref(sid))
    else: hr=create_profile(name,name,'DataPass fixed fixture qualification',None,0,c.byref(sid))
    if hr<0: raise OSError('appcontainer-profile-failed')
    cleanup_errors=[]
    try:
        ok(sid_string(sid,c.byref(ptr))); sidtext=ptr.value
        if mode=='cleanup': return
        if mode=='analysis':
            try:
                key=winreg.OpenKey(winreg.HKEY_CURRENT_USER,registry_key); key.Close(); raise ValueError('canary-key-exists')
            except FileNotFoundError: pass
            with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER,registry_key,0,winreg.KEY_READ|winreg.KEY_WRITE) as key:
                winreg.SetValueEx(key,'HarmlessCanary',0,winreg.REG_SZ,'owned harmless canary')
                if winreg.QueryValueEx(key,'HarmlessCanary')[0]!='owned harmless canary': raise ValueError('canary-control-failed')
        set_runtime_access(sid,True)
        groups=P(); group_count=w.DWORD(); capabilities=P(); count=w.DWORD()
        ok(derive_caps('registryRead',c.byref(groups),c.byref(group_count),c.byref(capabilities),c.byref(count)))
        for array,num in ((groups,group_count.value),(capabilities,count.value)):
            allocations.extend(c.cast(array,c.POINTER(P))[i] for i in range(num)); allocations.append(array)
        cap_values=(SIDATTR*count.value)(*[SIDATTR(c.cast(capabilities,c.POINTER(P))[i],4) for i in range(count.value)])
        caps=CAPS(sid,c.addressof(cap_values),count.value,0); policy=w.DWORD(1); child=w.DWORD(1)
        job=ok(create_job(None,None)); limit=LIMIT(); limit.basic.flags=0x2000|0x100|0x8; limit.basic.active=1; limit.processMemory=memory*1024*1024
        ok(set_job(job,9,c.byref(limit),c.sizeof(limit)))
        get_handle=api(K,'GetStdHandle',P,[w.DWORD])
        stdin=get_handle(w.DWORD(-10).value); stdout=get_handle(w.DWORD(-11).value); stderr=get_handle(w.DWORD(-12).value)
        if mode=='analysis':
            import msvcrt
            worker_read,worker_write=os.pipe(); stdin=msvcrt.get_osfhandle(worker_read)
        handles=(P*3)(stdin,stdout,stderr)
        for h in handles: os.set_handle_inheritable(h,True)
        size=SZ(); init_attrs(None,4,0,c.byref(size)); attrs=c.create_string_buffer(size.value)
        ok(init_attrs(attrs,4,0,c.byref(size)))
        for attribute,value in ((0x20009,caps),(0x2000f,policy),(0x20002,handles),(0x2000e,child)):
            ok(update_attr(attrs,0,attribute,c.byref(value),c.sizeof(value),None,None))
        startup=SIX(); startup.si.cb=c.sizeof(startup); startup.si.flags=0x100
        startup.si.stdin=stdin; startup.si.stdout=stdout; startup.si.stderr=stderr; startup.attrs=c.addressof(attrs)
        script='datapass_analyzer.py' if mode=='analysis' else 'datapass_worker.py'
        cmd=subprocess.list2cmdline([str(ROOT/'pythonw.exe'),'-I','-S','-B',str(ROOT/script)])
        allowed=('SystemRoot','WINDIR','SystemDrive','USERPROFILE','LOCALAPPDATA','APPDATA','TEMP','TMP')
        env=c.create_unicode_buffer('\0'.join(k+'='+os.environ[k] for k in sorted(allowed,key=str.upper) if k in os.environ)+'\0\0')
        # Runtime is read-only to LPAC. No project directory is the cwd.
        ok(create_process(str(ROOT/'pythonw.exe'),c.create_unicode_buffer(cmd),None,None,True,
            0x80000|0x400|0x4|0x08000000,env,str(ROOT),c.byref(startup),c.byref(pi)))
        ok(assign_job(job,pi.process))
        if resume(pi.thread)==0xffffffff: raise c.WinError(c.get_last_error())
        import threading
        deadline=threading.Timer(timeout/1000,lambda: terminate_job(job,1460)); deadline.daemon=True; deadline.start()
        if mode=='analysis':
            import struct
            os.close(worker_read); worker_read=None
            context=json.dumps({'policy':'local-static-parser-v1','paths':selected_paths,'registryKey':registry_key}).encode('utf-8')
            with os.fdopen(worker_write,'wb') as stream:
                worker_write=None
                stream.write(struct.pack('<I',len(context))+context); stream.flush()
                transferred=0
                while True:
                    chunk=sys.stdin.buffer.read(65536)
                    if not chunk: break
                    transferred+=len(chunk)
                    if transferred>320*1024*1024+4: raise ValueError('transport-limit')
                    stream.write(chunk)
        if wait(pi.process,timeout)==258:
            ok(terminate_job(job,1460)); ok(wait(pi.process,2000)==0); raise TimeoutError('worker-timeout')
        code=w.DWORD(); ok(exit_code(pi.process,c.byref(code)))
        if code.value: raise RuntimeError('worker-exit-failed')
    finally:
        if deadline: deadline.cancel(); deadline.join()
        if worker_read is not None: os.close(worker_read)
        if worker_write is not None: os.close(worker_write)
        if pi.process:
            if wait(pi.process,0)==258: terminate_process(pi.process,1460)
            close(pi.process)
        if pi.thread: close(pi.thread)
        if attrs: delete_attrs(attrs)
        if job: close(job)
        for allocation in allocations: local_free(allocation)
        if ptr:
            try:
                set_runtime_access(sid,False)
            except Exception: cleanup_errors.append('runtime-acl-cleanup')
            local_free(c.cast(ptr,P))
        # Delete even when ACL removal failed. The host repeats cleanup after controller death.
        deletion=delete_profile(name)
        if deletion not in (0,-2147024894): cleanup_errors.append('profile-cleanup')
        if sid: free_sid(sid)
        try: winreg.DeleteKey(winreg.HKEY_CURRENT_USER,registry_key)
        except FileNotFoundError: pass
        except OSError: cleanup_errors.append('registry-canary-cleanup')
        if cleanup_errors: raise RuntimeError(','.join(cleanup_errors))

if __name__=='__main__': main()
