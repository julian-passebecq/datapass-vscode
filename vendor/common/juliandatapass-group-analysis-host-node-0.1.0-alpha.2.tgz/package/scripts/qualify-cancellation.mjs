// One explicit owned-worker death probe; never executes client source.
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { randomUUID, createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { encodeFrame, verifyRuntime, createWindowsPathInspector } = require('../dist/cjs/index.cjs');
const { runProcess } = require('../dist/cjs/process.cjs');
const manifestPath = resolve(process.argv[2]); const bytes = await readFile(manifestPath);
const digest = createHash('sha256').update(bytes).digest('hex'); assert.equal(digest, process.argv[3]);
const directory = join(dirname(manifestPath), 'runtime');
await verifyRuntime({ cacheRoot: dirname(manifestPath), nativePathInspector: createWindowsPathInspector(process.env.SystemRoot) }, directory, bytes, digest);
const profile = 'DataPass.Analysis.' + randomUUID().replaceAll('-', '');
const executable = join(directory, 'pythonw.exe'); const script = join(directory, 'datapass_controller.py');
const env = Object.fromEntries(['SystemRoot','WINDIR','SystemDrive','USERPROFILE','LOCALAPPDATA','APPDATA','TEMP','TMP'].filter(k => process.env[k]).map(k => [k,process.env[k]]));
let workerPid; let controllerPid;
try {
  await new Promise((resolve, reject) => {
    const process_ = spawn(executable, ['-I','-S','-B',script,'fixture',profile,'30000','256'], { cwd: directory, env, windowsHide: true, shell: false, stdio: ['pipe','pipe','pipe'] });
    controllerPid = process_.pid; let errors = ''; let timedOut = false;
    const timeout = setTimeout(() => { timedOut = true; process_.kill('SIGKILL'); }, 8000);
    process_.on('error', reject); process_.stdin.on('error', () => {});
    process_.stdout.on('data', () => {});
    process_.stderr.on('data', chunk => {
      errors += chunk.toString(); if (errors.length > 4096) { process_.kill('SIGKILL'); return; }
      const ready = /owned-fixture-ready:(\d+)/.exec(errors);
      if (ready && !workerPid) { workerPid = Number(ready[1]); process_.kill('SIGKILL'); }
    });
    process_.on('close', () => { clearTimeout(timeout); if (timedOut || !workerPid) reject(new Error('owned worker never became ready')); else resolve(); });
    process_.stdin.end(encodeFrame({ fixture: 'owned-lifetime-v1', requestId: 'cancel-fixture', generation: 1 }));
  });
  assert.throws(() => process.kill(workerPid, 0), { code: 'ESRCH' });
} finally {
  await runProcess({ executable, args: ['-I','-S','-B',script,'cleanup',profile,'5000','256'], cwd: directory, env,
    input: Buffer.alloc(0), timeoutMs: 10000, maxStdoutBytes: 256, maxStderrBytes: 2048 });
}
const evidence = { manifestSha256: digest, controllerPid, workerPid, workerExitedOnControllerKill: true, cleanupSucceeded: true, productionQualified: false };
await writeFile(join(dirname(manifestPath), 'cancellation-result.json'), JSON.stringify(evidence, null, 2)+'\n');
console.log(JSON.stringify(evidence));
