// Explicit offline build only. Source is the reviewed pinned-payload spike/archive extraction.
import { createHash } from 'node:crypto';
import { readFile, mkdir, mkdtemp, writeFile, lstat } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const pkg = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const source = resolve(process.argv[2] ?? '');
const outputParent = resolve(process.argv[3] ?? 'artifacts');
if (!process.argv[2]) throw new Error('Usage: node build-payload.mjs <verified source extraction> [output-parent]');
const sha = value => createHash('sha256').update(value).digest('hex');
const bytes = await readFile(join(source, 'payload-manifest.json'));
if (sha(bytes) !== '0cb08f6892b550a449e0d545b3415517e184397237028ab58338b745c3abf1f2') throw new Error('Unreviewed source manifest');
const original = JSON.parse(bytes);
await mkdir(outputParent, { recursive: true });
const output = await mkdtemp(join(outputParent, 'python-host-'));
const runtime = join(output, 'runtime'); await mkdir(runtime);
const files = [];
for (const file of original.files) {
  if (!/^runtime\/[a-zA-Z0-9_./-]+$/.test(file.path) || file.path.split('/').includes('..')) throw new Error('Invalid pinned path');
  const path = join(source, file.path);
  if ((await lstat(path)).isSymbolicLink()) throw new Error('Source symlink');
  const content = await readFile(path);
  if (content.length !== file.bytes || sha(content) !== file.sha256) throw new Error('Pinned source file mismatch');
  if (file.path === 'runtime/adapter.py') continue; // Earlier spike adapter is not a product parser.
  const relative = file.path.slice('runtime/'.length);
  await mkdir(dirname(join(runtime, relative)), { recursive: true }); await writeFile(join(runtime, relative), content, { flag: 'wx' });
  files.push({ path: relative, sha256: sha(content), bytes: content.length });
}
for (const name of ['datapass_controller.py', 'datapass_worker.py', 'datapass_analyzer.py']) {
  const content = await readFile(join(pkg, 'python', name)); await writeFile(join(runtime, name), content, { flag: 'wx' });
  files.push({ path: name, sha256: sha(content), bytes: content.length });
}
files.sort((a, b) => a.path.localeCompare(b.path, 'en'));
const manifest = { schemaVersion: 1, runtimeVersion: '3.13.15', parserVersion: '30.19.0', platform: 'win-x64',
  status: 'containment-unqualified', sourceManifestSha256: sha(bytes), files };
const manifestBytes = Buffer.from(JSON.stringify(manifest, null, 2) + '\n');
await writeFile(join(output, 'manifest.json'), manifestBytes, { flag: 'wx' });
await writeFile(join(output, 'provenance.json'), JSON.stringify({ sourceManifest: original, sigstoreVerified: false }, null, 2));
console.log(JSON.stringify({ directory: runtime, manifestPath: join(output, 'manifest.json'), manifestSha256: sha(manifestBytes), status: 'containment-unqualified' }, null, 2));
