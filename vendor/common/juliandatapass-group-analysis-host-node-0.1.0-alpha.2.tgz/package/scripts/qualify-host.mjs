// Narrow real-host proof: static SQL/Python, stale/cancel, and an owned readable-ACL rejection.
import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir, access } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname, join, resolve } from 'node:path';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
const require=createRequire(import.meta.url);
const { StaticSyntaxHost }=require('../dist/cjs/syntax-transport.cjs');
const { createWindowsPathInspector }=require('../dist/cjs/index.cjs');
const core=require('@juliandatapass-group/semantic-core');
const { ANALYSIS_LIMITS }=require('@juliandatapass-group/analysis-protocol');
const manifestPath=resolve(process.argv[2]); const manifestBytes=await readFile(manifestPath);
const sha=value=>createHash('sha256').update(value).digest('hex');
assert.equal(sha(manifestBytes),process.argv[3]);
const selectedRoot=join(dirname(manifestPath),'owned-host-root'); await mkdir(selectedRoot,{recursive:true});
const sources=[{path:'query.sql',text:'SELECT c.id FROM dbo.customers c'},
  {path:'malformed.sql',text:'SELECT ( FROM dbo.orders'},
  {path:'never-execute.py',text:"open('client-code-executed.txt', 'w').write('never execute this')"}];
for(const source of sources) await writeFile(join(selectedRoot,source.path),source.text);
const snapshots=sources.map(source=>({artifactId:source.path,path:source.path,kind:'file',byteLength:Buffer.byteLength(source.text),
  integrityDigest:core.unwrap(core.digestExactBytes(Buffer.from(source.text))),semanticDigest:null}));
const options={dialect:'tsql',resolutionPolicy:'syntax-only'}; const digest=core.unwrap(core.digestJson(options));
const request={schema:'datapass.analysis-wire/1',kind:'request',requestId:'host-qualification',generation:1,options,limits:ANALYSIS_LIMITS,
  snapshotManifest:snapshots,header:{schemaVersion:'datapass.analysis-wire/1',engineVersion:'qualification',producer:{pluginId:'qualification',version:'1',parserLockDigest:digest},
  configDigest:digest,ruleCatalogDigest:digest,supportedManifestVersion:'datapass.snapshot-manifest/1',snapshotId:'owned-synthetic',
  sourceDigests:snapshots.map(({artifactId,integrityDigest,semanticDigest})=>({artifactId,integrityDigest,semanticDigest})),dependencyDigests:[]}};
const host=new StaticSyntaxHost({selectedRoot,securityPolicy:'local-static-parser-v1',runtimeDirectory:join(dirname(manifestPath),'runtime'),manifestBytes,
  expectedManifestSha256:sha(manifestBytes),cachePolicy:{cacheRoot:dirname(manifestPath),nativePathInspector:createWindowsPathInspector(process.env.SystemRoot)},systemRoot:process.env.SystemRoot});
const observations={};
try {
  const task=host.start(request,sources.map(source=>({artifactId:source.path,text:source.text,notebookProjection:null})));
  const facts=await task.facts; assert(Array.isArray(facts));
  assert.equal(facts[0].schema,'datapass.sql-syntax-facts/1'); assert.equal(facts[1].kind,'parse-error'); assert.equal(facts[2].kind,'python-ast');
  await assert.rejects(access(join(dirname(manifestPath),'runtime','client-code-executed.txt')));
  await assert.rejects(access(join(selectedRoot,'client-code-executed.txt')));
  observations.staticSyntax=true;
  await task.cancel(); observations.taskCleanupAwaited=true;
  await assert.rejects(host.analyze(request),{code:'stale-generation'}); observations.staleRejected=true;
  const canary=join(selectedRoot,'query.sql');
  const icacls=join(process.env.SystemRoot,'System32','icacls.exe');
  execFileSync(icacls,[canary,'/grant','*S-1-15-2-2:(R)'],{windowsHide:true,stdio:'pipe'});
  try {
    const blocked=await host.analyze({...request,generation:2});
    assert.deepEqual(blocked,{status:'unavailable',code:'selected-root-readable'}); observations.readableAclRejected=true;
  } finally { execFileSync(icacls,[canary,'/remove:g','*S-1-15-2-2'],{windowsHide:true,stdio:'pipe'}); }
  const cancelled=host.analyze({...request,generation:3}); host.cancel(request.requestId);
  await assert.rejects(cancelled); observations.cancelled=true;
} finally { await host.dispose(); }
await writeFile(join(dirname(manifestPath),'host-result-'+process.versions.node+'.json'),JSON.stringify({manifestSha256:sha(manifestBytes),windowsBuild:'26200',runtimeVersions:process.versions,observations},null,2)+'\n');
console.log(JSON.stringify(observations));
