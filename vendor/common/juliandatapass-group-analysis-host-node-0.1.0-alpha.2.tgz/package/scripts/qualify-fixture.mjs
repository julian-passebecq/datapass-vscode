// Explicit targeted probe using locally built, hash-pinned offline assets. No downloads.
import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname, join, resolve } from 'node:path';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { FixtureController } = require('../dist/cjs/controller.cjs');
const { createWindowsPathInspector } = require('../dist/cjs/index.cjs');
if (!process.argv[2]) throw new Error('Pass a locally built manifest.json path');
const manifestPath = resolve(process.argv[2]); const manifestBytes = await readFile(manifestPath);
const digest = createHash('sha256').update(manifestBytes).digest('hex');
if (digest !== process.argv[3]) throw new Error('Reviewed manifest digest is required');
const controller = new FixtureController({ runtimeDirectory: join(dirname(manifestPath), 'runtime'), manifestBytes, expectedManifestSha256: digest,
  cachePolicy: { cacheRoot: dirname(manifestPath), nativePathInspector: createWindowsPathInspector(process.env.SystemRoot) }, systemRoot: process.env.SystemRoot });
try {
  const result = await controller.run({ requestId: 'fixture-qualification', generation: 1 });
  assert.equal(result.qualification, 'unqualified'); assert.equal(result.observation.python, '3.13.15');
  assert.equal(result.observation.parser, '30.19.0'); assert.deepEqual(result.observation.tables, ['customers']); assert(result.observation.malformedRejected);
  await assert.rejects(controller.run({ requestId: 'fixture-qualification', generation: 1 }), { code: 'stale-generation' });
  await writeFile(join(dirname(manifestPath), 'fixture-result.json'), JSON.stringify({ manifestSha256: digest, result }, null, 2) + '\n');
  console.log(JSON.stringify(result));
} finally { await controller.dispose(); }
