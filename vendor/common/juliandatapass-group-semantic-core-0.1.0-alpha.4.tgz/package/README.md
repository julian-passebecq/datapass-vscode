# @juliandatapass-group/semantic-core

C2b alpha contracts, compiled as CJS and ESM with declarations and named subpaths.
All APIs operate on supplied data; no filesystem, network, parser, provider or execution host.

- `digest`: validated SHA256 modes, exact-byte/JCS/notebook-source hashing and bounded UTF-8 encoding.
- `json`: duplicate-key rejecting wire parser and bounded JCS canonicalisation.
- `anchor`: native source anchors bound to exact bytes and valid UTF-8 boundaries.
- `path`: canonical POSIX/NFC locators, collision inventory and fail-closed acceptance.
- `identity`: revision-free logical artifact IDs, separate revision IDs, boundary dataset references,
  and seven distinct model-kind references. These are not a universal graph.
- `schema` / `validation`: the shared executable/JSON Schema owner and typed bounded errors.

Validators return `ValidationResult`. Lower-level schema readers and `unwrap` are for trusted
composition inside `checked`; callers handling untrusted wire data use `parseJson` before
validation. Validation copies plain JSON data without invoking accessors/toJSON. Hostile JS
proxies and a compromised host environment are not a supported wire transport or sandbox.
Schema string lengths count Unicode code points; the separate input budget counts UTF-16
units, so its memory guard can reject a shape-valid oversized document.
JSON defaults to 2Mi UTF-16 units, depth128 and 100k nodes; callers can explicitly raise the
character ceiling up to64Mi units and node ceiling up to10million for bounded wire containers. Exact-byte hashing/UTF-8 encoding
default to50MiB, supporting the10MiB notebook container and50MiB request integrity digests;
callers may lower that limit or explicitly raise it to64MiB for canonical escape overhead.
These are not parser source limits. Notebook source digests enforce2MiB decoded UTF-8 per cell
and10MiB aggregate source, allow64Mi units for escaped canonical projection,
and bound canonical analysis metadata to256KiB. Acquisition/parser byte limits remain host-owned.

JCS uses canonicalize 2.1.0 (Apache-2.0), after rejecting duplicates, lone surrogates, nonfinite
numbers, executable values and excessive input. SHA256 uses @stablelib/sha256 1.0.1 (MIT),
the pure Uint8Array implementation without Node crypto imports. The workspace lock pins the
complete build dependency tree; consumer applications must retain their own reviewed lock.
This package's MIT licence does not replace those dependency licences.

`digestNotebookSource` accepts the splitter's explicit ordered source/analysis-metadata
projection, not raw notebook JSON. analysis-protocol binds Jupyter decoded cells and literal source maps; native splitter qualification remains later work.
Legacy LF-normalised digest values can be validated but are never calculated or relabelled here;
the V3 transformation belongs exclusively to C3.

For Windows case-insensitive path inventories, ASCII folding is qualified. Non-ASCII paths
remain supported as locators, but Windows case comparison is reported unqualified and
`validateRepoPaths` fails closed until the host supplies a qualified policy. This is not a
permanent Unicode ban. Paths preserve spelling; this API does not resolve symlinks/realpaths.

JSON schemas are emitted under `dist/schemas` from the same source definitions as validators.
Resource limits and captured-byte binding are semantic checks beyond JSON Schema shape checks.
The previously reserved Claim owner is deliberately moved from analysis-protocol to semantic-core
so FieldID/edges/Claims share one semantic owner without a reverse dependency. analysis-protocol
imports this schema; ClaimReview/Suppression/CheckResult remain owned by analysis-protocol.
C2b adds closed A1 Claim predicates, FieldID, lineage edge/transform, trace, OperationFlow and ArtifactSegment schemas in `lineage`. Claim IDs include revision, value, evidence and other semantic fields; `createClaimId` ignores the supplied placeholder id. FieldID is dataset-scoped; a resolver must supply its documented dialect case policy. Trace node resolution and traversal exhaustion are independent of unresolved references/coverage gaps. OperationFlow never asserts dataset lineage. Full domain models, runtime contracts and cross-language semantic parity remain later work. Capability registration and bounded context AI exchange now live in their own C2c packages.
