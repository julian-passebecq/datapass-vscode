# @juliandatapass-group/project-contracts

C5a/C5b alpha contracts for the DataPass project model (`dataprojects/technical-common/PROJECT_MODEL.md`
§3–6, PM interim decisions §13). Headless: no filesystem, network, Git, provider or execution host.
Built as CJS and ESM with declarations; depends only on `semantic-core`.

- `keys`: the §5 identity scheme. Each builder returns `{kind, id, key, identityKind}`: the wire ID
  is `datapass:<kind>:<sha256>` over JCS `{namespace:"datapass", kind, producerId:"project-contracts/1",
  stableInputs:{project:<namespace>, …}}` and the key is the readable `dp:` URI rendered from the same
  inputs. The producer is fixed so that two analyzers finding one environment derive one ID.
  Artifact IDs reuse semantic-core `createPathArtifactId`/`createNativeArtifactId` over the repository key.
  `parseKey` inverts every key; `verifyIdentity` recomputes the ID a key renders.
- `model`: executable schemas (one owner with the emitted JSON Schemas) for `ProjectIdentity`,
  `Repository`, `GitBinding`, `Environment`, `Target`, `Relation`, `Ref` and the
  `datapass.project-model/1` container; `sealProjectModel`, `validateProjectModel`, `lintProjectModel`.

Key rules:
- Segments are NFC and percent-encoded. Grammar words (`repo`, `path`, `bind`, `env`, `res`, `pipeline`,
  `act`, `seg`, …), `.`/`..` and a leading `_` are escaped inside free segments, so keys are injective
  and the sentinels `_unknown` (environment), `_unresolved` (dataset) and `_root` (binding folder) are
  unambiguous.
- Keys and repository URLs reject credentials, tokens, connection strings and local absolute paths
  (`key.secret-material`, `key.local-path`). The check is a fail-closed heuristic, not a secret scanner.
- Provider GUIDs are aliases (C5b/C6), never key segments. Target engine version is a property, not identity.

Model invariants checked by `validateProjectModel`: ref kind matches its ID; keys are canonical and
their recomputed ID matches; one project namespace; unique IDs and keys; no dangling reference;
bridge repository has role `bridge`; acyclic `promotesTo`; a `deployedRevision` needs listed evidence
and is refused on a `proposed` binding; typed endpoints for `contains`, `binds`, `promotes-to`,
`hosts`, `defines`, `configures`, `invokes`, `runs-in`, `reads`, `writes`; the snapshot content
digest (JCS over the canonical, ID-sorted model without the snapshot ID) and snapshot ID.
Absent optional values are wire `null`.

`lintProjectModel` returns non-fatal notices: native Fabric Git on a host other than GitHub or Azure
DevOps is unverified (Q4), `manual`/`unknown` binding mechanisms and bindings without deployment
evidence are gaps, unsourced environments and unresolved capability profiles are flagged.

C5b realizations (`realization`, PROJECT_MODEL.md §3.5–3.9, §6, §13 Q3/Q5):
- `Resource`: provider-versioned `resourceType`, optional target, environment (key segment `env/_unknown`
  when `null`) and parent (containment, acyclic), typed aliases and three evidence sides (`intended`,
  `declared`, `observed`). `realizationState` reads the sides; drift is never inferred from names.
- Aliases (`terraform-address`, `fabric-logical-id`, `provider-object-id`, `arm-id`, `uc-name`,
  `display-name`, `compose-service`, `k8s-object`, `host`) each have a value grammar
  (`checkAlias`, `alias.invalid-value`) and are evidence-bound; they never merge entities.
  `redactResourceAliases` hides provider IDs for exports and AI exchange (Q5).
- `SecretRef`: keyed reference `dp:<ns>/secret/<kind>/<locator>`, never a value;
  `valuePresentInSource: true` is a finding (`secret.value-in-source`).
- `Artifact`: key ↔ repository/path (or Fabric item), revision (integrity digest, optional semantic
  digest, Git commit/blob of one algorithm, acquisition), role/layer claim IDs and segment IDs.
- `Pipeline`/`Activity`: read-only structure (control vocabulary, conditional edges, `invokes`).
  Triggers, parameters and runs belong to the Cloud facet and Observe; control flow is never lineage.
- `EvidenceRef`: origin, data class, acquisition and environment of an evidence envelope, with the
  same enums as analysis-protocol `datapass.evidence/1`.
- Relations add typed endpoints for `references-secret`, `depends-on`, `observed-as` and `alias-of`.

Artifact identity and the analysis wire: C2b treats `artifactId` as opaque and analyzers echo the
snapshot manifest, so the host must mint it with `artifactIdentity` (producer `project-contracts/1`,
repoKey = the `dp:` repository key). `checkArtifactId` returns `identity.foreign-producer` for any
other minting (e.g. a legacy importer using a bare repository name and its own producer).
semantic-core caps `repoKey` at 256 characters, which bounds repository owner paths.

Navigation (`navigation`): `createProjectIndex(model)` gives lookups by ID/key, relations in/out,
resources per environment/target, containment, artifacts reaching a resource (`defines`,
`configures`, `runs-in`, or a Git binding whose folder contains the path), breadcrumb trails and a
`tree()` project → environment (+ `_unknown`) → target → resource → artifact for UIs.

## Frozen v1 (K1)

`schemas/v1/` holds the frozen wire schemas of this package (project model, ref, repository, Git binding, environment,
target, resource, secret ref, artifact, pipeline facet, observation batch, and `project-ids` for the `dp:` key and
`datapass:` wire ID grammar). A package test fails when the exported schemas drift from them. Frozen files never
change: a wire change adds `schemas/v2/` (`node scripts/freeze-project-model.mjs --version 2`), which CI
`contracts:additive` checks is additive over v1. Any change here needs the PM's `core-change` MR label
(`scripts/core-paths.json`).
