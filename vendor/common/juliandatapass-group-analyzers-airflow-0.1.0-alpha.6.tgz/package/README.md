# Airflow extractor (A5)

Headless K3 analyzer-SPI extractor `datapass.airflow-static`. It reads Airflow DAG files from CPython AST facts produced by the installed Python facts host. The same `host.startCaptured` adapter serves A2. DAG code is never imported, evaluated or run, and no connection is opened. The output is `datapass.lineage-graph/1` nodes and edges plus typed gaps.

`createAirflowExtractor({ python, parserLockDigest, sql?, dbtModels? })` owns the coverage-registry family `airflow.dag`: a `.py` file that imports `airflow`, priority 300, above `spark.python`. The signature is exported as `AIRFLOW_DAG_FAMILY`. Without `python`, every DAG file is `unknown` / `tool-unavailable`. Facts whose integrity digest does not match the captured bytes are refused.

## What is read

- **DAGs**: `with DAG(...)`, `dag = DAG(...)` with `dag=` or `with dag:`, and `@dag` functions. Each DAG is a `job` node scoped `airflow:<namespace>`, and its tasks are `task` nodes whose `parentId` is the DAG or their task group.
- **Dependencies** become `orchestrates` edges between tasks. The walker reads `>>`, `<<`, lists, `chain`, `chain_linear`, `cross_downstream`, `set_upstream` / `set_downstream`, `TaskGroup` and `@task_group`, TaskFlow calls and XComArgs (`op.output`). These shapes are ported from the V3 reader `src/core/airflow/dagExtract.ts`.
- **Datasets and Assets**: `schedule=` on Datasets or Assets (lists, `|`, `&`, `*OrTimeSchedule`) gives a `dataset -orchestrates-> DAG` edge. `inlets` become `reads` edges and `outlets` become `writes` edges. URIs map to canonical datasets:
  - `<scheme>://<host>/<catalog>/<schema>/<table>` and BigQuery `bigquery://<project>/<dataset>/<table>`;
  - object stores become bucket / folder / object.
  - Unknown schemes keep a stable `uri` dataset plus an `airflow.dataset-uri-unmapped` hole, so the producer and consumer DAGs still meet.
- **OpenLineage operator map** (`operators.ts`, exported as `MAPPED_OPERATORS`):
  - SQL operators (Databricks, Snowflake, Postgres, MySQL, MSSQL, Oracle, Redshift, Trino, Athena, BigQuery, Hive, Spark SQL) send their SQL to **A1**, the only column-lineage engine. A1's datasets are renamed onto the operator's platform.
  - Transfer operators map their source and target arguments.
  - Job operators (Databricks run-now, submit-run and notebook, Spark submit, Glue, ADF, dbt Cloud, `TriggerDagRunOperator`) `orchestrate` an external `job` node.
  - `ExternalTaskSensor` adds a cross-DAG edge, and S3/GCS sensors read their object.
  - **Provider operators** (AFPROV1, `providers.ts`, exported as `PROVIDER_OPERATORS`), looked up before the generic sensor/opaque fallback: `KubernetesPodOperator` / `GKEStartPodOperator` / `EksPodOperator` (container image name, and the script of `cmds` / `arguments`), EMR steps (`spark-submit` script of each step), EMR Serverless and EMR on EKS entry points, Dataproc jobs and batches (PySpark file, Spark jar, Spark SQL to A1), Lambda, AWS Batch, Synapse pipelines (same `adf-pipeline` node as the ADF reader), Airbyte connections and Fivetran connectors (typed external connector nodes); `GenericTransfer`, `SqlToS3Operator`, `S3ToSqlOperator` and generic `<X>To<Y>Operator` names with literal `sql` / `table` / bucket / object arguments; `SqlSensor`, `DatabricksSqlSensor`, `DatabricksPartitionSensor` and WASB blob/prefix sensors read their dataset. Templated or computed arguments are `airflow.operator-arg.*` holes; tables whose platform comes from a connection land on `airflow-connection` (connection id as a name, never resolved).
  - A local operator's `get_openlineage_facets_on_*` datasets are read. `airflow.lineage.entities.Table` borrows its platform from a same-named facet dataset.
- **Cosmos**: `DbtTaskGroup` and `DbtDag` read `ProjectConfig` (the project name) and `RenderConfig(select, exclude)`. Supported selectors are `path:`, `tag:`, `resource_type:`, names and intersections.
  - Given `dbtModels(project)`, for example `dbtModelsFromManifest(manifest.json)` from the DBT1 inputs, the extractor emits Cosmos task ids (`<model>.run` / `<model>.test`, `<seed>_seed`, `<snapshot>_snapshot`). Each one `orchestrates` the DBT1 `dbt-model` node with the same canonical id, and tasks are wired along dbt dependencies.
  - Graph operators (`+model`, `@`) and `config.*` selectors are holes.
- **dag-factory YAML** (DAGFACT1, family `airflow.dag-factory`, `AIRFLOW_DAG_FACTORY_FAMILY`, priority 290): each top-level DAG of a dag-factory YAML file, merged with its `default:` block, gives the same `job` and `task` ids as a Python DAG of that id. Task arguments go through the same operator map (SQL to A1). `dependencies`, `task_groups` (with `parent_group_name`), `task_group_name`, `inlets` / `outlets`, cron, `{__type__: datetime.timedelta}` and dataset schedules are read. Jinja values are masked as dynamic, never rendered. A loader `.py` (`DagFactory(...)` / `load_yaml_dags(...)`, which now also matches the `airflow.dag` sniff through `import dagfactory`) gets a `configures` edge to each DAG of a literal `config_filepath` / `dags_folder` in the selection. Otherwise it gets a typed hole.

## Holes, never guesses

Each hole is a `partial` gap on its line:

- opaque Python/Bash/TaskFlow tasks without inlets or outlets (`airflow.task-io-unknown`, `ask-human-or-ai`, the `lineage.gap.v1` route);
- SQL when A1 is not installed, a templated `.sql` file, dynamic SQL, or generic SQL whose platform comes from a connection;
- dynamic task ids, dynamic task mapping (`expand`), and DAG structure built in loops, conditionals or helper functions;
- Cosmos without its dbt project;
- operator arguments the map cannot read, such as a Redshift database that lives in a connection.

## Schedule facts (SCHED1)

Besides the graph, the extractor output carries `schedules`: typed `datapass.schedule-fact/1` facts. The shape is `ScheduleFact` in the neutral `@juliandatapass-group/analyzers/schedule` subpath, with `scheduleFactsOf(output)`, `cronDialect` and `cronOrUnknown`. Every orchestration analyzer shares it; `GraphSink.schedule` collects the facts.

- A fact points to lineage nodes by id. `nodeId` is the started job (here the DAG), and `triggerNodeId` is the trigger, schedule or deployment node when one exists. Its evidence is a `static` evidence with the file span.
- `kind` is one of:
  - `cron`: `expression` and `dialect` (`unix`, `quartz` or `preset`);
  - `rate`: `intervalMinutes`, null when the unit has no fixed length, and an optional `anchor`;
  - `event`: `triggeredBy` lists the upstream dataset ids;
  - `manual`: the file says there is no schedule;
  - `unknown`: a stable `reason`.
- `timezone` and `paused` are only what the file states. Null means that the engine default applies. Nothing is guessed.
- The SPI registry extraction carries them as `schedules` (analyzer-extraction v2, SCHED1b): consumers read `scheduleFactsOf(extraction)` through A0, not from the extractor.

Airflow reads `schedule`, `schedule_interval` and `timetable`:

- A cron string or preset. `@once` is `manual` and `@continuous` is `unknown`.
- `None` is `manual`.
- `timedelta` / `pendulum.duration` literals are a `rate`.
- `CronTriggerTimetable`, `CronDataIntervalTimetable` and `MultipleCronTriggerTimetable` give crons with their `timezone`. `Delta*Timetable` gives a `rate`.
- Datasets and Assets, including the `|` and `&` operators, give an `event` whose `triggeredBy` holds the same dataset nodes as the `orchestrates` edges. `DatasetOrTimeSchedule` gives both the cron and the event.
- A `start_date=pendulum.datetime(..., tz=...)` literal gives the time zone of crons and periods.
- A DAG without a schedule argument is `unknown` / `airflow.schedule-default-version-dependent`: the default is daily before Airflow 3 and none from Airflow 3.
- Imported names, custom timetables and other non-literal values are `unknown`.

`tests/fixtures/sched1/sched_dags.py` has one DAG per shape. Its facts are recorded in `airflow-facts.json` with the others.

## Fixture

- `tests/fixtures/foil-synthetic-airflow` is a byte copy of the FIXORC Airflow DAGs. Its golden extraction is `foil-synthetic-airflow.golden.json`, and `EXPECTED.md` lists the asserted edges.
- `tests/fixtures/shapes` holds synthetic DAGs for the other shapes and a parse error.
- `tests/fixtures/airflow-facts.json` stores their real CPython AST facts, recorded with the host serializer by `tests/record-facts.py`. It was recorded with CPython 3.13.1, which has the same 3.13 AST grammar as the pinned 3.13.15 host. The tests replay the facts, and no Python runs in CI.
- The SQL tests use a stand-in for A1, because A1 is TSQL-only today and the fixture SQL is Databricks SQL. The stand-in returns A1-shaped output.
