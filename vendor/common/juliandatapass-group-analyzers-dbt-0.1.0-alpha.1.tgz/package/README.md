# dbt extractor (DBT1, DBT2, DBT3)

Headless K3 analyzer-SPI extractor `datapass.dbt-static`. It reads a dbt project without running dbt, rendering Jinja or connecting to a warehouse. Its output is `datapass.lineage-graph/1` nodes and edges plus typed gaps.

`createDbtExtractor({ sql? })` owns six coverage-registry families: `dbt.artifact`, `dbt.packages`, `dbt.project`, `dbt.properties`, `dbt.seed` and `dbt.sql`. Their signatures are exported as `DBT_*_FAMILY`. `profiles.yml` belongs to CFG1, and a plain `.sql` file without Jinja stays with A1.

## Artifact mode

This mode runs when `<project>/<target-path>/manifest.json` is present. It reads `manifest.json` (v12) and `catalog.json` with origin `artifact` and evidence as JSON pointers:

- **Sources** become canonical datasets (`adapter_type`, database, schema, identifier).
- **Models, seeds, snapshots and analyses** become `dbt-model` nodes. Each one `writes` its relation. An ephemeral model writes a logical `dbt` relation instead.
- **Dependencies** become `reads` edges from each upstream relation.
- **Columns** come from the manifest and the catalog.
- **Tests** become `test` nodes with `tests` edges to the guarded column. Relationships tests link both parents.
- **Exposures** become `dashboard`, `ml-model` or `api-endpoint` nodes with `exposes` edges.

**DBT2** adds, from the same `manifest.json` (which holds what `semantic_manifest.json` holds):

- **Semantic models** become logical datasets `<project>.semantic_model.<name>`, read from their model relation. Entities, dimensions and measures are fields derived from the model columns named in their `expr` (a measure edge is `aggregate`). An `expr` whose words are not model columns is a `dbt.semantic-expr.*` hole.
- **Metrics** become `measure` nodes that read their input measures (simple, cumulative, conversion) or metrics (derived, ratio). A simple metric hangs off its semantic model.
- **Saved queries** become `visual` nodes that read their metrics and group-by dimensions. An export `writes` its relation.
- **Contracts, constraints and access** become `test` nodes, because dbt enforces them. An enforced contract gives one `contract <column>: <type>` node per typed column (the schema fact), and a catalog type that differs is a `dbt.contract-type-drift.*` hole (`supply-schema`). Each constraint gives a `constraint <type> (<columns>)` node. Non-default access, a group or a deprecation date gives one `access ...` node on the dbt-model.
- **Versions**: each version is its own dbt-model (`<uid>.vN`). The latest version also carries the unversioned unique id as an alias.
- **Unit tests** become `test` nodes on the model they cover and on the columns of their expected rows. Their given rows are fixtures, not data flow.

Unresolved metric inputs, saved-query dimensions and unit-test models are `unresolved-reference` holes (`ask-human-or-ai`). `semantic_manifest.json` without `manifest.json` is an `import-capture` hole. MetricFlow is never called.

Column lineage runs A1 over each model's `compiled_code` when `sql` (A1 on the SPI) is given. When it is not, each model gets a `partial` / `tool-unavailable` hole with `nextAction: ask-human-or-ai`, which is the `lineage.gap.v1` route. Python models are always such a hole.

## Static mode (DBT3)

This mode runs when there is no manifest, or the manifest is unreadable. It reads:

- `dbt_project.yml`: name, paths, `vars` and folder config (`+materialized`, `+schema`, `+database`, `+alias`, `+enabled`, `+target_schema`, `+access`, `+group`, `+contract`);
- properties YAML: sources, columns, generic tests, versions, contracts, constraints, access/groups, unit tests and exposures;
- Jinja `ref`, `source`, `config` and snapshot blocks;
- seed CSV headers and singular tests.

**Naming.** `createDbtExtractor({ targets })` takes the dbt targets by profile name. The host reads them from `profiles.yml` (a CFG1 file) with `readDbtTargets`, which keeps names only (adapter, database, schema, target name). With the project's target, relations are named as dbt names them: `generate_schema_name` is folded when it is dbt's default, the "custom schema as is" form or `generate_schema_name_for_env`. Snapshots use `target_schema`, and a versioned model writes `<name>_v<N>`. Node ids are then the manifest path's own ids. Generic tests get dbt's unique id (`test.<project>.<name>.<md5[-10:]>`), and governance nodes use the DBT2 keys. Without a target, relations stay logical (platform `dbt`) and the project gets a `dbt.no-target` hole (`import-capture`). A naming-macro override this reader cannot fold is a `dbt.naming-macro` hole, and relations stay logical. A config value that is not a literal is a `dbt.dynamic-config.*` hole.

**Column lineage.** `renderModel` renders model SQL as far as it is safe. `ref`/`source`/`this` become relation names, a literal `config()` disappears, and `var()` takes the project value or its literal default. `target.*` takes the target's value, and `{% if is_incremental() %}` takes the full-refresh branch. The rendered SQL goes to A1. Any other macro call becomes `null` and is a `dbt.macro.<name>` hole (the model is `dbt.column-lineage-partial`). Any other statement (`set`, `for`, `if <expr>`, ...) stops rendering and is a `dbt.jinja-<keyword>` hole. `select * from <one parent>` gives the parent's declared columns.

**Holes.** A model that properties YAML declares but whose file another extractor owns (a Python model, or plain SQL without Jinja) gets its node and relation from the YAML, plus a `dbt.model-file-not-received.*` hole (`analyze-selection`). Semantic models, metrics and saved queries stay one `*-needs-manifest` hole each, on their line, because MetricFlow resolution needs `manifest.json`. Unresolved or dynamic references become typed holes on their line.

## Fixture

`tests/fixtures/foil-synthetic-dbt` is a synthetic copy of FIXDBT (cloud `fixtures/foil-synthetic/dbt`, without its generator script). Its golden extraction is `foil-synthetic-dbt.golden.json`. The same fixture without `target/`, read with its `profiles.yml` target, is `foil-synthetic-dbt.static.golden.json`. Every node and edge in it is also in the manifest golden. `EXPECTED.md` lists the edges the tests assert.
