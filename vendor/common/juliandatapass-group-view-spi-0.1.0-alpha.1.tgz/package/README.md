# @juliandatapass-group/view-spi

K5 view SPI (FINAL_ARCHITECTURE §1.4, §2 K5): **views are projections of the one lineage graph**
(`datapass.lineage-graph/1`, lineage-core). Headless: no layout, no DOM, no renderer. workbench-ui hosts the
renderer; each Hop view or VSIX (Hop, Infra, IaC, Observe, …) is one projection.

## Contracts (frozen v1, `schemas/v1`, additive only)

| Schema | What it is |
|---|---|
| `datapass.view-projection/1` | filter + grouping + zoom level + edge direction + style preset ID |
| `datapass.view-style-preset/1` | node/edge style rules and the legend, as data (first matching rule wins) |
| `datapass.graph-view/1` | the projected DTO a renderer draws: groups, nodes, aggregated edges, legend, stats |
| `datapass.view-event/1` | selection/navigation events: select, clear-selection, zoom, expand/collapse group, reveal, open-evidence |

## Zoom levels (Julian idea 23)

`super-macro` → `macro` → `micro` → `very-micro`, coarse to fine:

- **super-macro**: each group is one node (`kind: "group"`, ID `group:…`); an expanded group shows its members at macro.
- **macro**: top-level nodes (datasets, jobs, resources…); fields and sub-fields fold into their dataset.
- **micro**: fields shown; sub-column paths fold into their field.
- **very-micro**: every node, including sub-column / JSON paths.

Edges between folded nodes are aggregated into one view edge per (from, to) pair with the member edge IDs,
kinds, best origin (runtime > artifact > static > ai-confirmed > ai-proposed) and a `certain` flag;
edges inside one representative are dropped. Flow edges are recorded in data-flow direction (see the
lineage-core README), so `direction: "data-flow"` and `"as-recorded"` both draw them as recorded.

## Volumetry as data

Flow edges (`reads`, `writes`, `derives`) carrying lineage volumetry are summed per view edge
(`rowsPerRun`, `bytesPerRun`), the frequency is kept when all members agree, the weakest basis wins
(observed < theoretical < ai-proposed), and `measuredEdges`/`flowEdges` show coverage. `label` is a
deterministic, locale-free string such as `≥ 1.2M rows · 3 GiB · PT1H (theoretical)`.

## Grouping and filters

- Filter: node kinds (top-level), edge kinds, origins, minimum evidence confidence, include/exclude IDs
  (a named child keeps its ancestors; children leave with their parent), drop isolated nodes.
- Grouping: ordered rules (kind, origin, `*`/`?` name glob, evidence path prefix, IDs), then `by`
  (`none`, `kind`, `origin`, `evidence-dir` with `dirDepth`). Groups apply to top-level nodes; fields follow their dataset.

## Styles and legends

Presets map matches to `shape`, theme color token (or `#rrggbb`), border and codicon name for nodes, and
line, color, width, arrow for edges. The view keeps only legend entries whose rule styled something, with
the resolved style. Hosts ship their own presets; `DEFAULT_STYLE_PRESET` is the default.

## Reference projections

`HOP_PROJECTION` (data lineage, data-flow, grouped by top-level folder), `INFRA_PROJECTION` (runtime
topology, one group per kind) and `IAC_PROJECTION` (declared resources, grouped by module folder).

## API

`projectGraph(graph, projection, preset, { zoom?, expandedGroupIds? })` → `ValidationResult<GraphView>`
(deterministic; the view ID digests its content). `validateViewProjection`, `validateViewStylePreset`,
`validateGraphView`, `validateViewEvent`. `initialViewState`, `reduceViewState` (pure), `zoomIn`/`zoomOut`,
`sourceIdsOf(view, target)` for navigation back to lineage node/edge IDs.

## Typed domain graphs

DataPass shows one project experience over multiple typed domain graphs: data lineage, control/orchestration, infrastructure, deployment, BI semantic, runtime execution, Git/history.
Each domain normalizes its facts into its own contract; a unified projection joins them.
A view is a projection of one or several domain graphs, never a second model of the project.
Lifecycle planes: Cloud = design, IaC = desired state, Deploy = transition, Observe = reality (monitoring is a sub-domain).

## Navigation and view catalog (V4-NAV)
- `navigation.ts`: `NAV_LEVELS` (project → subproject → artifact → step → operation), `ARTIFACT_KINDS`, `NavLocation`/`NavState`/`NavCommand` and the pure `reduceNav(state, command, ladder, views)` (history capped at 50). The host supplies the `NavLadder` and never lets view-spi read a project.
- `catalog.ts`: `LAYOUT_KINDS`, `ViewDef`, `resolveViews(catalog, overrides, kind, level)`, `validateViewCatalog`, `validateViewOverrides`. Views come from data (`datapass.view-catalog/1`); users reorder, hide, add or rename them with `datapass.view-overrides/1`; to reset, drop the entry.
- `DEFAULT_VIEW_CATALOG` is frozen as `schemas/v1/default-view-catalog.json`. Its titles are default labels only.
