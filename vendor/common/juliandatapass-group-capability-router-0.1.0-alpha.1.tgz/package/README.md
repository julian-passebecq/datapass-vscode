# @juliandatapass-group/capability-router

Operation capability router (CAPROUTE1a, PLAN § V4-ARCHCORR, AC-D2). For one **operation** in one **project
context**, it ranks the candidate providers and gives each a readiness, plus a preferred and a typed fallback route.

There is **no global provider status**. "Fabric: READY" does not exist; "Edit Fabric notebook: READY via Fabric Data
Engineering" does. Readiness always belongs to one route of one operation (brief § 35, § 37).

The router ranks, it never runs: no probe, provider call, credential read, command or execution happens here.
The app supplies the facts and renders the result. Provider names are data, never TypeScript types (§ 42).

## Contracts

| Contract | Export | What |
|---|---|---|
| `datapass.capability-router/1` | `CAPABILITY_ROUTER_JSON_SCHEMA`, `validateRouterCatalog` | Operation catalog: operations → candidate providers with requirements, provenance, side effects, action mode, route kind, tier |
| `datapass.capability-route-decision/1` | `CAPABILITY_ROUTE_DECISION_JSON_SCHEMA`, `routeOperation` | Ranked candidates for one operation, operation readiness, preferred and fallback route |

`fabricOperationCatalog()` returns the built-in catalog (a fresh copy): edit notebook, run Spark remotely, deploy a
source-controlled workspace (fabric-cicd, `fab deploy`, Fabric Git, FabricStudio publish), read OneLake, write
OneLake `/Files`, observe capacity CU, observe the Spark execution plan, Terraform Fabric deployment, PBIR editing.
Apps may extend it as data and validate it with `validateRouterCatalog`.

## Supplying facts

```ts
import { routeOperation, fabricOperationCatalog } from "@juliandatapass-group/capability-router";

const decision = routeOperation(fabricOperationCatalog(), {
  operationId: "fabric.workspace.deploy",
  project: { authority: "git" },                       // "git" | "workspace" | "unknown"
  tools: [{ id: "cli.fab", state: "present" }],         // installed-tool facts (tool-catalog/2 ids)
  providerState: [{ id: "auth.fab-cli", state: "present" }, { id: "auth.fabric-cicd.credential", state: "absent" }]
});
```

- `tools` are installed-tool facts, keyed by tool-catalog/2 entry ids (`toolSeedV2`: `ext.*`, `cli.*`, `app.*`,
  `tool.*`). Apps map their own probe ids onto them (the standalone maps `ext.onelake` → `ext.onelake-vscode` and
  `ext.powerbi-studio` → `ext.powerbi-vscode`). Ids the seed does not list yet stay namespaced: `service.*`,
  `cli.git`, `cli.terraform`, `cli.tofu`, `terraform/microsoft-fabric`.
- `providerState` holds `auth.*` and `config.*` facts (sign-in, live-provider gate, exporter configured…).
- A fact the app does not supply is `unknown`, never `absent`. Unknown never becomes READY.

A requirement is `required` or `optional`, of class `tool`, `auth` or `config`, and is satisfied when **any** of its
`anyOf` facts is present.

## Readiness

| Readiness | When |
|---|---|
| `READY` | every required fact present and the route is local (`open-native`, `copy-command`, `run-readonly`) |
| `IMPORT_ONLY` | every required fact present and the route imports exported evidence (`import-replay`); never live |
| `MISSING_AUTH` | tools present, a required `auth` fact absent |
| `NOT_CONFIGURED` | tools present, a required `config` fact absent (e.g. the live-provider gate) |
| `UNKNOWN` | a required fact was not supplied or is unknown |
| `AVAILABLE` | the route exists but not locally ready: a required tool is absent (install it), or the route is manual (`open-portal`, `manual-in-native-tool`, `reference-only`) |

Missing requirements are listed as typed `gaps` (required) and `optionalGaps`, each `{ class, anyOf, state }`,
so a card can say "install", "sign in" or "configure" without free text.

## Ranking

Candidates are ordered by: context demotion, tier (`primary` before `fallback`), readiness
(READY, IMPORT_ONLY, MISSING_AUTH, NOT_CONFIGURED, UNKNOWN, AVAILABLE), provenance (official, accelerator, community,
fork, sample-reference) and catalog order.

- **Git-authoritative rule (§ 20).** When `project.authority` is `git`, a `direct-publish` route (e.g. FabricStudio
  publish) is ranked last, carries the context note `git-authoritative-direct-publish-not-preferred`, and is never
  the preferred route. `git-first` routes (fabric-cicd, `fab deploy`, Fabric Git) are preferred.
- **Forks (§ 21).** A candidate with provenance `fork` resolves to its `canonicalUpstream`. When the operation also
  lists the upstream, the fork is folded into the upstream's `forks` list and never competes as a separate route.
- **Preferred.** The first non-demoted `primary` candidate that is READY or IMPORT_ONLY; `null` when none is.
  Reason: `git-first-route-for-git-authoritative-project` or `best-ready-route`.
- **Fallback.** The first usable (READY, IMPORT_ONLY or AVAILABLE) `fallback`-tier candidate (`declared-fallback`),
  else the next usable candidate (`next-usable-route`).
- **Operation readiness** (`readiness`, `summaryCandidateId`): the preferred route's, else the best non-demoted
  candidate's. This is the value a per-operation card shows.

## Rendering

Render one row per operation: `label`, `readiness`, and the provider of `summaryCandidateId`. Expanding a row lists
`candidates` in `rank` order with provenance, side effects, gaps and context notes. Side effects such as `billable`
or `writes-remote` must be shown before the user hands off to a route.

## Provenance

`provenance` is the tool-catalog/2 vocabulary (AC-D3): `PROVENANCE` holds the same values as `TOOL_PROVENANCE` from
`@juliandatapass-group/tool-catalog` (typed `satisfies readonly ToolProvenance[]`, a test checks the sets are equal)
but keeps the capability-router/1 order, so the frozen schema bytes do not change. Provider ids that are catalog entries (`tool.fabric-cicd`,
`tool.fabric-cicd.gbrueckl`, `toolbox.fabric`, `ref.fabric-toolbox.gbrueckl`, `ext.*`) carry the catalog's provenance
and `canonicalUpstream`; a test checks it.

## Not here

Probes, UI and the standalone switch (CAPROUTE1b); any provider call or execution; any clone of a native tool (§ 29).
