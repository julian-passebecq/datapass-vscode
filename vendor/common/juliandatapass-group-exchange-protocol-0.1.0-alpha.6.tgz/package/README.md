# @juliandatapass-group/exchange-protocol

C2c headless AIQuestion, AIProposal and ProposalResult contracts, compiled CJS/ESM/types, MIT.
These APIs return inert data. No automatic export/send, source mutation, bridge write or provider
action occurs. Product AI1 owns preview/redaction, explicit exchange and existing journals.

Every envelope binds the analysis JCS digest, exact source digests and a discriminated target:
context (bridge/workspace-local), bridge revision, realization revision or infra revision/scope.
`importAIProposal` additionally requires the current question and selected subject IDs/revisions.
Changed analysis/source/target/question or out-of-scope subjects fail closed. The selected context
is bounded to1000 subjects; callers must deliberately select a smaller context for larger graphs.

The first operation allowlist contains context notes and existing-subject Claim proposals.
It does not yet contain bridge configuration edits, realization changes, IaC edits or source-code
patches. Target discrimination does not authorize such edits. A proposed Claim must retain method
`proposed`, no minted evidence IDs, a deterministic Claim ID and the exact envelope producer.
The host must retain the AI envelope/origin when projecting context, never relabel it extraction.

`importProposalResult` always returns an unattested claimed review even when its JSON decision is
accepted. `assessProposalReview` requires an explicit local host receipt matching the complete
result, proposal, source/analysis/target binding and actor. Matching acceptance permits context
application only; sourceMutationAuthorized and gateEligible remain false. Call again against fresh
bindings immediately before applying context. The host owns authenticated review interaction,
receipt storage, bridge CAS/recovery and extension-storage persistence for workspace-local context.
Current subject/binding input is trusted host acquisition, never taken from the imported proposal.

Question/proposal text can contain client source or secrets. Validation is not redaction, consent,
or authentication. Preview/redaction and user-confirmed export remain mandatory host workflows.
Unknown fields/operations/major schemas are rejected. Raw imported approval/signature fields do
not create trust, and no external signing infrastructure is implied.

## lineage.gap.v1 (LG0)

`datapass.lineage-gap-request/1` / `datapass.lineage-gap-response/1`: DataPass asks the client AI to fill one
lineage gap (resolve-edge, classify-file, resolve-attribute). Requests are bounded (<= 20 spans of <= 200
lines, token budget), SEC2-redacted (`looksUnredacted` is a last-line guard, not the redactor) and carry
IDs only as context. `checkLineageGapResponse` rejects uncited or out-of-scope citations, unknown IDs and
answers the request did not allow, and returns proposal IDs plus prompt/response digests. Results are
always `ai-proposed`; confirmation happens in the lineage-core overlay. Contract only (runtime: AIB1).
A proposal may carry an optional `volumetry` (flow edges only, basis `ai-proposed`, `evidenceRef` = a cited span ID).

## exchange-gaps/1 (XGAP1)

`datapass.exchange-gaps/1`: what an AI-exchange answer says it could not determine. Any answer may carry an
optional `gaps[]` block of `{ location, question, reason }` (`reason`: `missing-source`, `ambiguous`,
`out-of-scope`); `readAnswerGaps` reads it (absent = none, bad block = rejected) without changing the frozen
answer wires (ai-proposal/1, lineage.gap.v1, app-exchange). The document form carries an `answerRef` when the
block travels beside the answer. Gaps feed "Next steps" as `ai-proposed` facts; nothing is resolved from them.
Distinct from `lineage.gap.v1`, which is DataPass asking the AI to fill one lineage gap.

`schemas/v1/` stays frozen; `schemas/v2/` (XGAP1) holds the two v1 files byte-equal plus `exchange-gaps.schema.json`.

## architect-review/1 (ARCHCALL1, feature contract)

`buildArchitectReviewRequest` builds an inert `datapass.architect-review-request/1` for one of three triggers
(`large-change`: an MR diff touching more components than a threshold; `repeated-failure`: the same check failing
at least twice in a row; `before-done`: before a readiness milestone is marked done), with subject Locations
(same shape as view-spi `datapass.nav-location/1`) and evidence refs. The request id is a digest of its content.
`checkArchitectReviewAnswer` accepts a `datapass.architect-review-answer/1` (findings + recommendation and
alternatives) only for the same request, about subjects and evidence that were sent; the result is always
`ai-proposed` and never gate-eligible. Hosts suggest the review, never send it: the person carries it through the
manual AI exchange. Not minted under `schemas/vN`: consumers vendor the feature SHA until V5FREEZE2 freezes it.
Labels for triggers and severities are host settings, never part of the contract.
