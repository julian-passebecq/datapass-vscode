# V3 compatibility — internal alpha candidate

`parseV3Bundle({ manifest, graph, understanding })` accepts host-acquired UTF-8 bytes or strict JSON strings. `understanding` is an array of per-file documents. Each result records the original document version and bytes, accepted/rejected state, donor diagnostics, and losses. `projectV3Bundle({ ...bundle, nativeSnapshots })` adds typed Common ArtifactSegments and OperationFlows. The adapter never acquires files, follows repository bindings, runs tools, executes text, or rewrites a bridge.

```ts
import { projectV3Bundle } from '@juliandatapass-group/compat-v3';
const result = projectV3Bundle({
  manifest: capturedManifestBytes,
  understanding: [capturedUnderstandingBytes],
  nativeSnapshots: [{ repository: 'pipelines', path: 'jobs/load.py', bytes: capturedNativeBytes }]
});
// Display diagnostics/losses even when a projection is available.
// Do not persist a result with cancelled === true.
```

## Version inventory

| Input | Reader / migration | Projection |
|---|---|---|
| Manifest 1 | Pinned donor; v1 local management, FOIL pack default, scopes/apps then v5 | Original inventory plus separate migrated manifest |
| Manifest 2 | Pinned donor v2→v3→v5 | Same |
| Manifest 3 | Pinned donor v3→v5 | Same |
| Manifest 4 | Pinned donor v4→v5 | Same |
| Manifest 5 | Pinned donor validation, cloned v5 | Same |
| Graph `0.1-draft` | Pinned donor, rejects v0.2-only fields | Bounded original inventory; no invented native facts |
| Graph `0.2` | Pinned donor semantic refs/cycles/paths/credentials | Same |
| Understanding 1 | Pinned donor schema and stable diagnostic codes | Steps→ArtifactSegment; links→OperationFlow; exact-byte source anchors when verified |
| Any other version | `unsupported-version` | Original bounded JSON/bytes retained, no projection |

V3 authority remains DataPass commit `99c670867acd33ab46af49148315655a75d08a55`. `authority/provenance.json` records every donor input hash, the generated reader hash, and three pinned generated schemas. `tools/capture-authority.mjs <donor-checkout>` reproducibly bundles only the pure donor exports and fails if any external import remains. The sole runtime adaptation replaces `Buffer.byteLength(text,'utf8')` with standard TextEncoder byte length. The managed Common V3 directories are untouched.

## Meaning and losses

- `declared`, `inferred`, `estimated`, and `illustrative` remain the same method on imported legacy statements. All retain `origin: unknown`, `executionScope: unknown`, and `acquisition: imported-capture`. V3 provenance does not establish an actual Common Claim or verified evidence.
- Every legacy step kind remains `legacyKind`, including task/config/test/transform. Milestone text becomes an ArtifactSegment label, never a DeliveryMilestone. Unsupported future kinds remain visible in the rejected document attachment; the authoritative validator is not weakened to accept them.
- V3 data/control/dependency links are `legacy-link` OperationFlows with original kind. Joins, columns, inputs/outputs, notes and graph relations remain in original documents. Dataset lineage stays empty because a name or drawing is insufficient to resolve a dataset/field identity.
- File roles and repository/tool/provider metadata remain declared inventory. The adapter does not upgrade them to observed native/runtime facts. `retained-legacy-inventory`, `legacy-claims-unverified`, and `unresolved-dataset-lineage` make these projection limits explicit.
- Seven evidence families have a separate bounded `importLegacyEvidence({family, version, record})` API. It maps all 38 pinned enum labels, preserves the complete original JSON/JCS digest, and emits shared Common Evidence shapes inside an always-unattested, inactive, non-gating receipt. They are never accepted as understanding-v1 documents implicitly. See `authority/evidence-inventory.json` and the exported `LEGACY_EVIDENCE_MAPPING` for source hashes and every row.

V3 source hashes use BOM-dropped, LF-normalized text. The adapter verifies that hash against the supplied capture, then binds a half-open UTF-8 byte interval to the capture's separate exact-byte digest. Line intervals are one-based/inclusive; byte intervals exclude the final line terminator and retain internal newline bytes. No source, digest mismatch, invalid UTF-8 or out-of-range lines gives a null anchor and a tagged legacy digest with a reason. A capture is hashed/scanned once, not once per step. No normalization changes original bytes.

## Budgets and host boundary

At most 500 documents / 50 MiB per bundle; manifest 1 MiB, graph 4 MiB, understanding 512 KiB, with donor depth/entity limits. Native capture budget: 500 files / 50 MiB total / 2 MiB per file. Duplicate capture identities remain unresolved. Oversized originals are not copied into output; the acquiring host keeps them. Cancellation is checked between documents and steps and returns partial/cancelled; synchronous calls cannot enforce a wall-clock deadline. Host scheduling owns that deadline.

Strict JSON does not accept comments. A host using JSONC must preserve original bytes separately and supply its explicitly normalized JSON; this adapter never claims those normalized bytes are the original source. For accepted bounded strict JSON, originalBytes supports exact rollback. Source bytes never come from a network or filesystem call inside the package.

## Qualification and release boundary

Tests preserve 33 original source-hashed donor corpus files, comprising 23 documents and 10 native sources. They cover every listed version, migration defaults, bad paths/refs, rejected future kinds, credential-shaped content, comments/duplicates/budgets, cancellation, unknown source, stale digest, Unicode, BOM, CRLF and CR anchors. Shared alpha3 DTO validators check projected segments/flows. Packed probes cover CJS, ESM, node10/NodeNext declarations and browser bundling without external dependencies; these are consumer-setting probes, not product adoption.

This package is `private: true`. DataPass donor code declares UNLICENSED; see NOTICE.md. Redistribution/licensing confirmation is a release blocker. C2b dependency is the reviewed draft alpha3 at `718e19866564fce4cb6152a0f37867a222874c98`, not a released production contract. Existing V3 bridges remain unchanged. Full C3 release acceptance, real product adoption, producer correctness/freshness/authority verification and redistribution clearance are not implied by this internal candidate.

## Seven-family import boundary (alpha.2)

Families: `datapass-observation` (10 labels), `datapass-basis` (5), `understanding-provenance` (4), `cloud-observation` (4), `mosaic-evidence` (7), `studio-workspace-truth` (3 quality labels), `studio-run-ledger` (5 evaluation states). Unversioned vocabularies require version:null and are pinned by source commit; BASIS uses 0.1-draft, understanding/Studio use version1. Unsupported families/versions fail explicitly; unknown labels remain retained with unknown dimensions.

Every mapping row specifies method, acquisition, environment, executionScope, origin, evidence kind and a loss explanation. Imported real/local/remote labels never mint real origin or provider environment. Simulated remains simulated-engine; targets/design/copy-only/idle retain not-executed where the original label supports it. Input population/data class remains unknown. Parent references remain original and unresolved; no fictitious ancestry is fabricated. Source hashes attest only to the pinned mapping inventory, not to an imported record's truth.

Studio truth readiness/rule flags are retained as reported data, never folded into a CheckResult. Run-ledger imports retain metrics and units, input revision, nested truth, client version, timestamps and raw fingerprint. Both sha256- and fnv1a- fingerprints stay legacy labels; neither becomes an exact-byte source digest or signature. Studio's minimum valid identity/revision/fingerprint record is retained even when optional evaluation status is absent, with an explicit unknown mapping. No storage or capture methods from the Studio donor are executed.

Import limits are 256KiB bounded JSON characters, depth30, 20,000 nodes and at most500 Studio run records. Getters, cycles, non-JSON values and malformed identities are rejected by the Common boundary. The original is copied before mapping. Import output always has attestation:unattested, active:false and gateEligible:false, even if original JSON forges the opposite fields. It does not verify a whole producer document schema or authenticate an author.
