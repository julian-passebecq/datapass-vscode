# Tool catalog

Original headless C4 contract (`datapass.tool-catalog/1`). Versioned tool/pattern identities, source provenance, aliases and exact-version support lookups; no installation, process or network API. Evidence references are declarations, never authenticated execution permission. Missing licenses are null, not inferred MIT.

`cloudToolSeed()` holds the 25 Cloud tool identities (single source: `src/cloud-seed.ts`; provenance in `ownership/catalog-migration.json`), every capability `unknown` until evidenced. Cloud does not consume this package yet: its own `src/catalog.ts` stays until a later Cloud switch-over package. Verified native handoffs and IaC inventory remain to be implemented.

## `datapass.tool-catalog/2`: tool provenance (TOOLPROV1, AC-D3)

Additive over `/1` (every v1 field kept; `/1` and `validateCatalog` are unchanged). Each entry adds:

- `provenance`: one of `TOOL_PROVENANCE` = `official | community | fork | accelerator | sample-reference`. This is the only provenance vocabulary: the standalone and Cloud map their own labels onto it through one mapping function each.
- `canonicalUpstream`: the catalog entry id of the upstream tool. Required for a `fork` (and must name an existing non-fork entry), `null` otherwise. A fork is never a competing deploy route: a router resolves it with `canonicalToolId()`.

`validateCatalogV2` enforces the v1 rules plus the fork rules. `toolSeedV2()` is the Cloud seed upgraded to `/2` with the brief § 21 classification plus the tools the seed lacked: `microsoft/fabric-cicd` official, `gbrueckl/fabric-cicd` fork → `tool.fabric-cicd`, `gbrueckl/Fabric.Toolbox` sample-reference, `microsoft/fabric-toolbox` accelerator, FabricStudio / PowerBI-VSCode / OneLake-VSCode community, Fabric VS Code / Fabric DE / `fab` official.

**v1 → v2 read-upgrade** (`upgradeCatalogToV2`, `provenanceFromV1`): `toolKind: reference` → `sample-reference`; `publisher.category: official` → `official`; `community`, `internal` and `unknown` → `community` (never promoted to official). v1 cannot express fork or accelerator: pass explicit overrides for those. Upgraded entries have `canonicalUpstream: null`.

## `datapass.tool-catalog/3`: lifecycle routing (TBX1a, brief § 19, 38)

Additive over `/2` (every v2 field kept; `/1`, `/2` and their validators are unchanged). Each entry adds `routing`, `null` when the entry is not routed, otherwise:

- `domains` (≥ 1, no duplicates): `TOOL_DOMAINS` = `observe | finops | admin | deploy-git | cloud-readiness | governance-security | architecture-materialization | capability-router`. There is no "toolbox" domain: an asset appears where it is used, never on one giant Toolbox page.
- `relevanceCondition`: `allOf` project facts (`<namespace>:<value>`, e.g. `platform:fabric`, `fabric:spark`) that must all hold, plus a one-line description.
- `prerequisites`, `sideEffects` (e.g. "deploys monitoring resources into a Fabric workspace"): short lines shown before any hand-off.
- `evidenceKinds`: `TOOL_EVIDENCE_KINDS` (`cpu`, `memory`, `shuffle`, `spill`, `duration`, `cu`, `cost`, `audit`, `inventory`, `configuration`, `security-finding`, `deployment`, `throughput`): what the asset's outputs can feed into Observe once imported. Import is replay-only in V1 (AC-D4, TBX1b); routing never authorizes cloning, installing, running or deploying.

`validateCatalogV3` = the v2 rules (through `catalogV3ToV2`) plus the routing rules. `upgradeCatalogToV3` leaves every entry unrouted. `entriesForDomain(catalog, domain)` lists a domain's entries.

`toolSeedV3()` = `toolSeedV2()` plus one `accelerator` entry per microsoft/fabric-toolbox asset the standalone catalogues: id `toolbox.fabric.<asset>`, alias = the standalone `fabric-tools.json` id, sources pinned to `FABRIC_TOOLBOX_VERIFIED_REF`. Routing: Cost Analysis → observe + finops; FUAM → observe + admin; Platform and Spark Monitoring → observe; the two CI/CD accelerators → deploy-git; Assessment Tool → cloud-readiness; Security Audit → governance-security; RTI Eventstream → architecture-materialization; the three MCP servers → capability-router. `toolbox.fabric` stays the discovery/provenance entry and `gbrueckl/Fabric.Toolbox` stays sample-reference, both unrouted. The toolbox code is referenced, never vendored (§ 29, 38). `tests/fixtures/standalone-fabric-tools.json` is a copy of the standalone catalog: a test fails when a standalone id has no seed entry.
