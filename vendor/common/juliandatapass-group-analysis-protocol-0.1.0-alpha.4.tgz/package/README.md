# @juliandatapass-group/analysis-protocol

C2b alpha evidence/authority/wire contracts, compiled as CJS and ESM with declarations and named
subpaths. `diagnostic` and `producer` retain the C1 vocabulary. `evidence` validates origin,
data class, acquisition, environment and execution scope independently; bounded ancestry
checks preserve all inherited origins/data classes and reject missing references/cycles.
`providerContentEligible` is only content suitability, never authenticity or a provider pass.
Source-anchor shapes in an evidence envelope still need binding to captured bytes by the host.

`authority` owns the one serializable ClaimReview, Suppression and CheckResult schema.
**quality-protocol/DQ1 consumes or re-exports these exact contracts** and owns rule execution,
readiness folding and final gate eligibility. It must not create a competing CheckResult.

`importAuthorityRecord` always produces inactive, unattested claimed records. Copied trusted
fields are rejected. `assessLocalAuthority` requires a host callback over its private receipt
store, binding the exact record digest, current subject, action and actor. A JSON field or
Git author string is not authentication. Suppression receipt matching does not activate a
suppression: DQ1 must check rule, scope and expiry. Even a matching check receipt does not
pass a gate here. The host/store, attestation persistence, readiness folds, full domain Claim models
and cross-language semantic parity remain later C2/host work.

JSON schemas under `dist/schemas` are emitted from the executable schema definitions.
Imports never run commands, contact providers, or start optional modules.

`wire` owns the closed `datapass.analysis-wire/1` request/cancel/progress/result/error ABI.
`validateAnalysisMessage` validates shape; only `createAnalysisSession(request, captures)`
establishes local exact-capture/request binding. Its `accept`, `cancel` and `supersede` methods
reject stale generations, changed parser/config/source tuples, cancelled and terminal results.
The closure is local trusted state, never JSON authority. Discarding an old session without
superseding/cancelling it is not cancellation; the host must retain and retire the active session.
Results validate subject revisions, Claim IDs, evidence/edge references and exact source anchors.
They establish static content consistency, not producer authenticity or provider qualification.

Limits distinguish source from transport: 2MiB/file or decoded cell, 10MiB aggregate decoded
notebook source, 50MiB raw notebook container and aggregate captured request. Large notebook
outputs therefore consume the independent raw-container/request allowance, not source allowance.
Raw frames/results also cap at50MiB UTF-8; validation uses a separate50Mi UTF-16-unit/10million
node/depth128 budget. Limits can be reduced per request. Time, worker concurrency, cancellation
grace and parser traversal depth are declared host obligations, not enforced timers in this pure
library. Memory containment and pre-read frame limits belong to the separately qualified host.

`source-map` verifies Jupyter JSON cell pointer/index/ID, exact container hash, decoded source
hash and UTF-8 span. A session also compares every projected cell's source/kind/ID to the raw
container. Language and analysisMetadata are declared pinned-splitter policy, not independently
inferred here. Embedded SQL mappings cover the complete child text with ordered nonoverlapping
parent segments and exact literal decoding (`verbatim` or JSON escape fragments only). Named
notebook cells are supported; anonymous-cell embedded mappings and Fabric/Databricks/Python
literal escape conventions need later versioned splitter qualification. A missing exact mapping
must remain a coverage gap; no string is executed.

`analysisCacheKey` includes semantic notebook source or exact file digest, parser/engine,
config/rules/options/limits and sorted dependencies; requestId/generation/snapshotId are excluded.
Cache **semantic payloads only**. An output-only notebook edit changes raw integrity and invalidates
the old wire result/header/anchors even when the semantic key matches. The host must reconstruct
current raw anchors/header from the new capture, validate all bindings and then accept a new
response. This library never automatically promotes or rebinds cached results. Session validation
rejects old raw response tuples. Source payload persistence is not implemented or authorized here.

Remaining C2 work is explicit: full domain/runtime/general-edit exchange
contracts and legacy enum migration, typed rule readiness, native splitter versions, full Python
semantic conformance and product adoption. No parser, IO, filesystem sandbox or executable plugin
loader ships in these packages.

## C2c persistence slice

`snapshot` creates/imports a versioned analysis snapshot. `createAnalysisSnapshot` first accepts
the result against exact captures. It omits captured source bodies, embedded child literal text
and diagnostic messages; source mapping metadata remains. This is **not general redaction**:
Claim names/rationales/assumptions and other semantic text can contain copied source or secrets.
The host owns storage policy, redaction/preview and explicit export. This package performs no IO.

The analysis digest excludes requestId/generation/requestDigest/snapshotId and capture timestamp;
semantic entity/claim/edge/evidence/gap arrays use stable ID order. Exact source bindings remain
part of content identity. Snapshot timestamp is validated UTC metadata, not measurement evidence.
`validateAnalysisSnapshot` establishes shape/digest consistency only. Imported snapshots always
start unattested, currency unknown and sourceValidated=false; a digest cannot authenticate a
producer. `revalidateAnalysisSnapshot` requires fresh captures and reconstructed embedded sources,
then runs the current session's complete reference/anchor checks. Even successful revalidation
remains unattested and cannot pass a provider gate. Stored/imported authority never self-restores.
Output-only notebook edits require new raw anchors/header despite reusable semantic cache content.
