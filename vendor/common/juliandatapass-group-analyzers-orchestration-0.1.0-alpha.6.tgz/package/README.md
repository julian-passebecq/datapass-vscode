# Orchestration extractor (ORC1, ORC2)

Headless K3 analyzer-SPI extractor `datapass.orchestration-static`. It reads Databricks Asset Bundles, Azure Data Factory / Synapse pipelines, Fabric data pipelines, AWS Step Functions state machines, Argo Workflows and GCP Workflows as data: JSON with a line-keeping reader, YAML with the DBT1 bounded YAML reader. Dagster and Prefect code goes through the bundled Python facts host like A5: it is parsed, never imported or run. Nothing is deployed, run, or sent to a provider. The output is `datapass.lineage-graph/1` nodes and edges plus typed gaps.

`createOrchestrationExtractor({ sql?, databricksJobId?, databricksCatalog?, awsCatalogPlatform?, python?, parserLockDigest? })` owns twelve coverage-registry families. Their signatures are exported:

| Family | Export | Files |
|---|---|---|
| `databricks.bundle` | `DATABRICKS_BUNDLE_FAMILY` | `databricks.yml` |
| `databricks.bundle-resource` | `DATABRICKS_BUNDLE_RESOURCE_FAMILY` | `resources/**/*.yml` starting with `resources:` |
| `adf.pipeline` | `ADF_PIPELINE_FAMILY` | `pipeline/`, `dataset/`, `linkedService/`, `trigger/`, `dataflow/` JSON |
| `fabric.pipeline` | `FABRIC_PIPELINE_FAMILY` | `<name>.DataPipeline/pipeline-content.json` |
| `stepfunctions.asl` | `STEPFUNCTIONS_ASL_FAMILY` | `*.asl.json`, `*.asl.yaml`, JSON with `StartAt` and `States` |
| `argo.workflow` | `ARGO_WORKFLOW_FAMILY` | YAML with `kind: Workflow`, `CronWorkflow`, `WorkflowTemplate` or `ClusterWorkflowTemplate` |
| `gcp.workflow` | `GCP_WORKFLOW_FAMILY` | YAML with `main:` and `steps:` |
| `orchestration.python` | `ORCHESTRATION_PYTHON_FAMILY` | `*.py` importing `dagster` or `prefect` |
| `prefect.deployment` | `PREFECT_DEPLOYMENT_FAMILY` | `prefect.yaml` |
| `logicapp.workflow` | `LOGICAPP_WORKFLOW_FAMILY` | `<app>/<workflow>/workflow.json` with a `definition` (LOGICAPP1) |
| `logicapp.connections` | `LOGICAPP_CONNECTIONS_FAMILY` | `<app>/connections.json` (LOGICAPP1) |

## What is read

- **Databricks Asset Bundles.**
  - The bundle, its variable defaults, and its targets: `bundle -deploys-> target -deploys-> workspace`.
  - Jobs are parentless `databricks-job` nodes, so Airflow and ADF references meet them. With `databricksJobId(name)` the node is `id:<n>`; without it the node is `name:<name>`.
  - Tasks and `depends_on`. Notebook, Python file, wheel, JAR and SQL-file tasks `orchestrate` their code unit. A relative path becomes a repository path.
  - `run_job_task` and `pipeline_task` resolve `${resources.*.id}`. `dbt_task` points to its project directory.
  - Clusters and warehouses `serve` their tasks. `trigger.table_update` tables `orchestrate` the job.
  - DLT pipeline IO comes from `configuration` table arguments.
- **ADF / Synapse.** Files are resolved per factory folder.
  - Activities and `dependsOn`. Nested `ForEach`, `Until`, `IfCondition` and `Switch` activities are children of their container.
  - Copy, Lookup, GetMetadata and Delete datasets are read through the dataset and linked-service documents. Tables get the linked service's database; files become object datasets.
  - Linked services `serve` their datasets.
  - Embedded SQL (Copy/Lookup queries, Script activities) goes to **A1**, the only column-lineage engine, on the linked service's platform.
  - Databricks job, notebook and Python activities, child pipelines, data flows (with their source and sink datasets), and schedule triggers.
- **Fabric data pipelines.** The same activity model, with inline `datasetSettings`: Lakehouse and Warehouse tables (`<item>.<schema>.<table>`) and Lakehouse Files. Also notebooks by item id and Script SQL against a Warehouse.
- **Step Functions.**
  - States with `Next`, `Choices`, `Default` and `Catch`. `Parallel` branches and `Map` processors are children of their state.
  - Task resources: Glue jobs (table arguments), Athena and Redshift Data SQL → A1, Lambda, EMR steps, Batch, Glue crawlers and nested executions.
  - `awsCatalogPlatform` (default `glue`) names the platform of Glue Data Catalog tables.

- **Argo Workflows.**
  - Each document of a multi-document file is read on its own. The workflow is a unit, its templates are its tasks, and the entrypoint is orchestrated.
  - DAG tasks and steps are children of their template. DAG edges come from `dependencies` and from `depends` conjunctions of task names. Each step group waits for the previous group.
  - A task runs its template. A `templateRef` or `workflowTemplateRef` names the (Cluster)WorkflowTemplate node of another file.
  - Container and script templates: S3, GCS and HDFS artifacts are object datasets (read for inputs, written for outputs). HTTP artifacts are URI datasets. The image is a `container-image` unit.
- **GCP Workflows.**
  - `main` and the subworkflows are tasks of the workflow. Steps follow their order, `next` and every `switch` target. Nested `steps`, `for`, `parallel` and `try`/`except` blocks are children of their step.
  - Subworkflow `call`s are edges. BigQuery `jobs.query` / `jobs.insert` send their SQL to A1 on `bigquery`, and destination and load tables are declared IO.
  - Dataproc jobs and batches, Cloud Run hosts and child workflow executions are units.
- **Dagster.**
  - `@asset` / `@multi_asset` tasks write their asset datasets (`dagster.asset.<key>`). They read their parameters, `ins=` and `deps=` (asset names, strings, `AssetKey`, `AssetSpec`).
  - Ops invoked in `@job` / `@graph` bodies are tasks of the job, with flow edges from argument passing.
  - `define_asset_job` orchestrates its selection: asset lists, `AssetSelection.assets/keys/groups`.
  - Schedules and sensors orchestrate their jobs. An asset sensor is triggered by its asset.
- **Prefect.**
  - Task and subflow calls in a `@flow` body are tasks of the flow, ordered by argument passing and `wait_for=`. A subflow call orchestrates the subflow.
  - `serve`/`deploy` calls and `prefect.yaml` deployments orchestrate their entrypoint flow (`path/file.py:function`, resolved against the Python files of the same run). The work pool serves them.

Table arguments are read by naming convention (`source_table`, `--target_table`, …). They are `inferred` (0.6); everything else is `declared`.

## Holes, never guesses

Each hole is a `partial` gap on its line:

- the body of a DLT source, Glue script, stored procedure or data flow script, and opaque activities (Web, Lambda, Batch, …; `*.activity-io-unknown` / `asl.task-io-unknown`, `ask-human-or-ai`);
- parameterized datasets and expressions, JSONPath parameters, and unresolved bundle variables;
- embedded SQL without A1, and Delta Lake datasets without a known catalog;
- Fabric connections given only by id;
- unknown `depends_on` / `dependsOn` / `Next` targets, and unmapped task, activity or dataset types;
- ORC2 (`argo.`, `gcpwf.`, `dagster.`, `prefect.` codes):
  - container commands, script sources, resource and HTTP templates, op and Prefect task bodies, HTTP / Cloud Run calls and Dataproc job IO;
  - `{{...}}` parameters and `${...}` expressions, and complex `depends` expressions (`||`, `!`, parentheses);
  - artifacts on the default artifact repository and unmapped connectors;
  - asset factories and definitions under loops or conditions, dynamic asset keys and selections (`AssetSelection.all()`, chained selections), and dynamic job bodies;
  - mapped tasks and calls in loops (a node plus a hole), unresolved job references, and `prefect.yaml` entrypoints outside the selection or templated.

A JSON syntax error makes the file `unknown` / `parse-error`. So does a Python syntax error (`*.python-parse-error`). Without the Python facts host, every Dagster or Prefect file is `unknown` / `tool-unavailable`.

## Schedule facts (SCHED1)

The extractor output also carries `schedules`: `ScheduleFact` facts from the neutral `@juliandatapass-group/analyzers/schedule` subpath. The A5 README describes the shape; read them with `scheduleFactsOf(output)`. The SPI registry extraction carries them as `schedules` (analyzer-extraction v2, SCHED1b). `GraphSink`, `STATIC_CONFIDENCE` and the relation helpers come from `@juliandatapass-group/analyzers/graph`, so this package no longer depends on analyzers-airflow. Each fact starts the job, pipeline, flow or workflow node, and its evidence is the line that declares it.

| Engine | Read | Unknown when |
|---|---|---|
| Databricks bundles | `schedule.quartz_cron_expression` (Quartz), `timezone_id`, `pause_status`. `trigger.periodic` is a rate. `trigger.table_update` and `file_arrival` are events on their datasets. | an unresolved `${var.*}`, no cron, or an unreadable period |
| ADF / Synapse triggers | `ScheduleTrigger`: with `recurrence.schedule`, a unix cron. Fields the schedule omits take the `startTime` value, as ADF does. Without it, a period (`frequency` × `interval`). `TumblingWindowTrigger` (its single `pipeline` is now also an `orchestrates` edge) is a period, and `BlobEventsTrigger` / `CustomEventsTrigger` are events. `timeZone`, `startTime` as the anchor, and `runtimeState` as paused. One fact per started pipeline, with the trigger node. | expressions, `monthlyOccurrences`, `interval` > 1 with a schedule, a missing `startTime` that the schedule needs, unmapped trigger types |
| Argo | `CronWorkflow` `schedule` / `schedules`, `timezone`, `suspend` | `{{...}}` parameters, or no schedule |
| Dagster | `ScheduleDefinition` and `@schedule`: `cron_schedule` (one cron or a list), `execution_timezone`, `default_status`. Sensors are events, and an asset sensor names its asset. The fact sits on the targeted jobs, or on the schedule node when no job resolves. | non-literal crons or time zones |
| Prefect | `prefect.yaml` `schedules` (or the single `schedule`): `cron` + `timezone`, `interval` in seconds + `anchor_date`, `active`, and the deployment's `paused`. Also `serve` / `deploy` with `cron=` and `interval=`. The fact sits on the flow, with the deployment node. | `rrule`, schedule objects, non-literal values |

| Fabric (SCHED1d) | The Git item `.schedules` part ([source code format](https://learn.microsoft.com/fabric/cicd/git-integration/source-code-format), [Job Scheduler configuration](https://learn.microsoft.com/rest/api/fabric/core/job-scheduler/create-item-schedule)): `Cron` is a period of `interval` minutes, `Daily` / `Weekly` `times` and `weekdays` are unix crons (one per distinct minute), `Monthly` on a `DayOfMonth` every month is a cron. `localTimeZoneId` (Windows id), `startDateTime` as the anchor, `enabled`. Since SCHED1e the `fabric.schedules` family belongs to FABITEM1 (analyzers-fabric), and the timing rules are `fabricScheduleTimings` in `analyzers/schedule`: the fact starts the canonical item node, `fabric-pipeline:<folder>` (the ORC1 pipeline), `fabric-notebook:<logical id>` from the item's `.platform`, `fabric-spark-job-definition:<folder>`. | `OrdinalWeekday` or `recurrence` > 1 months, unmapped types, unreadable times |
| AWS (SCHED1d, SCHED1f) | `readAwsScheduleTemplates(files, context, ref, options?)`, see below: `AWS::Events::Rule` ([EventBridge rule](https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-resource-events-rule.html)), `AWS::Scheduler::Schedule` ([EventBridge Scheduler](https://docs.aws.amazon.com/scheduler/latest/UserGuide/schedule-types.html)), SAM state machine and function `Events`. `rate()` is a period, `cron()` (6 fields, no seconds) is stated as the equivalent 7-field Quartz cron, an event pattern is an event. `State`, `ScheduleExpressionTimezone`. | `at()` one-time runs, intrinsic or `${...}` expressions |
| GCP Cloud Scheduler (SCHED1f) | `gcloud scheduler jobs create <http\|pubsub\|app-engine> NAME` in shell, PowerShell and batch scripts (`gcp.cloud-scheduler` family, `readGcloudSchedulerCommands`): `--schedule` (unix cron; legacy `every N minutes\|hours` is a period), `--time-zone`, a later `jobs pause NAME` = paused. The job is the trigger node `gcp-scheduler:<name>`; the literal target is the started node `gcp:scheduler-target` / `http:<uri>` (no query string, no credentials), `pubsub:<topic id>` or `app-engine:<service><url>`. | `$VAR` schedules or targets |

GCP Workflows files declare no schedule, so they give no facts. Terraform `google_cloud_scheduler_job`, `aws_scheduler_schedule` and `aws_cloudwatch_event_rule` are read by iac-hcl with the same timing helpers (`awsScheduleTiming`, `gcpSchedulerTiming`, `gcpSchedulerTargetKey` in `analyzers/schedule`). Not yet: `gcloud` lines inside CI YAML (the `cicd.*` families of analyzers-cicd).

Notebooks and Spark job definitions are named by their display name (the item folder), while pipeline activities name them by item id: the two nodes do not meet yet (the `.platform` logical id belongs to FABITEM1).

### EventBridge schedules (SCHED1d, SCHED1f)

Templates with a CloudFormation header belong to the `iac.cloudformation` family: since SCHED1f iac-cloud calls `readAwsScheduleTemplates` on them (scope `iac:<cloudformation|cdk>:<path>`, its own evidence). Templates without a header that hold `AWS::Events::Rule` or `AWS::Scheduler::Schedule` are the `aws.eventbridge-schedule` family of this extractor.

- A state machine is the ORC1 node `aws-stepfunctions:<name>`: the basename of its `DefinitionUri` or `DefinitionS3Location` key (the ASL file ORC1 reads), else its literal `StateMachineName`. A literal target ARN gives its last segment, like nested executions.
- Targets are `!Ref X`, `!GetAtt X.Arn`, `{"Ref": X}` or `{"Fn::GetAtt": [X, "Arn"]}`. Since SCHED1f any other resource of the template (Lambda, ECS, …) is started as its `infra-resource` node (the iac-cloud identity), and any other literal ARN as the node `aws:arn` / `<arn>`, never resolved. The rule or schedule resource is the trigger node.
- A target that does not resolve (a parameter, `!Sub`, `!ImportValue`) is an `aws.schedule-target-unresolved` hole and the fact stays on the trigger node; a state machine with an inline definition and no name is `aws.state-machine-name-unknown` (the fact starts its resource node). Nothing is guessed.

Fixtures:

- `tests/fixtures/sched1` has one shape per case. Its two Python files are recorded in `orc2-facts.json`.
- `tests/sched1.test.mjs` also checks the ORC2 fixtures and that the registry output is unchanged.
- `tests/fixtures/sched1d` holds the CloudFormation / SAM templates (`sched1d-aws.golden.json`); `tests/sched1d.test.mjs` checks them and that FIXORC gives no Fabric or AWS fact. The Fabric `.schedules` shapes moved to analyzers-fabric `tests/fixtures/sched1e` (SCHED1e).
- `tests/fixtures/sched1f` holds a headerless EventBridge template and `gcloud` scripts (`sched1f.golden.json`, the registry extraction); `tests/sched1f.test.mjs`.

## Logic Apps Standard (LOGICAPP1)

A Logic Apps Standard project is one folder per app: `connections.json` at its root and one `<workflow>/workflow.json` per workflow.

- Each workflow is the job node `logicapp-workflow:<app>/<workflow>`. Its triggers (`trigger:<name>`) and actions are tasks. The workflow orchestrates its triggers, and the triggers start the actions that have no `runAfter`.
- `runAfter` gives a control edge from each named sibling, whatever the status list (`Succeeded`, `Failed`, `Skipped`, ...). `Scope`, `If` / `else`, `Foreach`, `Until` and `Switch` cases / `default` nest their actions under the container, which starts their roots.
- Calls that meet other extractors' nodes:
  - ADF `CreateRun`, through the `azuredatafactory` connector path or an HTTP call to `management.azure.com`, and Synapse `.../pipelines/<p>/createRun`, both reach `adf-pipeline:<p>`.
  - Fabric `jobs/instances?jobType=` reaches `fabric-pipeline`, `fabric-notebook` or `fabric-spark-job` by item id (`inferred`: ORC1 names pipelines by display name).
  - A Power BI `datasets/<id>/refreshes` call, through the connector or HTTP, reaches the BI1M semantic model `remote:<id>`.
  - Databricks `jobs/run-now` with a literal `job_id` reaches `databricks-job:id:<n>`.
  - A `Workflow` action reaches its child workflow in the same app.
- `@{encodeURIComponent('x')}` literals are folded in. Any other expression (`@parameters(...)`, `@{triggerBody()...}`) is a `logicapp.expression.<what>` hole and is never evaluated.
- `connections.json` gives one `infra-resource` node per connection, `logicapp-connection:<app>` / key, labelled with its provider only (`managed:<api>`, `serviceProvider:<id>`, `function`). The connection `serves` each action and trigger that names it.
  - `parameterValues`, `authentication`, `connectionRuntimeUrl`, trigger URLs and connection resource ids are never read, so no secret, key or setting name reaches the graph.
  - Without the app's `connections.json` in the run, connections stay unnamed: no node and no hole.
- Schedule facts (engine `logicapp`) sit on the workflow node, with the trigger node:
  - `Recurrence` reads like an ADF `ScheduleTrigger`: a `schedule` becomes a unix cron (omitted fields take the `startTime` value), without it a period. `timeZone` and `startTime` are kept.
  - `SlidingWindow` is a period, `Request` is `manual`, and connector, webhook, service provider and polling `Http` triggers are events.
  - Expressions, `monthlyOccurrences` and an `interval` > 1 with a schedule stay `unknown`.
- Holes:
  - HTTP calls to other hosts (`logicapp.http-opaque`), service provider, function and inline code actions (`*-io-unknown`, `inline-code-opaque`);
  - unmapped connector actions and action types (`update-analyzer`; notification connectors like Office 365 and Teams are skipped);
  - `runAfter` and connection names that do not resolve, and connections whose API is an expression.
- Fixture: `tests/fixtures/logicapp1` (synthetic) holds the app `la-wind-ops` and trigger shapes in `la-shapes`. The registry extraction is `logicapp1.golden.json`, checked by `tests/logicapp1.test.mjs`.

## Fixture

- `tests/fixtures/foil-synthetic-orchestration` is a byte copy of the FIXORC DAB, ADF, Fabric and Step Functions files.
  - Its golden extraction is `foil-synthetic-orchestration.golden.json`, and `EXPECTED.md` lists the asserted edges.
  - One test runs it together with A5 to check the cross-file joins.
- `tests/fixtures/shapes` holds synthetic files for the other shapes and a parse error.
- `tests/fixtures/orc2` holds one synthetic project per ORC2 engine and a `shapes/` folder for the edge cases.
  - `orc2.golden.json` is the golden extraction, and `EXPECTED.md` lists the asserted edges.
  - The Python facts in `orc2-facts.json` are replayed. `tests/record-facts.py` records them with the host serializer, the same way A5 does.
- The SQL tests use a stand-in for A1, which returns A1-shaped output.
