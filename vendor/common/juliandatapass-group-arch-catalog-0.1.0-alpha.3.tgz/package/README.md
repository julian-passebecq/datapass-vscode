# @juliandatapass-group/arch-catalog

The DataPass architecture decision catalogue (ARCHCAT1, `handoff/ARCH_DECISIONS.md` § 1, § 3b, § 3c). It is the **knowledge** the bridge hands the client AI, not a menu of architectures: every entry is a platform-agnostic `arch.decision.v1` decision point (K9, `@juliandatapass-group/arch-decisions`) with its questions, options rated on the fixed criteria, invariant hints, a senior checklist (when / monitor / pitfalls), sub-decisions and estimate models (how to reason cost, runtime, data scanned or moved without running anything), then specialised for Fabric and Databricks. Data only: no filesystem, no network, no LLM. It is not a K9 core path; content grows by adding entries.

## Exports
- `ARCH_CATALOG`: `{ decision, meta }[]`. `meta` holds what § 3c asks for each decision point: `scale` (`macro-macro | macro | medium | micro | super-micro`), `valueLens` (`cost | time | trust | simplicity | capability`), `patternFamilies` (data engineering, warehousing, lakehouse, medallion, ML, BI, operations), `topics`, and `uncertain` (facts to re-check against current vendor docs: previews, limits, availability).
- `ARCH_CATALOG_DECISIONS`: the plain `arch.decision.v1` documents.
- `ARCH_COMPARISONS`: small comparison tables with concrete rows: ML on Fabric vs Databricks (`ml.placement`), Power BI on the Databricks lake vs a Fabric copy refreshed every 2 days (`bi.source`).
- `checkArchCatalog(entries, comparisons)`: the release check. It validates the whole catalogue with `parseArchCatalogue` (unique ids, no dangling or cyclic sub-decision), the tags, the coverage of every family, scale, pattern family and required topic (`REQUIRED_TOPICS`: medallion, polars, DuckDB, DuckLake, Iceberg / Delta / Parquet / Hudi, star schema, SCD, incremental, CDC, copy activity, ETL tool, Airflow, dbt, partition key, skew, compaction, cost saving, …), a Fabric and a Databricks view of every option, at least one estimate model per entry, and comparison columns that are real options.

## Entries by scale
| Scale | Entries |
|---|---|
| macro-macro | `platform.shape`, `platform.count`, `platform.team-model` |
| macro | `architecture.medallion`, `architecture.processing-mode`, `architecture.elt-etl`, `movement.cross-platform`, `storage.catalog`, `modelling.approach`, `ml.placement`, `bi.source`, `bi.metric-definition` |
| medium | `ingestion.mode`, `ingestion.tool`, `ingestion.schema-drift`, `transform.engine`, `pipeline.style`, `orchestration.tool`, `load.strategy`, `quality.gates`, `modelling.scd`, `modelling.conformed-dimensions`, `cost.control`, `ml.features`, `bi.storage-mode`, `bi.refresh`, `bi.logic-placement`, `monitoring.strategy`, `governance.sensitive-data` |
| micro | `transform.dbt-materialization`, `storage.format`, `storage.object-kind`, `layout.partitioning`, `layout.maintenance`, `modelling.grain`, `modelling.dimension-keys`, `modelling.dimension-shape`, `compute.scale`, `compute.spark-tuning`, `modelling.scd2-realization`, `quality.cleaning`, `bi.model-design`, `bi.security`, `code.packaging` |
| super-micro | `code.spark-functions`, `code.correctness-idioms`, `modelling.scd2-change-detection`, `modelling.fact-dimension-join`, `modelling.measure-additivity` |

The test file `tests/arch-catalog.test.mjs` asserts the table is complete. Prices are never stated: ratings and relative drivers only. Facts that move (previews, SKU limits) are flagged in the text and in `meta.uncertain`.

## Authoring
See `AUTHORING.md`. Check one entries module alone with `node packages/arch-catalog/tests/check-entry-file.mjs <module>`.

## Concept entries (CONCEPT1, `datapass.concept-entry/1`)
The deep understanding behind a decision point, at every scale down to one expression (how a NULL, a tie or a case variant is handled). Julian idea 30d; `handoff/ARCH_DECISIONS.md` § "Practice engine rules" in datapass-vscode. Additive: `arch.decision.v1` entries above are unchanged.
- `CONCEPT_CATALOG`: `ConceptEntry[]`. Fields: `concept` (plain senior explanation), `scale`, `decisionPoint` (an ARCHCAT1 id, or the entry's own id), `options[]` (`rightWhen`, `wrongWhen`, `cost`, `risk`, `failureScenario`), `recommendedWhen[]` (`constraint` ∈ `CONSTRAINT_KINDS`: sla-freshness, volume, cost, security, skills, platform, consumer — the RATIO1 `why` vocabulary — plus `data-profile`, the data's own shape (nullability, cardinality, duplicates, skew, lateness) that correctness choices hinge on; `condition`, `option`, `because`), `edgeCases[]`, `detectors` (shipped arch-lint ids; empty = "none yet", a detector gap), `plannedDetectors` (PLAN packages), `signals` (repo evidence), `questions` (taxonomy ids), `ownerQuestions[]` (class A), `platformNotes[]`.
- `QUESTION_TAXONOMY` / `TAXONOMY_DOMAINS`: the idea-30 question taxonomy with stable ids `q.<domain>.<topic>` and, per domain, its answerability classes (G/R/A/X), applicable scales and detector packages.
- `checkConceptCatalog(entries, { catalogDecisions, detectors })`: schema, unique ids, no dangling decision point, detector or taxonomy id. arch-lint depends on this package, so the caller passes the detector ids (`ARCH_LINT_DETECTORS`).
- `conceptCoverage()` / `renderConceptCoverage()`: domain × scale → entries and detector gaps, plus uncovered scales and unanswered questions. Golden: `tests/golden/concept-coverage.md` (`UPDATE_GOLDEN=1 node --test packages/arch-catalog/tests/concepts.test.mjs` to refresh).
- Domains: CONCEPT1a `sql`, `pyspark`, `spark-perf`, `modelling`, `ingestion` (48 entries); CONCEPT1b `streaming`, `layout`, `query-perf`, `architecture`, `governance`, `quality`, `powerbi`, `cost`.
- Authoring: one module per taxonomy domain in `src/concepts/entries/`, built with `domainConcepts(domain, [...])` from `src/concepts/dsl.ts`. A rationale (RATIO1) is a concept entry applied to one subject; a reasoning card (PRACT1) and an answer card (PRACT3) reuse these field names.
