# @juliandatapass-group/semantic-diff

Headless semantic diff for the DataPass Git companion (packet G1, `PROJECT_MODEL.md` §7.5). Given two
revisions of a project, it reports which **resources, pipelines, tables and IaC resources** changed
semantically, not which lines. Pure and deterministic: no I/O, no Git access, no client code executed.
The caller (Hub `git-service`, HG1b) reads the two sides of each file and the two project models.

## API

```ts
import { diffFile, semanticDiffer, diffProjectModels, diffProject } from '@juliandatapass-group/semantic-diff';

// One file, two sides (text, null when absent, or { skipped: 'binary' | 'too-large' | 'unreadable' }).
const file = diffFile({ path: 'sql/silver.sql', before, after });
// → { status, formatOnly, tables: { added, removed, kept }, changes: SemanticChange[], notes: string[] }

// Hub git-service seam (HG1b SemanticDiffer): the file diff plus `artifactKind`, mutable arrays.
const hub = semanticDiffer(path, artifactKind, before, after);

// Two sealed `datapass.project-model/1` snapshots: entity changes by wire ID.
const model = diffProjectModels(beforeModel, afterModel);

// Everything, grouped for the companion view.
const diff = diffProject({ before: beforeModel, after: afterModel, files, repositoryKey });
// → { model, files, resources, pipelines, tables, iacResources }: ImpactEntry[] each
```

`files` accepts raw sides or results of `diffFile` (so a caller can cache per file). `repositoryKey`
(`dp:<ns>/repo/...`) lets changed files be matched to model artifacts, then one hop through the
model: pipelines defined or invoked, resources reached by `defines`/`configures`/`runs-in`/binding,
datasets read or written.

Pass `lineage` (a typed `datapass.lineage-graph/1`, or any `{ nodes, edges }` of the same shape) to get
`downstream`: semantic models, measures, report pages and jobs reached from the change, for example
`models/fct_orders.sql` → dbt model → gold table → semantic model → 12 measures → 3 report pages.
Seeds are lineage nodes evidenced by a semantically changed file (a unique table name is only a hint
seed). The closure follows `reads`/`writes`/`derives`/`orchestrates`/`exposes`/`serves` downstream and
child → parent containment, is cycle-safe, stops at `maxDepth` (default 6, `truncated` says so), and
keeps each entry's hop path with its relation kinds. `describeDownstream(d)` gives "12 measures, 3 report pages".

## What is compared

| Input | Facts |
|---|---|
| SQL (T-SQL, Spark/Databricks SQL, DLT SQL) | tables read/written (CTEs excluded), created tables/views, join kinds, output and declared columns, `PARTITIONED BY`/`CLUSTER BY`/`ZORDER BY`, constraints and `EXPECT`, `${var}`/`{{var}}`/`:param` |
| PySpark | `table`/`saveAsTable`/`insertInto`/`DeltaTable.forName`/`spark.sql`, `.join(how=)`, `select`/`withColumn`/`drop`/`groupBy`, `partitionBy`/`clusterBy`, DLT tables and expectations, Great Expectations, widgets/conf |
| Notebooks | `.ipynb`, Fabric `notebook-content.py`, Databricks source: cells, `%sql` cells read as SQL |
| Airflow | DAGs as pipelines, `task_id=` calls and `@task` functions as steps |
| Terraform/OpenTofu | `resource`, `data`, `module`, `provider` by address with the changed attribute names; variables, locals, outputs, tfvars |
| Bicep | resources/modules (type and properties), params, outputs |
| YAML | GitLab CI jobs, GitHub Actions jobs, Databricks bundle jobs/pipelines/tasks and resources, Compose services |
| JSON | Fabric Data Pipeline / ADF activities (nested If/ForEach/Switch), Databricks job tasks; key order ignored |

`formatOnly` is true when the text differs only by comments, whitespace or (SQL) keyword case. Model
artifacts whose integrity digest changed but whose semantic digest did not are also format-only.
Neither produces impact entries. A new Git commit with the same bytes is not a change.

## Rules and limits

- Lexical rules, no parser: unknown syntax yields fewer facts, never invented ones. Dynamic SQL, string
  formatting, YAML anchors and `include:` stay opaque.
- Table names are text. They resolve to a model dataset only when exactly one dataset key ends with
  the name (`via: 'name-match'`, a hint, never an identity). IaC blocks resolve through a unique
  `terraform-address` alias. Unresolved entries keep `resolved: false` and a `table:`/`iac:`/`pipeline:` key.
- Identity is the wire ID. An artifact whose exact bytes appear at a new path is a `renamed`
  **proposal** only when the match is unique on both sides.
- Output arrays are sorted; the same input gives byte-identical JSON.
