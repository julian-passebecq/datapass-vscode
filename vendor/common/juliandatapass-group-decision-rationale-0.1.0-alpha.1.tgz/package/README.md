# @juliandatapass-group/decision-rationale

RATIO1 (Julian idea 30c, `handoff/ARCH_DECISIONS.md` § "Practice engine rules"). The reasoning behind each design choice, in one format, whoever wrote it. It is headless: no filesystem, no network, no LLM, and nothing it reads is executed.

A rationale is a catalogue entry (ARCHCAT1 / CONCEPT1) applied to one subject:

- `decisionPoint` is the entry id.
- `choice.option` and `alternatives[].option` are the entry's option ids.
- `why[].constraint` uses the constraint kinds of the entry's `recommendedWhen` rules.
- `scale` is the entry's scale.

## `datapass.decision-rationale/1`

A document holds `schema`, `project`, `author` and `rationales[]`. The JSON Schema is `DECISION_RATIONALE_JSON_SCHEMA`, frozen in `schemas/v1/`. Each rationale has these fields:

| Field | Meaning |
|---|---|
| `id` | Stable id (dotted / dashed lower case). |
| `decisionPoint`, `scale`, `domain` | Catalogue decision point, its scale, and the taxonomy domain (`modelling`, `incremental-cdc`, `layout`, `bi-semantic`, `security`, `streaming`, `cost`, `platform`, `engine`, `quality`). |
| `subjects[]` | What it is about: a `lineage-node`, `lineage-edge`, `infra-node` or `path`. A rationale needs a decision point, a subject, or both. |
| `choice` | `option` (catalogue option id or null) and `summary`. |
| `problemSolved` | The customer problem the choice solves. |
| `why[]` | Drivers. Each driver has a `constraint`, the `driver` text, the catalogue `rule` it applies (optional) and `evidence`. The constraint is one of the arch-catalog `CONSTRAINT_KINDS` (imported from `datapass.concept-entry/1`, the vocabulary of `recommendedWhen` rules): `sla-freshness`, `volume`, `cost`, `security`, `skills`, `platform`, `consumer`, `data-profile`. There is at least one driver. |
| `how` | The `mechanism` and the `evidence` spans that realise it. |
| `alternatives[]` | At least one. Each has an `option`, a `label`, `whenBetter` (when it would be the better choice), `costRisk` and `whyNotHere`. |
| `tradeoffs[]`, `revisitWhen[]` | The costs accepted, and the triggers that reopen the decision (with a constraint kind). |
| `confidence` | `high`, `medium` or `low`. |
| `origin` | `static-inferred` (DataPass from Git), `ai-proposed`, `ai-confirmed` or `owner-stated`. |
| `openQuestions[]` | What to ask the owner. |
| `acceptedFindings[]` | Arch-lint detector or finding ids accepted by design. This is honoured only for `owner-stated` and `ai-confirmed`. |

Evidence spans use the PRACT1 reasoning-card shape: `path`, `startLine` and `endLine` (1-based, inclusive, both null for a whole file), `cell` and `excerpt`.

## Validation (`readRationaleDocument`, `checkRationale`)

The envelope must be valid. After that, each rationale is validated alone, so one bad entry never hides the others.

**Errors** (the rationale is rejected):
- the schema fails (for example, no alternative, or an alternative without `whenBetter`);
- there is no subject and no decision point;
- an alternative equals the choice or is listed twice;
- there is no evidence (for an owner statement this is only a warning);
- an evidence span does not resolve to a repository file or its line range (checked when the host passes `repoLines`);
- the origin is not allowed for the source. A client AI or an owner cannot claim `static-inferred`, and DataPass cannot claim `owner-stated`.

**Warnings** (the rationale is kept):
- an unknown decision point or option;
- a scale that differs from the catalogue;
- an unresolved subject;
- `acceptedFindings` on an origin that cannot accept.

**Rationale is never a static fact.** No function here writes lineage, and the reader returns reasoning only.

## Static inference (`inferStaticRationales`)

`STATIC_RATIONALE_RULES` covers the cases where Git alone shows both the choice and its usual reason:

- Delta + MERGE → idempotent upsert;
- partition overwrite;
- dbt incremental, table or snapshot;
- SCD2 validity columns;
- a conformed date dimension in two or more files → star schema;
- a dimension with a surrogate key (`_sk`, identity) → surrogate keys (MODEL1);
- LASTNONBLANK / CLOSINGBALANCE* / last_value over a balance → semi-additive measure (MODEL1);
- role-playing date views or USERELATIONSHIP → role-playing dimension (MODEL1);
- partition by date or by tenant;
- clustering and table maintenance;
- Delta format;
- a broadcast hint;
- a watermark filter;
- Power BI Import and incremental refresh;
- dbt tests;
- an Airflow DAG;
- micro-batch streaming.

Inferred rationales follow these rules:
- They use the same schema, with `origin: static-inferred` and confidence `medium`.
- Alternatives come from the catalogue entry's other options (`whenToChoose` → `whenBetter`, `avoidWhen` → `costRisk`).
- Rules match text patterns and lean towards silence.
- Files under `.datapass/` are answers, not code, so rationale is never inferred from them.

The synthetic FOIL-like repository in `tests/fixtures/foil-like` yields 22 rationales (golden in `tests/golden/foil-like.static.txt`).

## Prompts as data (`RATIONALE_PROMPTS`, `rationaleRequest`)

These are the questions the bridge asks the client AI, one template per taxonomy domain, plus one ask per decision point (with the subjects the host found) and the answer rules. `@juliandatapass-group/arch-bridge` puts them in the exchange pack (minor 1).

## How modules consume rationale

Every module uses one API:

```ts
import { createRationaleIndex, mergeRationaleIntoCard } from '@juliandatapass-group/decision-rationale';
import { readRationaleLogs } from '@juliandatapass-group/arch-bridge';

const { index } = readRationaleLogs(repoFiles, { repoFiles, graphNodeIds }); // client-AI answers + static-inferred
index.getRationale('dbt/models/marts/fct_runs.sql');   // by path
index.getRationale('dbt:model.foil.fct_runs');         // by lineage / infra id
index.getRationale('bi.storage-mode');                 // by decision point
index.acceptedByDesign({ detector: 'partition-high-cardinality', subjects: [path] });
mergeRationaleIntoCard(reasoningCard, index, finding.id); // arch-lint card + rationale + accepted-by-design
```

Results are ranked owner-stated → ai-confirmed → ai-proposed → static-inferred. A module shows the first rationale and keeps the others as "also said".

Who uses it:
- **Arch-lint reasoning cards (PRACT1):** `mergeRationaleIntoCard` attaches the rationale and appends its alternatives. When an owner-stated or ai-confirmed rationale accepts the finding, the card is marked accepted by design, with its revisit triggers, instead of being raised again.
- **Cloud:** it reads the vendored Common. PRACT3 answer cards, the DASH1 architecture-decisions screen and the BI views call `getRationale(subjectId)` for the node, table or report being shown.

### Worked example 1: dbt incremental model vs full refresh

`fct_runs.sql` has `materialized='incremental'` with `unique_key` and an `is_incremental()` watermark filter.

Static inference writes the rationale `transform.dbt-materialization = incremental`:
- **why:** `volume` (a full rebuild each run is wasteful) and `sla-freshness` (short runs);
- **alternatives:** `table` (better while the model stays small or its logic changes often), `view` and `snapshot`;
- **revisitWhen:** late data beyond the lookback window.

The client AI then answers `ai-proposed` with repository facts: years of history, and the 05:00 DAG deadline, citing `foil_daily.py:5`. It also adds an open question: can a run be re-sent with an older `loaded_at`?

`getRationale('dbt/models/marts/fct_runs.sql')` returns the AI rationale first, then the static ones.

### Worked example 2: Power BI Import vs DirectQuery

`fct_runs.tmdl` has `mode: import` and a `RangeStart` / `RangeEnd` filter.

Static inference gives two rationales:
- `bi.storage-mode = import`, driven by `consumer` (sub-second visuals) and `sla-freshness` (the schedule is enough), with DirectQuery better "when reports must show data minutes old";
- `bi.refresh = incremental-refresh`.

The owner states the same choice (`owner-stated`, confidence high): the lakehouse SQL endpoint is slow at 08:00, and daily data is enough. Its revisit triggers are "a consumer needs intraday data" and "the model outgrows the capacity memory".

The owner's rationale ranks first on the BI view.

### Worked example 3: partition by date vs by tenant

`silver.measurements_history` is written with `partitionBy("measure_date")`, and `gold.tenant_exports` with `partitionBy("tenant")` plus `replaceWhere`.

Static inference writes one rationale for each, and each lists the other as its alternative:
- **Date:** pruning for period-bounded loads and queries. Revisit when daily partitions stay under about 1 GB.
- **Tenant:** per-tenant loads, deletes and isolation. Revisit when tenant sizes differ by orders of magnitude.

The client AI confirms the date choice (`ai-confirmed`) with `acceptedFindings: ["partition-high-cardinality"]`. The arch-lint finding on that file is then shown accepted by design, with the trigger "daily volume falls under ~1 GB", and is not raised again.

Tests: `node --test packages/decision-rationale/tests/*.test.mjs`. Refresh goldens with `UPDATE_GOLDEN=1` only after reviewing the diff. `tests/make-invalid-fixtures.mjs` regenerates the invalid fixtures from the valid answer.
