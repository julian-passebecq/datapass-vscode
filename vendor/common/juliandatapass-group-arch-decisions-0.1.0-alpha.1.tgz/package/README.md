# @juliandatapass-group/arch-decisions

Headless K9 contract (`handoff/ARCH_DECISIONS.md` §2, Julian idea 25). It describes how a senior cloud data engineer reasons about an architecture, stored as data. The package never reads files, calls a network or runs an LLM.

- **`arch.decision.v1`** (`datapass.arch-decision/1`). One catalogue entry is one decision point, platform-agnostic first. It holds:
  - the **questions** to ask;
  - the **options**, each rated once on every criterion of the fixed list: `data-movement`, `performance`, `price`, `complexity`, `operations`, `portability`, `skills`, `governance`. The rating is `excellent | good | fair | poor | bad | depends`, where `excellent` is the most favourable for the user and `depends` needs a note. Each option also carries when to choose it, when to avoid it, and what it adds and removes;
  - **invariant hints** that favour or exclude options;
  - **provider specialisations** keyed by provider id (`fabric` and `databricks` first; the list is open), giving each option's availability, its concrete services and the criteria it overrides;
  - a **senior checklist** (`when`, `monitor`, `pitfalls`);
  - **sub-decisions**, asked always or only once a given option is chosen.
- **`arch.choice.v1`** (`datapass.arch-choice/1`). This is the project's decision log, which the client AI writes in its own Git (`.datapass/decisions/*.json`, with an optional ADR markdown path). It holds:
  - the business case: the archetype and its invariants;
  - one entry per choice: decision id, scope, provider, `chosen` option, rationale, alternatives with a why-not, status `built | considered-not-built | proposed`, confidence, the business invariants it honours, a `parent` choice for sub-decisions, and links to `lineage` (lineage-graph/1) or `infra` node ids.

Validators:
- `parseArchDecision(entry)` checks the schema and the entry's internal references: unique ids, full criteria per option, and option references that resolve.
- `parseArchCatalogue(entries)` also checks that ids are unique across entries, that sub-decision ids resolve, and that nesting has no cycle.
- `parseArchChoiceLog(log)` checks unique choice ids, known invariants, known parents with no cycle, and that no alternative equals the chosen option.
- `checkChoiceLog(log, catalogue)` lists every cross-reference issue:
  - an unknown decision or option;
  - a log written against a newer entry version;
  - a built option that the named provider does not offer;
  - a parent whose decision does not raise this sub-decision.

Senior-mind fields (ARCHQ1, `handoff/ARCH_DECISIONS.md` § 3b). They are optional, so documents written before them stay valid, and the document ids stay `/1`. The JSON Schema files with these fields are in `schemas/v2/`; `schemas/v1/` stays frozen.
- `arch.decision.v1` `estimateModels[]` explains how to reason about a metric without running anything: the metric, the reasoning, the inputs, a formula in words, and the caveats.
- `arch.choice.v1` choices can add:
  - `realization`: `full | partial | none`, where `partial` means "I built part of it so you can compare";
  - `estimates[]`: an id, a metric (`cost | runtime | data-scanned | data-moved | storage | latency | freshness | other`), the compared `option`, `baseline`, `alternative` and `delta` values (each may be null) with a `unit`, a basis (`theory | measured`), and the assumptions;
  - `improvements[]`: `where` (a graph link or free text), `action`, `expectedGain`, and `estimateRefs`.
- The validator rejects a realization that contradicts the status (`built` with `none`, `considered-not-built` with `full`), duplicate estimate ids, a `delta` that is not `alternative − baseline` beyond hand rounding, an estimate that compares the chosen option with itself, and improvements that cite unknown estimates. `checkChoiceLog` also resolves `estimates[].option`.

Examples (synthetic): `examples/decisions/` holds the `transform.engine`, `storage.format`, `ml.placement` and `layout.partitioning` entries (the last one with estimate models). `examples/choices/foil-synthetic.decisions.json` is a FOIL-like log that covers all three statuses, and `examples/choices/supply-chain-senior.decisions.json` shows the senior fields. Catalogue content (ARCHCAT1) adds entries without changing a K9 core path.
