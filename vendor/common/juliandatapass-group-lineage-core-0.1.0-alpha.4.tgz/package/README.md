# @juliandatapass-group/lineage-core

L1 (ADR-0007 §2, `PROJECT_MODEL.md` §3.8/§5): headless, identity-based **static** lineage. It consumes
normalized analyzer outputs (an A0/A1 `AnalysisResult` is accepted as-is) and never reads files, calls
providers or executes SQL/Spark. It is the baseline that observation (OBSV1/OBSV3) is compared against.

## Identity

- Analyzers emit **boundary datasets**: bare table names scoped to one artifact. `buildLineageSnapshot`
  resolves them to one canonical dataset only through an **explicit mapping** (with evidence) or the
  artifact's **resolution context** (platform/catalog/schema from its C5 realization or the bridge).
- Equal labels in other artifacts become `candidateIds` (`possible`), never a merge. Unresolved names keep
  their analyzer ID, a `dp:<ns>/dataset/_unresolved/<name>` key and a `missing-context` coverage gap.
- `canonicalDatasetIdentity` / `canonicalFieldId` are the shared identity rule: the ID depends only on
  platform, catalog, schema, name (and field name), never on the SQL dialect. `casePolicy: insensitive`
  folds ASCII case of catalog/schema/name; `sensitive` never folds. **Observed producers (OBSV1) must use
  these helpers** so a table seen by a script and by a Spark run gets the same ID.

## Snapshot and queries

- `datapass.lineage-snapshot/1`: immutable, deterministic and sealed (`id` and `revision` are JCS digests;
  `validateLineageSnapshot` re-checks them). Canonical entities merge across artifacts; each edge keeps its
  analyzer claim and artifact (`edgeOrigins`).
- `traceLineage`: bounded breadth-first trace, upstream or downstream, filtered by relation
  (`data-value`/`row-influence`) and granularity. Defaults depth 20, 1,000 nodes, 3,000 edges, 2 s;
  cancellation, deterministic cursors (refused once the snapshot or request changes), depth-frontier nodes
  marked `truncated`, explanation paths and cycle (SCC) summaries. Returns the semantic-core
  `datapass.trace-result/1`; coverage gaps of the traversed artifacts are always reported.
- `impactOf`: downstream impact split into value impact and row-influence-only impact.
- `lineageCycles`: strongly connected components; lineage is not assumed acyclic.

## Static vs observed

- `projectCanonicalLineage` collapses local intermediates (query results, CTEs) into canonical
  dataset→dataset and field→field edges; any row-influence hop makes the projected edge `row-influence`.
- `datapass.observed-lineage-edge/1` is the runtime edge shape in the same identity space (provenance
  `observed | imported | synthetic`, `runRef` = OBSC `ObservedRun.runId`).
- `compareLineage` → `datapass.lineage-comparison/1`: `both | static-only | observed-only` per
  `lineageEdgeKey`. A match never upgrades the static edge; synthetic inputs set `synthetic: true`;
  `static-only` means "not seen" only when `observedCoverage` is `complete`. Edges through unresolved
  datasets are listed as `uncomparableEdgeIds`.

## Lineage graph v1 and AI overlay (K2/K7, LG0)

- `datapass.lineage-graph/1` (`buildLineageGraph`, `validateLineageGraph`): one graph for every extractor.
  Node kinds: dataset, field, job, task, dbt-model, measure, visual, dashboard, test, topic, api-endpoint,
  ml-model, ml-feature, infra-resource, secret-ref. Edge kinds: reads, writes, derives (field→field with
  transform), orchestrates, tests, exposes, deploys, serves, configures.
- Flow edges point in **data-flow direction** (PM ruling, 30 Sept 2026): `fromId` is upstream (where the
  data comes from), `toId` is downstream. `reads`: dataset/field/topic/api-endpoint → the job, task,
  dbt-model, ml-model, measure, visual or dashboard consuming it; `writes`: job/task/dbt-model → the
  dataset/field/topic it produces; `derives`: upstream field → downstream field. Trace, impact and views
  follow edges as recorded. `scripts/tests/flow-direction.test.mjs` checks every analyzer golden.
- IDs: datasets/fields keep `canonicalDatasetIdentity`/`canonicalFieldId`; sub-columns and JSON paths use
  `canonicalSubFieldId({ fieldId, path })` (still a `datapass:field:` ID); other kinds use `canonicalNodeId`.
  One `canonicalEdgeId` per (kind, from, to): evidence of every origin merges under it.
- Evidence on every node and edge: `origin` (static | artifact | runtime | ai-proposed | ai-confirmed),
  `extractor@version`, locator (file span or JSON pointer), confidence 0–1, run ref or proposal ID.
  Display origin: runtime > artifact > static > ai-confirmed > ai-proposed; only the first three are
  "certain" (`isCertain`).
- `datapass.lineage-overlay/1` at `.datapass/lineage-overlay.json`: client-AI answers to `lineage.gap.v1`
  (exchange-protocol), never facts. Status proposed → confirmed/edited/rejected by a human;
  `markStaleOverlay` (cited sha changed) and `supersedeOverlay` (certain edge now known).

- Optional `volumetry` on flow edges (reads, writes, derives; Julian idea 23): `rowsPerRun`, `bytesPerRun`,
  `frequency` (cron or ISO 8601 duration), `basis` observed | theoretical | ai-proposed, `evidenceRef`.
  At least one measure; merged edges keep observed > theoretical > ai-proposed.

Contract only: no bridge runtime, no AI call (AIB1).

## Graph domains (EDGEDOM1)

One user graph, several typed semantic graphs (brief § 25). `GRAPH_DOMAINS` lists them and
`EDGE_KIND_DOMAIN` (frozen, total) maps each edge kind to one; `edgesInDomain(graph, domain)` is a pure
filter for projections. The domain is derived from the kind, never stored: no schema, edge ID or golden change.

| Domain | Edge kinds |
|---|---|
| data | reads, writes, derives, tests |
| control | orchestrates |
| infrastructure | configures |
| deployment | deploys |
| bi-semantic | exposes, serves |
| runtime, git | none yet |

## Limits

Data-value and row-influence lineage at dataset/field granularity only (SQL and static PySpark). BI
measure/report, control and deployment relations (L1B, BI1) are separate projections and not in this
package yet. Rename reconciliation needs mapping evidence; string similarity never links datasets.
